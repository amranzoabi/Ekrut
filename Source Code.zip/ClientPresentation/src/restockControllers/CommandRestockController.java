package restockControllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import homepagescontrollers.AreaManagerInterfaceController;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import producereportscontrollers.AreaManager;

/**
 * This class is a Command Restock Controller for CommandRestockPage.fxml the
 * function of this class is to display all locations associated with the area
 * of AreaManager the AreaManager can see each location with the its percentage
 * of stock and is given the option of commanding a stock renewal. In case of
 * commanding a renewal, the request is then sent to the operations worker to
 * apply the stock renewal. This class also uses other classes to help manage
 * the properties one of the classes is TableRow - which helps us add rows to
 * our table of users registered
 * 
 * @author amran
 *
 */
public class CommandRestockController implements Initializable {
	/**
	 * to save/show area
	 */
	@FXML
	private Label IDDownPageArea;
	/**
	 * to save the root
	 */
	@SuppressWarnings("unused")
	private Parent root;
	/**
	 * Observable list for TableRow data
	 */
	ObservableList<TableRow> data;
	/**
	 * Label to show low Point
	 */
	@FXML
	private Label LowPointLBL;

	/**
	 * LowPointField is a text field in which the AreaManager is able to enter the
	 * new low point he desires this lowPoint is a variable which is set by the
	 * areaManager to be notified when the stock percentage of a certain location
	 * goes under that low point; so that the AreaManager be aware of it and issue
	 * restock command
	 */
	@FXML
	private TextField LowPointFIeld;
	/**
	 * SetLowPointBTN is a button for submitting the low point that the AreaManager
	 * wishes to change
	 */
	@FXML
	private Button SetLowPointBTN;

	/**
	 * This is our main table in which our locations will be displayed in for the
	 * manager to restock initialization of this table is in the initialize function
	 * at the bottom of the page
	 */
	@FXML
	private TableView<TableRow> RestockTable;

	// Columns START//
	/**
	 * Column for RestockTable - Location
	 */
	@FXML
	private TableColumn<TableRow, String> Location;
	/**
	 * Column for RestockTable - RequestID
	 */
	@FXML
	private TableColumn<TableRow, String> RequestID;
	/**
	 * Column for RestockTable - Stock
	 */
	@FXML
	private TableColumn<TableRow, Integer> Stock;
	/**
	 * Column for RestockTable - CommandRestock
	 */
	@FXML
	private TableColumn<TableRow, HBox> CommandRestock;
	// Columns END//
	/**
	 * this is an array of type string which contains the different locations of a
	 * given area we will use this array store locations of current area
	 */
	String[] locations = { "Old City", "Down Town", "Maritime Museum", "Haifa-University" };

	/**
	 * Method for initializing our current page our table - RestockTable - will be
	 * initialized using multiple instances of our TableRow class
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		CommonMethods.continueWithEnter(LowPointFIeld,SetLowPointBTN);
		CommonMethods.textLegality(LowPointFIeld, 2);
		IDDownPageArea.setText(AreaManagerInterfaceController.workingarea);
		getDataDB();
		buildView();
		
	}
	
	
	/**
	 * Method to build the view for the table view using the data that we took
	 * from the data base
	 */
	private void buildView() {
		Location.setCellValueFactory(new PropertyValueFactory<>("Location"));
		RequestID.setCellValueFactory(new PropertyValueFactory<>("RequestID"));
		Stock.setCellValueFactory(new PropertyValueFactory<>("Stock"));
		CommandRestock.setCellValueFactory(new PropertyValueFactory<>("CommandRestock"));

		ClientMethods.SendMessage(Commands.GetLowLevel, AreaManager.getArea());
		Integer LowLevel = ChatClient.LowLevel;
		LowPointLBL.setText(LowLevel.toString());
		// making the cell change colors depending on the item inside it
		Stock.setCellFactory(column -> {
			return new TableCell<TableRow, Integer>() {
				@Override
				protected void updateItem(Integer item, boolean empty) {
					super.updateItem(item, empty);
					if (item != null) {
						setText(item.toString());
						String OldStyle = this.getStyle();
						if (item <= LowLevel)
							this.setStyle(OldStyle + "-fx-background-color:#FF0000;" + "-fx-border-color:#ededed;");
						else if (item > LowLevel && item < LowLevel + 20)
							this.setStyle(OldStyle + "-fx-background-color:#FFFF00;" + "-fx-border-color:#ededed;");
						else
							this.setStyle(OldStyle + "-fx-background-color:#00FF00;" + "-fx-border-color:#ededed;");
					}

				}
			};
		});

		RestockTable.setItems(data);
	}
	/**
	 * Method to get the data from the data base 
	 */
	private void getDataDB() {
		ClientMethods.SendMessage(Commands.GetAllMachinesJoinsProductsInsideThem, "nothing");
		
		ArrayList<ArrayList<Object>> MachinesPlusProductArr = new ArrayList<>();
		MachinesPlusProductArr = ChatClient.MachinesPlusProductArr;
		data = FXCollections.observableArrayList();
		for (ArrayList<Object> arr : MachinesPlusProductArr) {
			String Area = ((String) arr.get(2));
			if (Area.equals(AreaManagerInterfaceController.workingarea)) { // constant for now needs to change after
				// declare all the variables we need in table row
				ArrayList<Object> DataToInsert = new ArrayList<>();
			
				Integer MachineID = (Integer) arr.get(0);
				String location = ((String) arr.get(1));

				Integer pid = ((Integer) arr.get(4));
				Integer stock = ((Integer) arr.get(5));
				TableRow save = new TableRow(location, pid, stock, null);
				
				DataToInsert.add(location);
				DataToInsert.add(Area);
				DataToInsert.add(pid);
				DataToInsert.add(MachineID);
				
				String RestockRequestStatus=(String)arr.get(7);
				if(RestockRequestStatus.equals("No Request")) {
					HBox box = new HBox();
					box.setSpacing(20);
					box.setAlignment(Pos.CENTER);
					box.getChildren().add( MakeRestockButton(save, DataToInsert) );
					save.setCommandRestock(box);
				}
				else {
					HBox box = new HBox();
					box.setSpacing(20);
					box.setAlignment(Pos.CENTER);
					Label SentLabel=new Label("Sent");
					SentLabel.setStyle("-fx-alignment:center;"+"-fx-font-size: 15px;" + "-fx-text-fill: #90BB14;" 
									 + "-fx-font-weight:bold;");
					box.getChildren().add(SentLabel);
					save.setCommandRestock(box);	
				}
				
					data.add(save);
			}

		}
	}
	
	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event on clicking the close X icon
	 * @throws Exception exception if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}


	/**
	 * Method for showing help information, a popup with explanation of current page
	 * will show up to the user
	 * 
	 * @param event event on clicking the help icon
	 * @throws Exception exception if an error occurs
	 */
	public void help(MouseEvent event) throws Exception {

		CommonMethods
				.help("This is the ReStock Command Page:" + "\nYou Can Command the Restock of products in a location"
						+ "\nThat needs to be restocked by clicking on Restock Button", getClass());

	}

	/**
	 * Method for going back to the page that precedes the current page
	 * 
	 * @param event event on clicking the arrow back icon
	 * @throws Exception exception if an error occurs
	 */
	public void back(MouseEvent event) throws Exception // close window
	{
		CommonMethods.switchSceneBack(getClass(), event);
	}

	

	/**
	 * Method to create and connect a ReStock button
	 * 
	 * @param DataToInsert the data to insert
	 * @param row       the row
	 * @return Button
	 */
	public Button MakeRestockButton(TableRow row, ArrayList<Object> DataToInsert) {
		Button restockbtn = new Button("Restock");
		restockbtn.requestFocus();
		restockbtn.setOnMouseClicked(event -> {
			Integer pid = (Integer)DataToInsert.get(2);
			Integer machineID=(Integer)DataToInsert.get(3);
			ArrayList<Integer> DataToChangeStatus = new ArrayList<>();
			DataToChangeStatus.add(pid);
			DataToChangeStatus.add(machineID);
			
			ClientMethods.SendMessage(Commands.UpdateRestockRequestStatusToSent, DataToChangeStatus);
			ClientMethods.SendMessage(Commands.InsertRestockRequest, DataToInsert);
			
			data.remove(row);
			CommonMethods.ShowDialog("Restock request has been sent to the operations worker", getClass());
		});
		restockbtn.setStyle("-fx-background-radius: 50;" + "-fx-background-color: #90BB14;" + "-fx-font-weight:bold;"
				+ "-fx-font-size: 12px;" + "-fx-effect: dropshadow( three-pass-box , #A2A09F, 13, 0 , 7 , 7 );"
				+ "-fx-text-fill: white;");
		return restockbtn;

	}

	/**
	 * @param event
	 */
	@FXML
	void SetLowLevel(ActionEvent event) {
		String LowLevel = LowPointFIeld.getText();
		String Area = AreaManager.getArea();
		ArrayList<String> DataToSend = new ArrayList<>();
		DataToSend.add(LowLevel);
		DataToSend.add(Area);
		ClientMethods.SendMessage(Commands.SetLowLevel, DataToSend);

		// changing the cells LowLevel colors after setting new LowLevel
		Stock.setCellFactory(column -> {
			return new TableCell<TableRow, Integer>() {
				@Override
				protected void updateItem(Integer item, boolean empty) {
					super.updateItem(item, empty);
					if (item != null) {
						setText(item.toString());
						String OldStyle = this.getStyle();
						if (item <= Integer.parseInt(LowLevel))
							this.setStyle(OldStyle + "-fx-background-color:#FF0000;" + "-fx-border-color:#ededed;");
						else if (item > Integer.parseInt(LowLevel) && item < Integer.parseInt(LowLevel) + 20)
							this.setStyle(OldStyle + "-fx-background-color:#FFFF00;" + "-fx-border-color:#ededed;");
						else
							this.setStyle(OldStyle + "-fx-background-color:#00FF00;" + "-fx-border-color:#ededed;");
					}

				}
			};
		});
		LowPointLBL.setText(LowLevel.toString());

	}

	/**
	 * This class is a TableRow for the table which the locations will be shown in
	 * parameters of the class are Location, RequestID, Stock another variable is a
	 * Button, this button will be used to issue the command of stock renewal all
	 * these variables are defining details of our location the class has a
	 * constructor that allows us to set the data through it, we also have getters
	 * and setters for each variables as well we use this class mainly to add each
	 * instance into a row of the table we have
	 * 
	 * @author amran
	 *
	 */
	public class TableRow { // class for table of request we can make

		/**
		 * String Location to store location of restock needed
		 */
		private final SimpleStringProperty Location;
		/**
		 * Integer RequestID to store ID of restock request
		 */
		private final SimpleIntegerProperty RequestID;
		/**
		 * Integer Stock to store amount of stock currently
		 */
		private final SimpleIntegerProperty Stock;
		/**
		 * Button CommandRestock to confirm the restock command
		 */
		private HBox CommandRestock;

		/**
		 * Constructor for TableRow class - that allows us to initiate an instance with
		 * values already assigned
		 * 
		 * @param location       string
		 * @param requestID      integer
		 * @param stock          integer
		 * @param commandRestock button
		 */
		public TableRow(String location, Integer requestID, Integer stock, HBox commandRestock) {
			super();
			this.Location = new SimpleStringProperty(location);
			this.RequestID = new SimpleIntegerProperty(requestID);
			this.Stock = new SimpleIntegerProperty(stock);
			this.CommandRestock = commandRestock;

		}

		/**
		 * getter for value Location of this User class
		 * 
		 * @return Location value of current (this) instance
		 */
		public String getLocation() {
			return this.Location.get();
		}

		/**
		 * setter for value Location of this User class
		 * 
		 * @param location is used to be assigned to Location's value
		 */
		public void setLocation(String location) {
			this.Location.set(location);
		}

		/**
		 * getter for value RequestID of this User class
		 * 
		 * @return RequestID value of current (this) instance
		 */
		public Integer getRequestID() {
			return this.RequestID.get();
		}

		/**
		 * setter for value RequestID of this User class
		 * 
		 * @param requestID is used to be assigned to RequestID's value
		 */
		public void setRequestID(Integer requestID) {
			this.RequestID.set(requestID);
		}

		/**
		 * getter for value Stock of this User class
		 * 
		 * @return Stock value of current (this) instance
		 */
		public Integer getStock() {
			return this.Stock.get();
		}

		/**
		 * setter for value Stock of this User class
		 * 
		 * @param stock is used to be assigned to Stock's value
		 */
		public void setStock(Integer stock) {
			this.Stock.set(stock);
		}

		/**
		 * getter for value CommandRestock of this User class
		 * 
		 * @return CommandRestock value of current (this) instance
		 */
		public HBox getCommandRestock() {
			return this.CommandRestock;
		}

		/**
		 * setter for value CommandRestock of this User class
		 * 
		 * @param commandRestock is used to be assigned to CommandRestock's value
		 */
		public void setCommandRestock(HBox commandRestock) {
			this.CommandRestock = commandRestock;
		}

	}

}
