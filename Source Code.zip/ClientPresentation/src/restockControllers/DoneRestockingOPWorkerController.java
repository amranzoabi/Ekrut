package restockControllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import homepagescontrollers.OPWorkerHomepageController;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
/**
 * This class is a Command Restock Controller for CommandRestockPage.fxml
 * the function of this class is to display all locations associated with the area of AreaManager
 * the AreaManager can see each location with the its percentage of stock and is given the option
 * of commanding a stock renewal. In case of commanding a renewal, the request is then
 * sent to the operations worker to apply the stock renewal.
 * This class also uses other classes to help manage the properties
 * one of the classes is TableRow - which helps us add rows to our table of users registered
 * @author amran
 *
 */
public class DoneRestockingOPWorkerController  implements Initializable{
	
	/**
	 * for data
	 */
	ObservableList<TableRow> data;
    /**
     * LowPointField is a text field in which the AreaManager is able to enter the new low point he desires
     * this lowPoint is a variable which is set by the areaManager to be notified when the stock percentage
     * of a certain location goes under that low point; so that the AreaManager be aware of it and issue restock command
     */
    @FXML
    private TextField LowPointFIeld;
    /**
     * SetLowPointBTN is a button for submitting the low point that the AreaManager wishes to change
     */
    @FXML
    private Button SetLowPointBTN;
    
    /**
     * This is our main table in which our locations will be displayed in for the manager to restock
     * initialization of this table is in the initialize function at the bottom of the page
     */
    @FXML
    private TableView<TableRow> RestockTable;

    //Columns START//
    /**
     * Column for RestockTable - Location
     */
    @FXML
    private TableColumn<TableRow, String> Location;
    /**
     * Column for RestockTable - RequestID
     */
    @FXML
    private TableColumn<TableRow, String> RequestID;
    /**
     * Column for RestockTable - Stock
     */
    @FXML
    private TableColumn<TableRow, String> Stock;
    /**
     * Column for RestockTable - CommandRestock
     */
    @FXML
    private TableColumn<TableRow , Button> CommandRestock;
    /**
     * Label to show the area
     */
    @FXML
    private Label IDarea;
    //Columns END//
    /**
	 * this is an array of type string which contains the different locations of a given area
	 * we will use this array store locations of current area
	 */
    String[] locations = {"Old City","Down Town","Maritime Museum","Haifa-University"};
    
    
	/**
	 * Method for closing the application, the window of the application would be closed
	 * @param event event on clicking close icon
	 * @throws Exception exception if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception
	  {
		ClientMethods.close(event);
	  }

    /**
     * Method for showing help information, a popup with explanation of current page will show up to the user
     * @param event event on clicking the help icon
     * @throws Exception exception if an error occurs
     */
    public void help(MouseEvent event) throws Exception{
    	CommonMethods.help("This is a Restock Confirmation Page"
    			+ "\nYou Can Confirm the Restocking after its done",getClass());
    }


	/**
	 * Method for going back to the page that precedes the current page
	 * @param event event on clicking the back arrow icon 
	 * @throws Exception exception if an error occurs
	 */
	public void back(MouseEvent event) throws Exception 
	  {
		CommonMethods.switchSceneBack(getClass(), event);
	  }

	
	/**
	 *Method for initializing our current page
	 *our table - RestockTable - will be initialized using multiple instances of our TableRow class
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		IDarea.setText(OPWorkerHomepageController.workingarea);
		getAndBuildDataDB();
		
    }
	/**
	 * Method to get the data from the data base
	 * and build the view
	 */
	private void getAndBuildDataDB() {
		Location.setCellValueFactory(new PropertyValueFactory<>("Location"));
        RequestID.setCellValueFactory(new PropertyValueFactory<>("RequestID"));
        Stock.setCellValueFactory(new PropertyValueFactory<>("Stock"));
        CommandRestock.setCellValueFactory(new PropertyValueFactory<>("CommandRestock"));
		ClientMethods.SendMessage(Commands.GetAllRestockRequests , "nothing" );	
		ArrayList<ArrayList<Object>> RestockRequests = new ArrayList<>();	
		RestockRequests = ChatClient.RestockRequestsArr ;
		data = FXCollections.observableArrayList();
		
		for (ArrayList<Object> arr : RestockRequests)
		{
			String Area = ((String) arr.get(2));
			if (Area.equals(OPWorkerHomepageController.workingarea)) { // constant for now needs to change after
				// declare all the variables we need in table row
				Integer RequestID=((Integer) arr.get(0));
				String location = ((String) arr.get(1));
				Integer pid = ((Integer) arr.get(3));
				Integer MachineID = ((Integer) arr.get(4));
				TableRow save = new TableRow(location, pid, MachineID, null);
				save.setCommandRestock( MakeDoneRestockButton(RequestID,MachineID ,pid , save));
				// add the tablerow to the array data which observes the data on the table
				data.add(save);
			}
			
		}
	
	    RestockTable.setItems(data);
	}
	
    /**
     * Method to create and connect a Done ReStocking button for the ReStocking (the row in that table view)
     * @param RequestID the request id
     * @param MachineID the machine id
     * @param pId product id
     * @param row row that needs to be connected to the ReStocking button in the table view 
     * @return ReStocking button
     */
    public Button MakeDoneRestockButton(Integer RequestID,Integer MachineID,Integer pId,TableRow row)
    {
    	Button restockbtn=new Button("Done Restocking");
    	restockbtn.requestFocus();
    	restockbtn.setOnMouseClicked(event ->  
    	{
    		
    		ArrayList<Integer> ListToSend = new ArrayList<>();
    		ListToSend.add(MachineID);
    		ListToSend.add(pId);
    		ClientMethods.SendMessage(Commands.UpdateProductInMachineQuantity , ListToSend ); 
    		ClientMethods.SendMessage(Commands.DeleteRestockRequest , RequestID);
    		ClientMethods.SendMessage(Commands.UpdateRestockRequestStatusToNoRequest,ListToSend );
    		data.remove(row);
    	} );
    	restockbtn.setStyle("-fx-background-radius: 50;"+"-fx-background-color: #90BB14;"+"-fx-font-weight:bold;"+"-fx-font-size: 12px;"
    	    	+"-fx-effect: dropshadow( three-pass-box , #A2A09F, 13, 0 , 7 , 7 );"+"-fx-text-fill: white;");
    	return restockbtn;
    	
    	
    }
    /**
	 * This class is a TableRow for the table which the locations will be shown in
	 * parameters of the class are Location, RequestID, Stock
	 * another variable is a Button, this button will be used to issue the command of stock renewal
	 * all these variables are defining details of our location
	 * the class has a constructor that allows us to set the data through it, we also have getters and setters for each variables as well
	 * we use this class mainly to add each instance into a row of the table we have
	 * @author amran
	 *
	 */
	public class TableRow { //class for table of request we can make

		/**
		 * for the locaiton
		 */
		private  final SimpleStringProperty Location;
		/**
		 * for the request id
		 */
		private  final SimpleIntegerProperty RequestID ;
	    /**
	     * for the stock
	     */
	    private  final SimpleIntegerProperty Stock;
	    /**
	     * to save the button
	     */
	    private Button CommandRestock;
		
		/**
		 * constructor for the class
		 * @param location current location
		 * @param requestID the request id
		 * @param stock the stock
		 * @param commandRestock the button
		 */
		public TableRow(String location, Integer requestID, Integer stock, Button commandRestock) {
			super();
			this.Location = new SimpleStringProperty(location);
			this.RequestID = new SimpleIntegerProperty(requestID);
			this.Stock = new SimpleIntegerProperty(stock);
			this.CommandRestock = commandRestock;
			
		}
		
	    
		/**
		 * Method to get the location
		 * @return return Location
		 */
		public String getLocation() {
			return this.Location.get();
		}

		/**
		 * Method to set the Location to location
		 * @param location parameter to set the Location to
		 */
		public void setLocation(String location) {
			this.Location.set(location);
		}

		/**
		 * Method to get the RequestID
		 * @return return RequestID
		 */
		public Integer getRequestID() {
			return this.RequestID.get();
		}

		/**
		 * Method to set the RequestID to requestID
		 * @param requestID the parameter to set the RequestID to
		 */
		public void setRequestID(Integer requestID) {
			this.RequestID.set(requestID);
		}

		/**
		 * Method to get the Stock
		 * @return return Stock
		 */
		public Integer getStock() {
			return this.Stock.get();
		}

		/**
		 * Method to set Stock to stock
		 * @param stock the parameter to set the Stock to 
		 */
		public void setStock(Integer stock) {
			this.Stock.set(stock);
		}

		/**
		 * Method to get the Button
		 * @return return the Command Restock button
		 */
		public Button getCommandRestock() {
			return this.CommandRestock;
		}

		/**
		 * Method to set the button
		 * @param commandRestock the parameter to set the command button to
		 */
		public void setCommandRestock(Button commandRestock) {
			this.CommandRestock = commandRestock;
		}
	     
	}

}
