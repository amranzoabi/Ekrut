package registrationcontrollers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import homepagescontrollers.AreaManagerInterfaceController;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

/**
 * This class is a Review Registrations Controller for
 * ReviewRegistrationsPage.fxml the function of this class is to display all
 * registrations that are awaiting review the reviewing is done by the area
 * manager associated with the users, the area manager is shown a table (list)
 * with users that are awaiting confirmation each row in this table shows
 * information of user awaiting confirmation, the area manager is given the
 * option to either confirm or reject given user This class also uses other
 * classes to help manage the properties one of the classes is TableRow - which
 * helps us add rows to our table of users registered
 * 
 * @author amran
 * @author mohamad
 */
public class ReviewCustomersRegistrationsController implements Initializable {
	/**
	 * to save/show area
	 */
	@FXML
	private Label IDDownPageArea;

	/**
	 * the list that shows on the table
	 */
	public ObservableList<TableRow> data;

	/**
	 * This is our main table in which our users will be displayed in for the
	 * manager to confirm/reject initialization of this table is in the initialize
	 * function at the bottom of the page
	 */
	@FXML
	private TableView<TableRow> RegistrationsTable;

	// Columns START//
	/**
	 * FirstName Column
	 */
	@FXML
	private TableColumn<TableRow, String> FirstName;
	/**
	 * LastName Column
	 */
	@FXML
	private TableColumn<TableRow, String> LastName;
	/**
	 * Email Column
	 */
	@FXML
	private TableColumn<TableRow, String> Email;
	/**
	 * PhoneNumber Column
	 */
	@FXML
	private TableColumn<TableRow, String> PhoneNumber;
	/**
	 * CreditCard Column
	 */
	@FXML
	private TableColumn<TableRow, String> CreditCard;
	/**
	 * UserType Column
	 */
	@FXML
	private TableColumn<TableRow, String> UserType;
	/**
	 * Confirm Column
	 */
	@FXML
	private TableColumn<TableRow, Button> Confirm;
	/**
	 * DECLINE Column
	 */
	@FXML
	private TableColumn<TableRow, Button> Decline;
	// Columns END//

	/**
	 * Method for initializing our current page our table - RegistrationsTable -
	 * will be initialized using multiple instances of our TableRow class
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		IDDownPageArea.setText(AreaManagerInterfaceController.workingarea);
		getAndBuildDataDB();
	}

	/**
	 * Method to get the needed data from the data base and build the view 
	 * in the table view using the data that we took
	 */
	private void getAndBuildDataDB() {
		ClientMethods.SendMessage(Commands.GetAllCustomersRegistirations, "Nothing");
		ArrayList<ArrayList<Object>> CustomerRegistrationsArr = ChatClient.CustomerRegistrationsArr;

		data = FXCollections.observableArrayList();
		// Loop to Traverse over all the elements in the array
		for (ArrayList<Object> arr : CustomerRegistrationsArr) {
			// check registration status if it needs review show in the table
			String registirationsstatus = (String) (arr.get(10));
			if (registirationsstatus.equals("Needs Review")) {
				// check customer type
				String customertype = new String();
				if (((String) (arr.get(9))).equals("NO"))
					customertype = "Costumer";
				else
					customertype = "Subscriber";
				// make new table row and add it to the table
				TableRow RowToAdd = new TableRow((String) (arr.get(4)), (String) (arr.get(5)), (String) (arr.get(7)),
						(String) (arr.get(8)), (String) (arr.get(6)), customertype, null, null);
				RowToAdd.setApproveButton(MakeApproveButton((Integer) (arr.get(0)), RowToAdd, arr)); // set the Approve
																										// Button
				RowToAdd.setDisApproveButton(MakeDisApproveButton((Integer) (arr.get(0)), RowToAdd, arr)); // set the
																											// DisApprove
																											// Button
				data.add(RowToAdd);
			}

		}

		FirstName.setCellValueFactory(new PropertyValueFactory<>("FirstName"));
		LastName.setCellValueFactory(new PropertyValueFactory<>("LastName"));
		Email.setCellValueFactory(new PropertyValueFactory<>("Email"));
		PhoneNumber.setCellValueFactory(new PropertyValueFactory<>("PhoneNumber"));
		CreditCard.setCellValueFactory(new PropertyValueFactory<>("CreditCard"));
		UserType.setCellValueFactory(new PropertyValueFactory<>("UserType"));
		Confirm.setCellValueFactory(new PropertyValueFactory<>("ApproveButton"));
		Decline.setCellValueFactory(new PropertyValueFactory<>("DisApproveButton"));
		RegistrationsTable.setItems(data);
	}
	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event on clicking close icon
	 * @throws Exception exception if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}

	/**
	 * Method for showing help information, a popup with explanation of current page
	 * will show up to the user
	 * 
	 * @param event event in clicking help icon
	 * @throws Exception exception if an error occurs
	 */

	public void help(MouseEvent event) throws Exception {
		CommonMethods.help("This is the Review Customer Registraion Page"
				+ "\nYou can Approve the Customer by Clicking on Approve Button"
				+ "\nYou can DisApprove the Customer by Clicking on DisApprove Button", getClass());

	}


	/**
	 * Method for going back to the page that precedes the current page
	 * @param event event on clicking back arrow
	 * @throws Exception exception if an error occurs
	 */
	public void back(MouseEvent event) throws Exception // close window
	{
		CommonMethods.switchSceneBack(getClass(), event);
	}

	/**
	 * Method to create and connect a Approve button
	 * 
	 * @param Registirationid the id
	 * @param row             the row
	 * @param Customerinfo    the customer information
	 * @return return Approve Button
	 */
	public Button MakeApproveButton(int Registirationid, TableRow row, ArrayList<Object> Customerinfo) {
		Button approvebtn = new Button("Approve");
		approvebtn.requestFocus();
		approvebtn.setOnMouseClicked(event -> {
			ClientMethods.SendMessage(Commands.UpdateCustomerRegistirationStatus, Registirationid);
			// check customer type
			String customertype = new String();
			if (((String) (Customerinfo.get(9))).equals("NO"))
				customertype = "Costumer";
			else
				customertype = "Subscriber";
			Customerinfo.set(9, customertype);

			ClientMethods.SendMessage(Commands.AddNewCustomer, Customerinfo);

			data.remove(row);
		});
		approvebtn.setStyle("-fx-background-radius: 50;" + "-fx-background-color: #90BB14;" + "-fx-font-weight:bold;"
				+ "-fx-font-size: 12px;" + "-fx-effect: dropshadow( three-pass-box , #A2A09F, 13, 0 , 7 , 7 );"
				+ "-fx-text-fill: white;");
		return approvebtn;
	}

	/**
	 * Method to create and connect a DisApprove button
	 * 
	 * @param Registirationid the id
	 * @param row             the row
	 * @param Customerinfo    the customer information
	 * @return return DisApprove Button
	 */
	public Button MakeDisApproveButton(int Registirationid, TableRow row, ArrayList<Object> Customerinfo) {
		Button approvebtn = new Button("DisApprove");
		approvebtn.requestFocus();
		approvebtn.setOnMouseClicked(event -> {
			ClientMethods.SendMessage(Commands.UpdateCustomerRegistirationStatusToNotApproved, Registirationid);
			data.remove(row);
		});
		approvebtn.setStyle("-fx-background-radius: 50;" + "-fx-background-color: #90BB14;" + "-fx-font-weight:bold;"
				+ "-fx-font-size: 12px;" + "-fx-effect: dropshadow( three-pass-box , #A2A09F, 13, 0 , 7 , 7 );"
				+ "-fx-text-fill: white;");
		return approvebtn;
	}

	/**
	 * This class is a TableRow for the table which the users registered and
	 * awaiting confrimation will be displayed parameters of the class are
	 * FirstName, LastName, Email, PhoneNumber, CreditCard, UserType another
	 * variable is a Button, this button will be used to confirm said user all these
	 * variables are defining details of our user the class has a constructor that
	 * allows us to set the data through it, we also have getters and setters for
	 * each variables as well we use this class mainly to add each instance into a
	 * row of the table we have
	 * 
	 * @author amran
	 * @author Mahran
	 *
	 */
	public class TableRow { // class for table of request we can make

		/**
		 * to save information
		 */
		private SimpleStringProperty FirstName, LastName, Email, PhoneNumber, CreditCard, UserType;
		/**
		 * for approve Button
		 */
		private Button ApproveButton;
		/**
		 * for disApprove button
		 */
		private Button DisApproveButton;

		/**
		 * Constructor for creating a TableRow object with the given user information
		 * and action buttons.
		 * 
		 * @param firstName        the user's first name.
		 * @param lastName         the user's last name.
		 * @param email            the user's email.
		 * @param phoneNumber      the user's phone number.
		 * @param creditCard       the user's credit card.
		 * @param userType         the user's type.
		 * @param approveButton    the approve button.
		 * @param disApproveButton the disapprove button.
		 */
		public TableRow(String firstName, String lastName, String email, String phoneNumber, String creditCard,
				String userType, Button approveButton, Button disApproveButton) {
			super();
			this.FirstName = new SimpleStringProperty(firstName);
			this.LastName = new SimpleStringProperty(lastName);
			this.Email = new SimpleStringProperty(email);
			this.PhoneNumber = new SimpleStringProperty(phoneNumber);
			this.CreditCard = new SimpleStringProperty(creditCard);
			this.UserType = new SimpleStringProperty(userType);
			ApproveButton = approveButton;
			DisApproveButton = disApproveButton;

		}

		/**
		 * Gets the firstName property
		 * 
		 * @return the FirstName
		 */
		public String getFirstName() {
			return this.FirstName.get();
		}

		/**
		 * Sets the FirstName property.
		 * 
		 * @param firstName the FirstName to set
		 */
		public void setFirstName(String firstName) {
			this.FirstName.set(firstName);
		}

		/**
		 * Gets the LastName property
		 * 
		 * @return the LastName
		 */
		public String getLastName() {
			return this.LastName.get();
		}


		/**
		 * Sets the lastName property.
		 * @param lastName LastName the LastName to set
		 */
		public void setLastName(String lastName) {
			this.LastName.set(lastName);
		}

		/**
		 * Gets the Email property
		 * 
		 * @return the Email
		 */
		public String getEmail() {
			return this.Email.get();
		}

		/**
		 * Sets the Email property.
		 * 
		 * @param email the Email to set
		 */
		public void setEmail(String email) {
			this.Email.set(email);
		}

		/**
		 * Gets the PhoneNumber property.
		 * 
		 * @return the PhoneNumber
		 */
		public String getPhoneNumber() {
			return this.PhoneNumber.get();
		}

		/**
		 * 
		 * Sets the PhoneNumber property.
		 * 
		 * @param phoneNumber the PhoneNumber to set
		 */
		public void setPhoneNumber(String phoneNumber) {
			this.PhoneNumber.set(phoneNumber);
		}

		/**
		 * Gets the CreditCard property.
		 * 
		 * @return the CreditCard property.
		 */
		public String getCreditCard() {
			return this.CreditCard.get();
		}

		/**
		 * Sets the CreditCard property.
		 * 
		 * @param creditCard the creditCard to set
		 */
		public void setCreditCard(String creditCard) {
			this.CreditCard.set(creditCard);
		}

		/**
		 * Gets the UserType property.
		 * 
		 * @return the UserType property.
		 */
		public String getUserType() {
			return this.UserType.get();
		}

		/**
		 * Sets the UserType property.
		 * 
		 * @param userType the userType to set
		 */
		public void setUserType(String userType) {
			this.UserType.set(userType);
		}

		/**
		 * Gets the ApproveButton.
		 * 
		 * @return the ApproveButton
		 */
		public Button getApproveButton() {
			return ApproveButton;
		}

		/**
		 * Sets the ApproveButton.
		 * 
		 * @param approveButton the approveButton to set
		 */
		public void setApproveButton(Button approveButton) {
			ApproveButton = approveButton;
		}

		/**
		 * Gets the DisApproveButton.
		 * 
		 * @return the DisApproveButton
		 */
		public Button getDisApproveButton() {
			return DisApproveButton;
		}

		/**
		 * Sets the DisApproveButton.
		 * 
		 * @param disApproveButton the disApproveButton to set
		 */
		public void setDisApproveButton(Button disApproveButton) {
			DisApproveButton = disApproveButton;
		}

	}

}
