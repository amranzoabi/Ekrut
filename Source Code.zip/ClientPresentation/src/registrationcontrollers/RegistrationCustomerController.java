package registrationcontrollers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * This Class is a Customer Registration Page Controller for
 * RegistrationCustomer.fxml ,it runs all the methods that functions the
 * Register of Customer Note: this class uses help from CommonMethods class
 * 
 * @author Mohamed
 *
 */
public class RegistrationCustomerController implements Initializable {

	/**
	 * Label used to display credit card number
	 */
	@FXML
    private Label IDLabelCard;

    /**
     * Label used to display email
     */
    @FXML
    private Label IDLabelEmail;

    /**
     * Label used to display first name
     */
    @FXML
    private Label IDLabelFirst;

    /**
     * Label used to display last name
     */
    @FXML
    private Label IDLabelLast;

    /**
     * Label used to display ID number
     */
    @FXML
    private Label IDLabelNumber;

    /**
     * Label used to display passowrd
     */
    @FXML
    private Label IDLabelPassword;

    /**
     * Label used to display phone number
     */
    @FXML
    private Label IDLabelPhone;

    /**
     * Label used to display user name
     */
    @FXML
    private Label IDLabelUsername;
	/**
	 * Label to show error message
	 */
	@FXML
	private Label errorLabel;
	/**
	 * TextField to get the first name
	 */
	@FXML
	private TextField firstNameID;
	/**
	 * TextField to get the last name
	 */
	@FXML
	private TextField lastNameID;
	/**
	 * TextField to get the ID number
	 */
	@FXML
	private TextField idNumberID;
	/**
	 * TextField to get the phone number
	 */
	@FXML
	private TextField phoneNumberID;
	/**
	 * TextField to get the email
	 */
	@FXML
	private TextField emailID;
	/**
	 * TextField to get the credit card number
	 */
	@FXML
	private TextField creditCardID;
	/**
	 * TextField to get the user name
	 */
	@FXML
	private TextField UsernameID;
	/**
	 * TextField to get the password
	 */
	@FXML
	private TextField PasswordID;
	/**
	 * ComboBox to save/show the types
	 */
	@FXML
	ComboBox<String> IDTypeBox;

	/**
	 * initialize all the data needed in that class
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		setImportantLabel();
		ObservableList<String> type = FXCollections.observableArrayList(Arrays.asList("Regular", "Subscriber"));
		IDTypeBox.setItems(type);
		checkInput();
	}

	/**
	 * Method to create and save the Worker in Data Base by clicking on Sign Up
	 * Button in case any field is empty an error message/label would be thrown
	 * 
	 * @param event event of Clicking on Sign Up Button
	 * @throws IOException IOException will be throws if there is an error
	 */
	public void submitRegister(ActionEvent event) throws IOException {
		String firstName = firstNameID.getText();
		String lastName = lastNameID.getText();
		String username = UsernameID.getText();
		String password = PasswordID.getText();
		String idNumber = idNumberID.getText();
		String phoneNumber = phoneNumberID.getText();
		String email = emailID.getText();
		String creditCard = creditCardID.getText();
		String type = IDTypeBox.getValue();

		if (type != null && type.equals("Regular"))
			type = "NO";
		else if (type != null && type.equals("Subscriber"))
			type = "YES";

		if (IDTypeBox.getValue() == null || firstName.isEmpty() || lastName.isEmpty() || idNumber.isEmpty()
				|| phoneNumber.isEmpty() || email.isEmpty() || creditCard.isEmpty() || username.isEmpty()
				|| password.isEmpty() || idNumber.length() != 10) {
			errorLabel.setText("You must fill all fields correctly before signning up");
			clearFields();
		} else {
			boolean flag = false;
			String tableToSend = "customer";
			ClientMethods.SendMessage(Commands.getRegestrationIDNumber, tableToSend);
			ArrayList<ArrayList<Object>> data = new ArrayList<>();
			data = ChatClient.regesterIDNumberArr;
			for (int i = 0; i < data.size(); i++)
				if (data.get(i).get(0).equals(idNumber))
					flag = true;

			if (flag == false) {
				errorLabel.setText("");
				ArrayList<String> DataToSend = new ArrayList<String>(Arrays.asList(idNumber, username, password,
						firstName, lastName, creditCard, email, phoneNumber, type));
				ClientMethods.SendMessage(Commands.RegisterNewCustomer, DataToSend);
				CommonMethods.CompletionMessage(
						"Customer registration has been added needs review from the area manager", getClass());
				flag = true;
				clearFields();
			} else
				errorLabel.setText("this customer ID already registered");

		}
	}

	/**
	 * Method for clicking the help icon ,a windows will show with a message and
	 * explain the scene/page
	 * 
	 * @param event event of the help icon clicked the scene/page and what every
	 *              button do
	 * @throws Exception Exception will be thrown if an error occurs from Customer
	 *                   class
	 */
	public void help(MouseEvent event) throws Exception {
		CommonMethods.help(
				"This is a Customer Registiration Page:"
						+ "\nBy filling all fields and clicking sign up you will register the new Customer",
				getClass());

	}

	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}

	/**
	 * Method for going back to the previous page in this case the Service Agent
	 * Page
	 * 
	 * @param event event if the the arrow (back) icon clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void back(MouseEvent event) throws Exception // close window
	{
		CommonMethods.switchSceneBack(getClass(), event);
	}

	/**
	 * Method to clear all input fields (Text fields)
	 */
	private void clearFields() {
		firstNameID.clear();
		lastNameID.clear();
		idNumberID.clear();
		phoneNumberID.clear();
		emailID.clear();
		creditCardID.clear();
		UsernameID.clear();
		PasswordID.clear();

	}

	/**
	 * Method to check input legality
	 */
	private void checkInput() {
		CommonMethods.textLegality(idNumberID, 10);
		CommonMethods.textLegality(phoneNumberID, 10);
		CommonMethods.textLegality(creditCardID, 16);
		CommonMethods.textLengthLegality(firstNameID, 20);
		CommonMethods.textLengthLegality(lastNameID, 20);
		CommonMethods.textLengthLegality(UsernameID, 20);
		CommonMethods.textLengthLegality(emailID, 30);
		CommonMethods.textLengthLegality(PasswordID, 20);
	}
	 /**
	 * This method sets the "*" before the text of the IDLabelCvv, IDLabelName, 
	 * IDLabelCard and IDLabelDate to indicate that these labels are important.
	 */
	private void setImportantLabel() {
		CommonMethods.importantLabel(IDLabelFirst);
		CommonMethods.importantLabel(IDLabelLast);
		CommonMethods.importantLabel(IDLabelCard);
		CommonMethods.importantLabel(IDLabelUsername);
		CommonMethods.importantLabel(IDLabelPassword);
		CommonMethods.importantLabel(IDLabelNumber);
		CommonMethods.importantLabel(IDLabelEmail);
		CommonMethods.importantLabel(IDLabelPhone);
	}
	/**
	 * Method to activate the ability of moving between text fields by 
	 * clicking on TAB key (keyboard)
	 * @param event event on clicking on text field
	 */
	public void activateTab(MouseEvent event) {
		idNumberID.setFocusTraversable(true);
		firstNameID.setFocusTraversable(true);
		lastNameID.setFocusTraversable(true);
		phoneNumberID.setFocusTraversable(true);
		emailID.setFocusTraversable(true);
		creditCardID.setFocusTraversable(true);
		UsernameID.setFocusTraversable(true);
		PasswordID.setFocusTraversable(true);
		
		   
	    }
}
