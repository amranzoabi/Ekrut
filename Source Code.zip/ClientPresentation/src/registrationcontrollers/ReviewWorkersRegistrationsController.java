package registrationcontrollers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import homepagescontrollers.AreaManagerInterfaceController;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

/**
 * This class is a Review Registrations Controller for
 * ReviewRegistrationsPage.fxml the function of this class is to display all
 * registrations that are awaiting review the reviewing is done by the area
 * manager associated with the users, the area manager is shown a table (list)
 * with users that are awaiting confirmation each row in this table shows
 * information of user awaiting confirmation, the area manager is given the
 * option to either confirm or reject given user This class also uses other
 * classes to help manage the properties one of the classes is TableRow - which
 * helps us add rows to our table of users registered
 * 
 * @author amran
 * @author mohamad
 *
 */
public class ReviewWorkersRegistrationsController implements Initializable {
	/**
	 * to save/show area
	 */
	@FXML
	private Label IDDownPageArea;

	/**
	 * the list that shows on the table
	 */
	public ObservableList<TableRow> data;
	/**
	 * This is our main table in which our users will be displayed in for the
	 * manager to confirm/reject initialization of this table is in the initialize
	 * function at the bottom of the page
	 */
	@FXML
	private TableView<TableRow> RegistrationsTable;

	// Columns START//
	/**
	 * FirstName Column
	 */
	@FXML
	private TableColumn<TableRow, String> FirstName;
	/**
	 * LastName Column
	 */
	@FXML
	private TableColumn<TableRow, String> LastName;
	/**
	 * Email Column
	 */
	@FXML
	private TableColumn<TableRow, String> Email;
	/**
	 * PhoneNumber Column
	 */
	@FXML
	private TableColumn<TableRow, String> PhoneNumber;
	/**
	 * CreditCard Column
	 */
	@FXML
	private TableColumn<TableRow, String> CreditCard;
	/**
	 * UserType Column
	 */
	@FXML
	private TableColumn<TableRow, String> UserType;
	/**
	 * Confirm Column
	 */
	@FXML
	private TableColumn<TableRow, Button> Confirm;
	/**
	 * DECLINE Column
	 */
	@FXML
	private TableColumn<TableRow, Button> Decline;

	// Columns END//
	/**
	 * Method for initializing our current page our table - RegistrationsTable -
	 * will be initialized using multiple instances of our TableRow class
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		IDDownPageArea.setText(AreaManagerInterfaceController.workingarea);
		getAndBuildDataDB();

	}

	/**
	 * Method to get the needed data from the data base and build the view 
	 * in the table view using the data that we took
	 */
	private void getAndBuildDataDB() {
		ClientMethods.SendMessage(Commands.GetAllWorkersRegistirations, "Nothing");
		ArrayList<ArrayList<Object>> WorkerRegistrationsArr = ChatClient.WorkerRegistrationsArr;

		data = FXCollections.observableArrayList();
		// Loop to Traverse over all the elements in the array
		for (ArrayList<Object> arr : WorkerRegistrationsArr) {
			if (((String) (arr.get(10)) + "").equals(AreaManagerInterfaceController.workingarea)) {
				// check registration status if it needs review show in the table
				String registirationsstatus = (String) (arr.get(11));
				String role =(String)(arr.get(9));
				if (registirationsstatus.equals("Needs Review")) 
					if(!role.equals("Area Manager") && !role.equals("CEO")) { // check if the role isnt area manager or ceo
					// make new table row and add it to the table
					TableRow RowToAdd = new TableRow((String) (arr.get(4)), (String) (arr.get(5)),
							(String) (arr.get(7)), (String) (arr.get(8)), (String) (arr.get(6)),
							((String) (arr.get(9))), null, null);

					RowToAdd.setApproveButton(MakeApproveButton((Integer) (arr.get(0)), RowToAdd, arr)); // set the
																											// Approve
																											// Button
					RowToAdd.setDisApproveButton(MakeDisApproveButton((Integer) (arr.get(0)), RowToAdd, arr)); // set
																												// the
																												// DisApprove
																												// Button
					data.add(RowToAdd);
				}
			}

		}

		FirstName.setCellValueFactory(new PropertyValueFactory<>("FirstName"));
		LastName.setCellValueFactory(new PropertyValueFactory<>("LastName"));
		Email.setCellValueFactory(new PropertyValueFactory<>("Email"));
		PhoneNumber.setCellValueFactory(new PropertyValueFactory<>("PhoneNumber"));
		CreditCard.setCellValueFactory(new PropertyValueFactory<>("CreditCard"));
		UserType.setCellValueFactory(new PropertyValueFactory<>("UserType"));
		Confirm.setCellValueFactory(new PropertyValueFactory<>("ApproveButton"));
		Decline.setCellValueFactory(new PropertyValueFactory<>("DisApproveButton"));
		RegistrationsTable.setItems(data);
	}
	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event on clicking the X close icon
	 * @throws Exception exception if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}

	/**
	 * Method for showing help information, a popup with explanation of current page
	 * will show up to the user
	 * 
	 * @param event event on clicking the help icon
	 * @throws Exception exception if an error occurs
	 */

	public void help(MouseEvent event) throws Exception {
		CommonMethods.help("This is the Review Customer Registraion Page"
				+ "\nYou can Approve the Customer by Clicking on Approve Button"
				+ "\nYou can DisApprove the Customer by Clicking on DisApprove Button", getClass());
	}

	/**
	 * Method for going back to the page that precedes the current page
	 * 
	 * @param event event on clicking the back arrow icon
	 * @throws Exception exception if an error occurs
	 */
	public void back(MouseEvent event) throws Exception // close window
	{
		CommonMethods.switchSceneBack(getClass(), event);
	}

	/**
	 * Method to create and connect a Approve button
	 * 
	 * @param Registirationid the id
	 * @param row             the row
	 * @param Workerinfo    the customer information
	 * @return return Approve Button
	 */
	public Button MakeApproveButton(int Registirationid, TableRow row, ArrayList<Object> Workerinfo) {
		Button approvebtn = new Button("Approve");
		approvebtn.requestFocus();
		approvebtn.setOnMouseClicked(event -> {
			ClientMethods.SendMessage(Commands.UpdateWorkerRegistirationStatus, Registirationid);
			ClientMethods.SendMessage(Commands.AddNewWorker, Workerinfo);
			data.remove(row);
		});
		approvebtn.setStyle("-fx-background-radius: 50;" + "-fx-background-color: #90BB14;" + "-fx-font-weight:bold;"
				+ "-fx-font-size: 12px;" + "-fx-effect: dropshadow( three-pass-box , #A2A09F, 13, 0 , 7 , 7 );"
				+ "-fx-text-fill: white;");
		return approvebtn;
	}

	/**
	 * Method to create and connect a DisApprove button
	 * 
	 * @param Registirationid the id
	 * @param row             the row
	 * @param Customerinfo    the customer information
	 * @return return DisApprove Button
	 */
	public Button MakeDisApproveButton(int Registirationid, TableRow row, ArrayList<Object> Customerinfo) {
		Button approvebtn = new Button("DisApprove");
		approvebtn.requestFocus();
		approvebtn.setOnMouseClicked(event -> {
			ClientMethods.SendMessage(Commands.UpdateWorkerRegistirationStatusToNotApproved, Registirationid);
			data.remove(row);
		});
		approvebtn.setStyle("-fx-background-radius: 50;" + "-fx-background-color: #90BB14;" + "-fx-font-weight:bold;"
				+ "-fx-font-size: 12px;" + "-fx-effect: dropshadow( three-pass-box , #A2A09F, 13, 0 , 7 , 7 );"
				+ "-fx-text-fill: white;");
		return approvebtn;
	}

	/**
	 * This class is a TableRow for the table which the users registered and
	 * awaiting confrimation will be displayed parameters of the class are
	 * FirstName, LastName, Email, PhoneNumber, CreditCard, UserType another
	 * variable is a Button, this button will be used to confirm said user all these
	 * variables are defining details of our user the class has a constructor that
	 * allows us to set the data through it, we also have getters and setters for
	 * each variables as well we use this class mainly to add each instance into a
	 * row of the table we have
	 * 
	 * @author amran
	 *
	 */
	public class TableRow { // class for table of request we can make

		/**
		 * to save information
		 */
		private SimpleStringProperty FirstName, LastName, Email, PhoneNumber, CreditCard, UserType;
		/**
		 * for Approve Button
		 */
		private Button ApproveButton;
		/**
		 * for DisAprrove Button
		 */
		private Button DisApproveButton;

		/**
		 * Constructs a new TableRow object with the specified first name, last name,
		 * email, phone number, credit card, user type, approve button, and disapprove
		 * button.
		 * 
		 * @param firstName        the first name of the user
		 * @param lastName         the last name of the user
		 * @param email            the email of the user
		 * @param phoneNumber      the phone number of the user
		 * @param creditCard       the credit card number of the user
		 * @param userType         the type of user (e.g. "admin", "regular")
		 * @param approveButton    a button to approve the user
		 * @param disApproveButton a button to disapprove the user
		 */
		public TableRow(String firstName, String lastName, String email, String phoneNumber, String creditCard,
				String userType, Button approveButton, Button disApproveButton) {
			super();
			this.FirstName = new SimpleStringProperty(firstName);
			this.LastName = new SimpleStringProperty(lastName);
			this.Email = new SimpleStringProperty(email);
			this.PhoneNumber = new SimpleStringProperty(phoneNumber);
			this.CreditCard = new SimpleStringProperty(creditCard);
			this.UserType = new SimpleStringProperty(userType);
			ApproveButton = approveButton;
			DisApproveButton = disApproveButton;

		}

		/**
		 * Returns the first name of the person.
		 * 
		 * @return the first name
		 */
		public String getFirstName() {
			return this.FirstName.get();
		}

		/**
		 * Sets the first name of the person.
		 * 
		 * @param firstName the first name to set
		 */
		public void setFirstName(String firstName) {
			this.FirstName.set(firstName);
		}

		/**
		 * Returns the last name of the person.
		 * 
		 * @return the last name
		 */
		public String getLastName() {
			return this.LastName.get();
		}

		/**
		 * Sets the last name of the person.
		 * 
		 * @param lastName the last name to set
		 */
		public void setLastName(String lastName) {
			this.LastName.set(lastName);
		}

		/**
		 * Returns the email of the person.
		 * 
		 * @return the email
		 */
		public String getEmail() {
			return this.Email.get();
		}

		/**
		 * Sets the email of the person.
		 * 
		 * @param email the email to set
		 */
		public void setEmail(String email) {
			this.Email.set(email);
		}

		/**
		 * Returns the phone number of the person.
		 * 
		 * @return the phone number
		 */
		public String getPhoneNumber() {
			return this.PhoneNumber.get();
		}

		/**
		 * Sets the phone number of the person.
		 * 
		 * @param phoneNumber the phone number to set
		 */
		public void setPhoneNumber(String phoneNumber) {
			this.PhoneNumber.set(phoneNumber);
		}

		/**
		 * Returns the credit card of the person.
		 * 
		 * @return the CreditCard
		 */
		public String getCreditCard() {
			return this.CreditCard.get();
		}


		/**
		 * @param creditCard the creditCard to set
		 */
		public void setCreditCard(String creditCard) {
			this.CreditCard.set(creditCard);
		}

		/**
		 * Returns the User Type of the person.
		 * 
		 * @return the UserType
		 */
		public String getUserType() {
			return this.UserType.get();
		}

		/**
		 * Sets the user type
		 * 
		 * @param userType the UserType to set
		 */
		public void setUserType(String userType) {
			this.UserType.set(userType);
		}

		/**
		 * Gets the ApproveButton.
		 * 
		 * @return the ApproveButton
		 */
		public Button getApproveButton() {
			return ApproveButton;
		}

		/**
		 * Sets the ApproveButton.
		 * 
		 * @param approveButton the approveButton to set
		 */
		public void setApproveButton(Button approveButton) {
			ApproveButton = approveButton;
		}

		/**
		 * Gets the DisApproveButton.
		 * 
		 * @return the DisApproveButton
		 */
		public Button getDisApproveButton() {
			return DisApproveButton;
		}

		/**
		 * Sets the DisApproveButton.
		 * 
		 * @param disApproveButton the disApproveButton to set
		 */
		public void setDisApproveButton(Button disApproveButton) {
			DisApproveButton = disApproveButton;
		}

	}

}
