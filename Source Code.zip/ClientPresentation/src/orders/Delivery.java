package orders;

/**
 * This class is a delivery information class, to save the delivery information
 * of the customer
 * 
 * @author Mahran
 *
 */
public class Delivery {
	/**
	 * to save the first name
	 */
	private String firstName;
	/**
	 * to save the last name
	 */
	private String lastName;
	/**
	 * to save the phone number
	 */
	private String phoneNumber;
	/**
	 * to save the house number
	 */
	private String houseNumber;
	/**
	 * to save the street address
	 */
	private String street;

	/**
	 * to save the area
	 */
	private String area;

	/**
	 * to save the location
	 */
	private String Location;

	/**
	 * constructor to initialize the data
	 * 
	 * @param firstName   first name of the customer
	 * @param lastName    last name of the customer
	 * @param phoneNumber phone number of the customer
	 * @param houseNumber house number of the customer
	 * @param street      street address of the customer
	 * @param area        area of the delivery address
	 * @param location    of the delivery address
	 */
	public Delivery(String firstName, String lastName, String phoneNumber, String houseNumber, String street,
			String area, String location) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.houseNumber = houseNumber;
		this.street = street;
		this.area = area;
		this.Location = location;
	}

	/**
	 * Method to get the first name
	 * 
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Method to get the last name
	 * 
	 * @return LastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Method to get the phone number
	 * 
	 * @return phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Method to get the house number
	 * 
	 * @return houseNumber
	 */
	public String getHouseNumber() {
		return houseNumber;
	}

	/**
	 * Method to get the street
	 * 
	 * @return street
	 */
	public String getStreet() {
		return street;
	}

	/**
	 * Method to get the location
	 * 
	 * @return return this location
	 */
	public String getLocation() {
		return Location;
	}

	/**
	 * Method to get the area
	 * 
	 * @return return this area
	 */
	public String getArea() {
		return area;
	}

	/**
	 * Method to clear all fields in that class
	 */
	public void clear() {
		firstName = null;
		lastName = null;
		phoneNumber = null;
		houseNumber = null;
		street = null;
	}

}
