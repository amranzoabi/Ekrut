package othercontrollers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import client.LogOutTimer;
import common.Commands;
import common.CommonMethods;
import customermethods.Customer;
import homepagescontrollers.AreaManagerInterfaceController;
import homepagescontrollers.CEOInterfaceController;
import homepagescontrollers.CustomerPageInterFaceController;
import homepagescontrollers.DeliveryOperatorController;
import homepagescontrollers.MarketingManagerController;
import homepagescontrollers.MarketingWorkerController;
import homepagescontrollers.OPWorkerHomepageController;
import homepagescontrollers.ServiceAgentController;
import interfaces.CloseablePage;
import interfaces.SetableHomepage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import orders.Order;
import producereportscontrollers.AreaManager;

/**
 * This Class is a Login Page Controller for LoginHomePage.fxml ,it runs all the
 * methods that functions the choices of the user
 * 
 * @author Shadi
 * @author Mahran
 *
 */
public class LoginInterFaceController implements CloseablePage, Initializable {
	/**
	 * to save SmartPhone(ImageView) yOffset
	 */
	private double xOffset = 0;
	/**
	 * to save SmartPhone(ImageView) yOffset
	 */

	private double yOffset = 0;
	/**
	 * ImageView for the smart phone image
	 */
	@FXML
	private AnchorPane IDSmartPhone;

	/**
	 * TextField to get the password
	 */
	@FXML
	private PasswordField passwordID;

	/**
	 * TextField to get the user Name
	 */
	@FXML
	private TextField usernameID;

	/**
	 * Label to show error message
	 */
	@FXML
	private Label errorLabel;
	/**
	 * to get the order code from customer
	 */
	@FXML
	private TextField IDOrderCode;
	/**
	 * to show message on machine
	 */
	@FXML
	private Label IDMachineMsg;

	/**
	 * to get the phone user
	 */
	@FXML 
	private TextField IDPhoneUser;
	
	/**
	 * to save the user type
	 */
	private String UserType;
	/**
	 * to save the user ID
	 */
	private String UserID ;
	/**
	 * to save the user name
	 */
	private String UserName ;
	/**
	 * to save is logged in
	 */
	private String isLoggedin ;
	/**
	 * to save the customer ID
	 */
	private String CostumerID ;
	/**
	 * to save the email address
	 */
	private String EmailAddress ;
	/**
	 * to save the phone number
	 */
	private String PhoneNumber ;
	/**
	 * to save is logged
	 */
	private int IsLogged;
	/**
	 * to save user name
	 */
	private String username ;
	/**
	 * to save password
	 */
	private String password;
	/**
	 * to save area
	 */
	private String Area;
	
	@FXML
	private Button loginBtn;
	/**
	 * to initialize the length of input
	 *
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	
		CommonMethods.textLengthLegality(usernameID, 20);
		CommonMethods.textLengthLegality(passwordID, 20);
		CommonMethods.textLengthLegality(IDOrderCode, 3);
		CommonMethods.continueWithEnter(usernameID,loginBtn);
		CommonMethods.continueWithEnter(passwordID,loginBtn);
	}


	/**
	 * Method for clicking the Login Button ,switches stage to the next page(depends
	 * on the type of user) checks the type of user and if he exists in the data
	 * base and then switches the stage/scene in case the user doesn't exist in the
	 * data base or fields aren't filled an error message would be thrown
	 * 
	 * @param event event of the Create Sale Button clicked
	 * @throws IOException IOException will be thrown if an error occurs
	 */
	public void login(ActionEvent event) throws IOException {
		errorLabel.setText("");
		username = usernameID.getText();
		password = passwordID.getText();

		// Step 1 : Check if user inputing legal username and password
		if (username.equals("") || password.equals(""))
			{
				errorLabel.setText("Please enter your username and password\n correctly");
				usernameID.clear();
				passwordID.clear();
				
			}

		else {
			// Step 2 : send the data to the server for check
			ClientMethods.SendMessage(Commands.Login, username + "/" + password);

			// LoginAnswer returns in the following form [loginanswer,usertype,userID,user
			// FirstName}
			if ((ChatClient.LoginAnswer.get(0)).equals("false")) {
				System.out.println("user not found");
				errorLabel.setText("You entered incorrect username or password");

			} else {
				resetPage();
				getLoginInfoDB();
				Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

				stage.setOnCloseRequest(closeEvent -> { // logout from the account if the user closed the window
					ClientMethods.LogOut();
				});

				SetableHomepage hp;

				if (IsLogged != 1) // enter the switch statment only if the user not logged in
				{
					activateTimer();
					usernameID.clear();
					passwordID.clear();
					loginBtn.setFocusTraversable(true);
					
					
					switch (UserType) {
					case "Costumer":
						stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
						hp = (CustomerPageInterFaceController) CommonMethods.switchScene(getClass(), stage,
								"CustomerPage.fxml", "CustomerInterface.css");
						hp.SetPageInfo(UserName, "Customer ID: " + CostumerID, "Customer");
						Order.customerID = ChatClient.LoginAnswer.get(6); // save the customer id for the payment
						Order.customerType = UserType;
						break;
					case "Subscriber":
						stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
						hp = (CustomerPageInterFaceController) CommonMethods.switchScene(getClass(), stage,
								"CustomerPage.fxml", "CustomerInterface.css");
						hp.SetPageInfo(UserName, "Customer ID: " + CostumerID, UserType);	
						Order.customerType = UserType;
						Order.customerID = ChatClient.LoginAnswer.get(6); // save the customer id for the payment
						
						break;
						

					case "Area Manager":
						stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
						hp = (AreaManagerInterfaceController) CommonMethods.switchScene(getClass(), stage,
								"AreaManagerPage.fxml", "AreaManagerInterface.css");
						hp.SetPageInfo(UserName, "User ID: " + UserID, "Area: " + Area);
						AreaManager.setArea(Area);
						
						break;

					case "Service Agent":
						stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
						hp = (ServiceAgentController) CommonMethods.switchScene(getClass(), "ServiceAgentHomepage.fxml",
								"ServiceAgentInterface.css", event);
						hp.SetPageInfo(UserName, "User ID: " + UserID, Area);
						break;

					case "Marketing Manager":
						stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
						hp = (MarketingManagerController) CommonMethods.switchScene(getClass(), stage,
								"MarketingManagerHomepage.fxml", "MarketingManagerPageInterface.css");
						hp.SetPageInfo(UserName, "User ID: " + UserID, "");
						break;

					case "Marketing Worker":
						stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
						hp = (MarketingWorkerController) CommonMethods.switchScene(getClass(), stage,
								"MarketingWorkerHomepage.fxml", "MarktingWorkerPageInterface.css");
						hp.SetPageInfo(UserName, "User ID: " + UserID, "Area: " + Area);
						break;

					case "Delivery Operator":
						stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
						hp = (DeliveryOperatorController) CommonMethods.switchScene(getClass(), stage,
								"DeliveryOperatorHomepage.fxml", "DeliveryOperatorPageInterface.css");
						hp.SetPageInfo(UserName, "User ID: " + UserID, "Area: " + Area);
						break;

					case "CEO":
						stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
						hp = (CEOInterfaceController) CommonMethods.switchScene(getClass(), stage, "CEOPage.fxml",
								"CEOInterface.css");
						hp.SetPageInfo(UserName, "User ID: " + UserID, "");
						break;

					case "Operations Worker":
						stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
						hp = (OPWorkerHomepageController) CommonMethods.switchScene(getClass(), stage,
								"OperationsWorkerPage.fxml", "OPWorkerInterface.css");
						hp.SetPageInfo(UserName, "User ID: " + UserID, "Area: " + Area);
						break;
						
					}
		
				} else
					{
						errorLabel.setText("This user is Already Logged in the system");
						passwordID.clear();
					}
					
			}
		}
		
	}

	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}

	/**
	 * Method for Login in via smart phone to the system ,this method will activate
	 * by clicking on the key icon (on the vending machine) this method also allows
	 * the the movement of the smart phone image and checks when the smart phone is
	 * on top of the key icon(like a sensor) in case the phone is in the right
	 * position the stage will be changed to the costumer page (user name: costumer2
	 * , password: 123456)
	 * 
	 * @param event event of clicking on the key icon
	 */
	public void LoginViaSmartphone(MouseEvent event) {
		IDMachineMsg.setText("");
		usernameID.setFocusTraversable(false);
		passwordID.setFocusTraversable(false);
		   
		IDSmartPhone.setVisible(true);
		IDSmartPhone.setOnMousePressed(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				xOffset = event.getX();
				yOffset = event.getY();
			}

		});
		IDSmartPhone.setOnMouseDragged(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				CommonMethods.smartPhoneMoving = 1;
				
				phoneSetData(event);
				

			}

		});
		
		CommonMethods.smartPhoneMoving = 0;
	}
	
	/**
	 * This method handles the mouse event for a phone object and attempts to log the user in with the provided username and password
	 * If the login is successful, the method saves the user's ID, sets the scene to the appropriate home page, 
	 * saves some customer data and starts a timer for logging the user out after a certain period of inactivity.
	 * If the login is unsuccessful, it displays an error message. Additionally, 
	 * it has some functionality to log the user out if they close the window
	 * @param event The MouseEvent object that triggers the method of login via phone
	 * @param username  The username used for the login attempt
	 * @param password The password used for the login attempt
	 */
	private void phoneSetData(MouseEvent event) {
		
		username = IDPhoneUser.getText();
		password = "123456";
		ArrayList<ArrayList<Object>> temp ;
		if (event.getSceneX() >= 210 && event.getSceneX() <= 300 && event.getSceneY() >= 110
				&& event.getSceneY() <= 200) {
			resetPhone();
			if(username!=null && !username.isEmpty()) {
				ClientMethods.SendMessage(Commands.getUserPassword,username);
				temp = ChatClient.password;
				if(temp!=null && !temp.isEmpty())
					password = (String)temp.get(0).get(0)+"";
				else
					password = "1234";
				}
			usernameID.setText(username);
			passwordID.setText(password);

			ClientMethods.SendMessage(Commands.Login, username + "/" + password);
			if ((ChatClient.LoginAnswer.get(0)).equals("false")) {
				IDMachineMsg.setText("Something went wrong");
				resetPhone();

			} else {
				
				getLoginInfoDB();
				Order.customerType = UserType;
				
				Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

				stage.setOnCloseRequest(closeEvent -> { // logout from the account if the user closed the window
					ClientMethods.LogOut();
				});

				SetableHomepage hp;
				if (IsLogged != 1 && UserType.equals("Subscriber")) { // enter the switch statment only if the user not logged in

					activateTimer();
					resetPhone();
					
					switch (UserType) {
					case "Subscriber":
						stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
						hp = (CustomerPageInterFaceController) CommonMethods.switchScene(getClass(), stage,
								"CustomerPage.fxml", "CustomerInterface.css");
						hp.SetPageInfo(UserName, "Customer ID: " + CostumerID, UserType);
						Order.customerID = ChatClient.LoginAnswer.get(6); // save the customer id for the
						// payment
						Customer.customerName = UserName;
						Customer.customerID = CostumerID;
						System.out.println(ChatClient.LoginAnswer.get(6));
						Order.customerType = UserType;
						CommonMethods.smartPhoneMoving = 0;
						break;
			
						
					}
					resetPage();
				}
				else
					{IDMachineMsg.setText("Your not a subscriber");
					ClientMethods.LogOut();
					resetPhone();
					}
			}

		} 
		else {
			IDSmartPhone.setLayoutX(event.getSceneX() - xOffset);
			IDSmartPhone.setLayoutY(event.getSceneY() - yOffset);
			
		}
	}
	/**
	 * This method activates when the touch pad (on the machine) is clicked
	 * retrieves an order from a machine and checks if the order status is "Ready to
	 * Pickup" and the entered code matches the order code. If it matches, it
	 * displays "thank you, have a nice day" otherwise "Wrong Code"
	 * 
	 * @param event touch pad clicked
	 */
	public void getOrder(MouseEvent event) {

		String code = IDOrderCode.getText();
		if (!code.isEmpty() && code != null) {

			ClientMethods.SendMessage(Commands.getOrderFromMachine, "Nothing");
			ArrayList<ArrayList<Object>> ordersMachine = new ArrayList<ArrayList<Object>>();
			ordersMachine = ChatClient.OrdersFromMachineArr;
			if (ordersMachine != null)
				for (int i = 0; i < ordersMachine.size(); i++) {
					if (((String) ordersMachine.get(i).get(4) + "").equals("Ready To Pickup")
							&& ("ekrut-" + code).equals((String) ordersMachine.get(i).get(10) + "")) {
						IDMachineMsg.setText("thank you, have a nice day");
						Integer orderid = (Integer) ordersMachine.get(i).get(0);
						ClientMethods.SendMessage(Commands.ChangeOrderStatus, orderid);
						break;

					} else
						IDMachineMsg.setText("Wrong Code or pickedUp");

				}
			else
				IDMachineMsg.setText("Enter Order code");

		}

	}
	/**
	 * Method to get Login information from data base
	 */
	private void getLoginInfoDB() {

		UserType = ChatClient.LoginAnswer.get(1);
		UserID = ChatClient.LoginAnswer.get(2);
		UserName = ChatClient.LoginAnswer.get(3);
		isLoggedin = ChatClient.LoginAnswer.get(5);
		CostumerID = ChatClient.LoginAnswer.get(6);
		EmailAddress = ChatClient.LoginAnswer.get(7);
		PhoneNumber = ChatClient.LoginAnswer.get(8);
		Customer.customerEmail = EmailAddress;
		Customer.CustomerPhoneNumber = PhoneNumber;
		IsLogged = Integer.parseInt(isLoggedin);

		// might be null stay careful
		Area = ChatClient.LoginAnswer.get(4);
		ClientMethods.SaveUserID(Integer.parseInt(UserID)); // save the userid for the time he logges out
	}
	/**
	 * Method to activate the logout timer
	 */
	private void activateTimer() {
		CommonMethods.setLogOutTimerFlag(false); // set the timer to false -- reseting the timer
		// condition to prevent making multiple instances of LogOutTimer -- Performance
		// upgrade
		if (LogOutTimer.getNumberOfInstances() < 1) {
			// starting the logout timer for the client
			LogOutTimer lot = new LogOutTimer();
			lot.setLogOutTime(20);
			lot.start();
		}
	}
	/**
	 * Method to reset phone position and clear the fields
	 */
	private void resetPhone() {
		IDSmartPhone.setLayoutX(228);
		IDSmartPhone.setLayoutY(382);
		IDSmartPhone.setVisible(false);
		usernameID.clear();
		passwordID.clear();
		
	}
	
	/**
	 * Method to activate the ability of moving between text fields by 
	 * clicking on TAB key (keyboard)
	 * @param event event on clicking on text field
	 */
	public void activateTab(MouseEvent event) {
		   usernameID.setFocusTraversable(true);
		   passwordID.setFocusTraversable(true);
		   
		   
	    }
	/**
	 * Method to reset the page to the original state
	 * that it was in the first time
	 */
	private void resetPage() {
		resetPhone();
		   usernameID.setFocusTraversable(false);
		   passwordID.setFocusTraversable(false);
		   errorLabel.setText("");
		   IDMachineMsg.setText("");
		
	}
}
