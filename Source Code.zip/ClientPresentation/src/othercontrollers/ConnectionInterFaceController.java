package othercontrollers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import client.ClientController;
import client.ClientMethods;
import client.ClientUI;
import common.Commands;
import common.CommonMethods;
import interfaces.CloseablePage;
import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * This Class is a Connection Page Controller for ConnectionPage.fxml ,it runs
 * all the methods that functions the connection
 * 
 * @author Shadi
 * @author Mahran
 *
 */
public class ConnectionInterFaceController implements CloseablePage, Initializable {

	/**
	 * To get the IP Address
	 */
	@FXML
	private TextField ip;

	/**
	 * To show error label for client when trying to connect for unavailable server
	 */
	@FXML
	private Label errorLBL;
	/**
	 * ImageView for the Logo image
	 */
	@FXML
	private ImageView afsa31;
	/**
	 *Button for the connection button
	 */
	@FXML
	private Button zr1;


	/**
	 * Method to get 
	 * @return return ip port 
	 */
	private String getport() {
		return ip.getText();
	}

	/**
	 * to initialize the ip input text length legality
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		CommonMethods.textLengthLegality(ip, 15);
		setAnimation();
	

	}
	/**
	 * Method to set animation and effects for connection 
	 */
	private void setAnimation() {
		FadeTransition ft = new FadeTransition(Duration.seconds(0.8), afsa31);
		ft.setFromValue(0.0);
		ft.setToValue(1.0);
		FadeTransition ft1 = new FadeTransition(Duration.seconds(0.8), zr1);
		ft1.setFromValue(0.0);
		ft1.setToValue(1.0);
		FadeTransition ft2 = new FadeTransition(Duration.seconds(0.8), ip);
		ft2.setFromValue(0.0);
		ft2.setToValue(1.0);

		ParallelTransition pt = new ParallelTransition(ft, ft1, ft2);
		pt.play();
	}

	/**
	 * Method to Connect to the server and the login in case IP address field is
	 * empty an error message would be thrown
	 * 
	 * @param event event of clicking connect Button
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void connect(ActionEvent event) throws Exception {
		String p;

		p = getport();
		if (p.trim().isEmpty()) {
			System.out.println("You must enter an ip");

		} else {

			try {
				ClientUI.chat = new ClientController(p, 5550);
				ClientMethods.SendMessage(Commands.ClientConnect, "New Client Connected");
				CommonMethods.switchScene(getClass(), "LoginHomePage.fxml", "Logininterface.css", event);
			} catch (IOException ex) {
				errorLBL.setText("This server isn't available");
				System.out.println("this server is unavailable");
			}
		}

	}

	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		Stage stage = (Stage) ((Node) (event.getSource())).getScene().getWindow();
		stage.close();

	}

}
