package othercontrollers;

import common.CommonMethods;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * This Class is start Application class to start the whole application starting
 * from connection Page And Controller
 * 
 * @author Shadi
 *
 */
public class StartApplication extends Application {
	/**
	 * to save the primary stage
	 */
	public static Stage primaryStage;
	/**
	 * to save Object
	 */
	public static Object clas;

	/**
	 * Save the login Scene before starting the application
	 */
	@Override
	public void start(Stage stage) throws Exception {

		CommonMethods.SaveLoginScene(getClass(), stage);

		try {
			stage.initStyle(StageStyle.UNDECORATED);
			stage.setTitle("Server Connection Homepage");
			System.out.println("hey");
			Image icon = new Image("/icons/vending-machine-client.png");
			Parent root = FXMLLoader.load(getClass().getResource("/FXMLs/ConnectionPage.fxml"));
			// usernameID.getText();
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/CssF/ConnectionInterface.css").toExternalForm());// implement
																													// css
																													// design
			stage.setTitle("Ekrut");
			stage.setScene(scene);
			stage.getIcons().add(icon);
			primaryStage=stage;
			clas=stage.getClass();
			stage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Method to switch to login screen
	 */
	public  static void SwitchToLoginScreen()
	{
		CommonMethods.switchScene((Class<?>)clas , primaryStage , "LoginHomePage.fxml", "Logininterface.css");
	}
	
	

	/**
	 * Main
	 * 
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		launch(args);

	}

}
