package othercontrollers;

import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import homepagescontrollers.DeliveryOperatorController;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;

/**
 * This Class is a Approve Delivery Page Controller for ApproveDeliveryPage.fxml
 * ,it runs all the methods that functions to show the deliveries(also the their
 * status) and the ability to Confirm them when its done Note: this class uses
 * help from CommonMethods to set and get some functionalities
 * 
 * @author Shadi
 */
public class ApproveDeliveryPageController implements Initializable {

	/**
	 * TableView to save and show the orders
	 */
	@FXML
	private TableView<TableRow> tableView;

	/**
	 * TableColumn for the orders id
	 */
	@FXML
	private TableColumn<TableRow, Integer> OrderID;

	/**
	 * TableColumn for the Customer id
	 */
	@FXML
	private TableColumn<TableRow, Integer> CostumerID;

	/**
	 * TableColumn for the Components
	 */
	@FXML
	private TableColumn<TableRow, String> Components;

	/**
	 * TableColumn for the Buttons
	 */
	@FXML
	private TableColumn<TableRow, HBox> ApproveButton;

	/**
	 * Observable list for TableView rows
	 */
	private ObservableList<TableRow> list;
	/**
	 * map that helps save the address for each order via id
	 */
	private HashMap<String, ArrayList<String>> orderAddress = new HashMap<String, ArrayList<String>>();
	/**
	 * map that helps save the customer id for each order via id
	 */
	private HashMap<String, String> customerIDOfOrder = new HashMap<String, String>();
	/**
	 * map that helps save the time of arrive for each order via id
	 */
	private HashMap<String, String> timeOfArrive = new HashMap<String, String>();
	/**
	 * map that helps save the time that the order was done for each order via id
	 */
	private HashMap<String, String> orderTime = new HashMap<String, String>();
	/**
	 * map that helps save the total price of the order was done for each order via
	 * id
	 */
	private HashMap<String, String> orderTotalPrice = new HashMap<String, String>();
	/**
	 * Label to show the area 
	 */
	@FXML
	private Label IDarea;
	/**
	 * Hbox for column status
	 */
	private HBox actionHbox;
	/**
	 * to save order status
	 */
	private HashMap<String, String> orderStatus= new HashMap<String, String>();
	/**
	 * initialize all the details that needed in the helper classes and in the
	 * current class initialize the table view and every row in it
	 */
	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		IDarea.setText(DeliveryOperatorController.workingArea);
		getDataDB();
		buildView();
		
	}
	
	/**
	 * Method to set the view in the table view 
	 * using the data from the data base
	 */
	private void buildView() {
		OrderID.setCellValueFactory(new PropertyValueFactory<TableRow, Integer>("OrderID"));
		CostumerID.setCellValueFactory(new PropertyValueFactory<TableRow, Integer>("CostumerID"));
		Components.setCellValueFactory(new PropertyValueFactory<TableRow, String>("Components"));
		ApproveButton.setCellValueFactory(new PropertyValueFactory<TableRow, HBox>("ApproveButton"));



		for (String i : orderAddress.keySet()) {
			TableRow save = new TableRow();
			save.setOrderID(Integer.parseInt(i));
			save.setCostumerID(Integer.parseInt(customerIDOfOrder.get(i)));
			String temp = "";
			for (String j : orderAddress.get(i))
				temp += j + "\n";
			save.setComponents(temp);
			if(orderStatus.get(i).equals("Ready For Dispatch"))
			{actionHbox = new HBox(MakeApproveButton(save.getOrderID(), save, timeOfArrive.get(i), orderTime.get(i),
					orderTotalPrice.get(i)));
			
			actionHbox.setSpacing(20);
			actionHbox.setAlignment(Pos.CENTER);
			}
			else
				{
				if(orderStatus.get(i).equals("Refunded"))
					actionHbox = new HBox(createStatusLabel(orderStatus.get(i)+" Customer"));
				else if(orderStatus.get(i).equals("Confirmed"))
					actionHbox = new HBox(createStatusLabel(orderStatus.get(i)+" by Customer"));		
				else
					actionHbox = new HBox(createStatusLabel(orderStatus.get(i)));
				actionHbox.setSpacing(20);
				actionHbox.setAlignment(Pos.CENTER);
				}
			
			
			save.setApproveButton(actionHbox);
			list.add(save);

			tableView.setItems(list);
		}
	}
	/**
	 * Method to get the data from the data base
	 */
	private void getDataDB() {
		ClientMethods.SendMessage(Commands.Getallorders, "Nothing");
		ArrayList<ArrayList<Object>> arr1 = new ArrayList<ArrayList<Object>>();
		arr1 = ChatClient.OrdersArr;
		System.out.println(arr1);
		list = tableView.getItems();
		if (arr1 != null)
			for (int i = 0; i < arr1.size(); i++) {
				if ((arr1.get(i).get(17)).equals(DeliveryOperatorController.workingArea)
			) {
					ArrayList<String> address = new ArrayList<String>();
					if (!orderAddress.containsKey((Integer) arr1.get(i).get(0) + "")) {
						address.add("First Name: " + arr1.get(i).get(12));
						address.add("Last Name: " + arr1.get(i).get(13));
						address.add("Phone Number: " + arr1.get(i).get(14));
						address.add("House Number: " + arr1.get(i).get(15));
						address.add("Street: " + arr1.get(i).get(16));
						orderAddress.put((Integer) arr1.get(i).get(0) + "", address);

					}

					if (!customerIDOfOrder.containsKey((Integer) arr1.get(i).get(0) + "")) {
						customerIDOfOrder.put((Integer) arr1.get(i).get(0) + "", arr1.get(i).get(5) + "");
						timeOfArrive.put((Integer) arr1.get(i).get(0) + "", arr1.get(i).get(2) + "");
						orderTime.put((Integer) arr1.get(i).get(0) + "", arr1.get(i).get(3) + "");
						orderTotalPrice.put((Integer) arr1.get(i).get(0) + "", arr1.get(i).get(1) + "");
						orderStatus.put((Integer) arr1.get(i).get(0) + "", arr1.get(i).get(4) + "");
					}

				}
			}
	}

	/**
	 * Method to create and connect a Approve button for the Delivery (the row in
	 * that table view) in case that Delivery isn't completed in case the approve
	 * button is clicked and the time is more than the time of arrive the order a
	 * message would be thrown telling the user that the amount is refunded
	 * 
	 * @param orderid order id
	 * @param row     row that needs to be connected to the Approve button in the
	 *                table view
	 * @param tof the given time of arrival
	 * @param orderDate the order date
	 * @param totalPrice the total price
	 * @return return the Button
	 */
	public Button MakeApproveButton(int orderid, TableRow row, String tof, String orderDate, String totalPrice) {
		Button approvebtn = new Button("Approve");
		approvebtn.requestFocus();
		approvebtn.setOnMouseClicked(event -> {
			ArrayList<String> arr = new ArrayList<>();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
			LocalDateTime now = LocalDateTime.now();
			String today = dtf.format(now);
			System.out.println(findDifference(orderDate, today, "Minutes", Integer.parseInt(tof.substring(0, 2))));
			if (findDifference(orderDate, today, "Minutes", Integer.parseInt(tof.substring(0, 2)))) {
				CommonMethods.CompletionMessage("This order Arrived late so it is refunded", getClass());
				arr.add(orderid + "");
				arr.add(totalPrice + "");
				ClientMethods.SendMessage(Commands.RefundOrderAfterDelivery, arr);
				list.remove(row);

			} else {
				CommonMethods.CompletionMessage("This order is delivered in time and Approved", getClass());
				arr.add(orderid + "");
				ClientMethods.SendMessage(Commands.ApproveOrderDelivery, arr);
				list.remove(row);
			}

		});
		approvebtn.setStyle("-fx-background-radius: 50;" + "-fx-background-color: #90BB14;" + "-fx-font-weight:bold;"
				+ "-fx-font-size: 12px;" + "-fx-effect: dropshadow( three-pass-box , #A2A09F, 13, 0 , 7 , 7 );"
				+ "-fx-text-fill: white;" + "-fx-border-radius:50px;" + "-fx-border-width:2px;");
		return approvebtn;

	}
	/**
	 * Method to create and connect label to the row of the table view(order)
	 * "complete" ,in case the order is completed
	 * 
	 * @return complete(label)
	 */
	private Label createStatusLabel(String status) {
		Label complete = new Label();
		complete.setText(status);
		complete.setStyle("-fx-font-size: 15px;" + "-fx-text-fill: #90BB14;" + "-fx-font-weight:bold;");
		return complete;
	}

	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void close(MouseEvent event) throws Exception {
		ClientMethods.close(event);

	}

	/**
	 * Method for going back to the previous page in this case the Delivery Operator
	 * Home Page
	 * 
	 * @param event event if the the arrow (back) icon clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void back(MouseEvent event) throws Exception {
		CommonMethods.switchSceneBack(getClass(), event);
	}

	/**
	 * Method for clicking the help icon ,a windows will show with a message and
	 * explain the scene/page
	 * 
	 * @param event event of the help icon clicked the scene/page and what every
	 *              button do
	 * @throws Exception Exception will be thrown if an error occurs from Customer
	 *                   class
	 */
	public void help(MouseEvent event) throws Exception {
		CommonMethods.help("This is the Approve Delivery Page" + "\nYou Can Approve the delivery when its delivered",
				getClass());

	}

	/**
	 * This Method calculates the time difference between two dates in hours and
	 * minutes, and returns a boolean value depending on whether the difference
	 * meets a certain criterion ( specified by the "check" and "checkParameter"
	 * parameters). The dates are in the format "yyyy-MM-dd HH:mm".
	 * 
	 * @param start_date     the order date
	 * @param end_date       time and date now
	 * @param check          to check
	 * @param checkParameter checkParameter to compare
	 * @return
	 */
	private boolean findDifference(String start_date, String end_date, String check, int checkParameter) {

		long difference_In_Time;
		long difference_In_Minutes;
		long difference_In_Hours;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

		// Try Block
		try {

			// parse method is used to parse
			// the text from a string to
			// produce the date
			Date d1 = sdf.parse(start_date);
			Date d2 = sdf.parse(end_date);

			// Calculate time difference
			// in milliseconds
			difference_In_Time = d2.getTime() - d1.getTime();

			difference_In_Minutes = (difference_In_Time / (1000 * 60)) % 60;
			difference_In_Hours = (difference_In_Time / (1000 * 60 * 60)) % 24;

			if (check.equals("Minutes") && difference_In_Minutes >= checkParameter || difference_In_Hours > 0)
				return true;

		}

		// Catch the Exception
		catch (ParseException e) {
			System.out.println("Error in date diffrence");
			e.printStackTrace();
		}
		return false;

	}

	/**
	 * Inner class to help build the rows of the order's table view
	 * 
	 * @author Shadi
	 *
	 *
	 */
	public class TableRow {
		private int OrderID;
		private int CostumerID;
		private String Components;
		private HBox ApproveButton;

		/**
		 * default constructor
		 */

		public TableRow() {

		}

		/**
		 * constructor to initialize the data
		 * 
		 * @param orderID       the order id
		 * @param costumerID    the customer id
		 * @param components    the components (products)
		 * @param approveButton the approve Button
		 */
		public TableRow(int orderID, int costumerID, String components, HBox approveButton) {
			super();
			OrderID = orderID;
			CostumerID = costumerID;
			Components = components;
			ApproveButton = approveButton;
		}

		/**
		 * Method to get the order id
		 * 
		 * @return OrderID
		 */
		public int getOrderID() {
			return OrderID;
		}

		/**
		 * Method to set the order id
		 * 
		 * @param orderID OrderID to set the order id to this value
		 */
		public void setOrderID(int orderID) {
			OrderID = orderID;
		}

		/**
		 * Method to get Customer id
		 * 
		 * @return return this Customer id
		 */
		public int getCostumerID() {
			return CostumerID;
		}

		/**
		 * Method to set Customer id
		 * 
		 * @param costumerID set the id to this param
		 */
		public void setCostumerID(int costumerID) {
			CostumerID = costumerID;
		}

		/**
		 * Method to get the components
		 * 
		 * @return return this components
		 */
		public String getComponents() {
			return Components;
		}

		/**
		 * Method to set this components to this param
		 * 
		 * @param components the components
		 */
		public void setComponents(String components) {
			Components = components;
		}

		/**
		 * Method to get the HBox
		 * 
		 * @return return the Button
		 */
		public HBox getApproveButton() {
			return ApproveButton;
		}

		/**
		 * Method to set HBox
		 * 
		 * @param approveButton the HBox to set 
		 */
		public void setApproveButton(HBox approveButton) {
			ApproveButton = approveButton;
		}

	}
}
