package othercontrollers;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import customermethods.Customer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import orders.Order;

/**
 * This Class is a Payment Page Controller for PaymentPage.fxml ,it runs all the
 * methods that functions the choice of Paying for the order by the customer the
 * choices for subscriber are Normal Payment (credit card) Subscription
 * Payment(monthly) there is only one choice for normal customer to pay with
 * credit card(normal payment) Note: this class uses help from Customer and
 * Order class to set and get some functionalities
 * 
 * @author Mahran
 * @author Shadi
 *
 */
public class PaymentController implements Initializable {
	/**
	 * to generate random number
	 */
	private Random rand = new Random();
	/**
	 * ArrayList to save the coupons of the customer
	 */
	private ArrayList<String> coupons = new ArrayList<>(Arrays.asList("None"));
	/**
	 * to save the final price
	 */
	private String finalPrice;
	/**
	 * to save and show the stage
	 */
	Stage stage;
	/**
	 * to save and the root
	 */
	Parent root;
	/**
	 * ImageView to show what page customer came from
	 */
	@FXML
	private ImageView IDLocationStep;
	/**
	 * ImageView to show v mark after completing the payment
	 */
	@FXML
	private ImageView IDCompleteMark;
	/**
	 * RadioButton to select subscription payment option
	 */
	@FXML
	private RadioButton IDSubPayment;
	/**
	 * Label to show to total price
	 */
	@FXML
	private Label IDTotalPrice;
	/**
	 * Label that shows error message
	 */
	@FXML
	private Label IDErrorLabel;
	/**
	 * ComboBox to save/show coupons to choose from
	 */
	@FXML
	private ComboBox<String> IDCoupon;
	/**
	 * Button for  order
	 */
	@FXML
	private Button ID;
	/**
	 * Button to the complete order(confirm payment)
	 */
	@FXML
	private Button IDConfirm;
	/**
	 * TextField to get the customer's credit card number
	 */
	@FXML
	private TextField IDCreditCard;
	/**
	 * TextField to get the customer's credit card CVV
	 */
	@FXML
	private TextField IDCvv;
	/**
	 * TextField to get the customer's credit card expiry Month
	 */
	@FXML
	private TextField IDDateMonth;
	/**
	 * TextField to get the customer's credit card expiry year
	 */
	@FXML
	private TextField IDDateYear;
	/**
	 * TextField to get the Holder's name
	 */
	@FXML
	private TextField IDHolderName;
	/**
	 * Label to show page title
	 */
	@FXML
	private Label IDTitle;
	/**
	 * to save the payment method
	 */
	private String paymentMethod;
	/**
	 * Button to use coupon
	 */
	@FXML
	private Button IDUseCoupon;
	/**
	 * to save the order code
	 */
	private String orderCode;
	/**
	 * to save the id of the used coupon
	 */
	private String usedCouponID;
	
	/**
	 * from location and area to arrival time
	 */
	private HashMap < List<String> ,Integer> AreaLocationToArrivaltime = new HashMap<>();
	
	/**
	 * label to show CVV to fill text
	 */
	@FXML
	private Label IDLabelCvv;
	/**
	 * label to show credit card number to fill text
	 */
	@FXML
	private Label IDLabelCard;
	/**
	 * label to show Expiry date to fill text
	 */
	@FXML
	private Label IDLabelDate;
	/**
	 * label to show holder Name to fill text
	 */
	@FXML
	private Label IDLabelName;
	/**
	 * to save a price after coupon
	 */
	private String price ;
	/**
	 * to save the credit card cvv from data base
	 */
	private String cvv;
	private int flag=0 ;


	/**
	 * initialize labels and text fields initialize the current path that customer
	 * took initialize all the details that needed in the helper classes
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		setEnter();
		setImportantLabel();
		InitializeArrivaltimeHashMap();
		price = Order.orderPrice;
		Customer.IDLocationStep = IDLocationStep;
		Customer.checkCustomerPath();
		IDErrorLabel.setVisible(false);
		IDSubPayment.setVisible(true);
		checkCustomer();
		getDBcoupons();
		IDCoupon.getItems().addAll(coupons);
		IDErrorLabel.setText("All fields with * mark must be filled correctly");
		IDTotalPrice.setText("Toltal Price: " + String.format("%.2f", Double.parseDouble(Order.orderPrice)) + "$");
		checkInput();
		IDCoupon.setOnAction(this::chooseCoupon);

	}


	/**
	 * Method to choose coupon from the coupon Combo Box and and calculate the final
	 * price after the coupon and shows it on the screen
	 * 
	 * @param event if a coupon is choosed from the coupon Combo Box
	 */
	public void chooseCoupon(ActionEvent event) {
		if (IDCoupon.getValue() == "None") {
			finalPrice = price;
			IDTotalPrice.setText("Toltal Price: " + String.format("%.2f", Double.parseDouble(finalPrice)) + "$");
		}
		if (IDCoupon.getValue() != "None" && IDCoupon.getValue() != null) {
			finalPrice = Double.parseDouble(price)
					- Double.parseDouble(price) * (CouponDiscount() / 100) + "";
			IDTotalPrice.setText("Toltal Price: " + String.format("%.2f", Double.parseDouble(finalPrice)) + "$");
		}
	}

	/**
	 * Method to activate the coupon and implemented on final price in case customer
	 * chooses the coupon and choose to use it a message of confirmation would show
	 * to confirm his decision then it will remove the coupon from the coupon
	 * ComboBox
	 * 
	 * @param event event if use button is clicked
	 */
	public void getCoupon(ActionEvent event) {

		if (IDCoupon.getValue() != "None" && IDCoupon.getValue() != null) {
			Customer.confirmationMessage("Do you want to use this coupon?\n\n", "Coupon\n", getClass());
			if (Customer.respond == "yes") {

				String coupon = IDCoupon.getValue();
				if (price != null)
						price = Double.parseDouble(price)
							- Double.parseDouble(price) * (CouponDiscount() / 100) + "";
					
				IDTotalPrice.setText("Toltal Price: " + price + "$");
				IDCoupon.getItems().remove(coupon);
				usedCouponID = coupons.indexOf(coupon) + "";
			}

		}
	}

	/**
	 * Method that gets the customer's coupon and returns the discount as a double
	 * 
	 * @return discountNum
	 */
	private double CouponDiscount() {
		String coupon = IDCoupon.getValue();
		String discount[] = coupon.split("-");
		double discountNum = Double.parseDouble(discount[1]);
		return discountNum;
	}

	/**
	 * Method to check if the customer is a subscriber or a regular customer
	 */
	public void checkCustomer() {

		if (Order.customerType.equals("Subscriber")) {
			IDSubPayment.setVisible(true);
		} else
			IDSubPayment.setVisible(false);
	}

	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception // close window
	{

		ClientMethods.close(event);
	}

	/**
	 * Method for clicking the help icon ,a windows will show with a message and
	 * explain the scene/page
	 * 
	 * @param event event of the help icon clicked the scene/page and what every
	 *              button do
	 * @throws Exception Exception will be thrown if an error occurs from Customer
	 *                   class
	 */
	public void help(MouseEvent event) throws Exception {

		CommonMethods.help(
				"All Fields with * are necessary fill \n" + "Press Coupon and choose one if you have\n"
						+ "Press confirm to submit your Order\n" + "Press  Order to  your order\n"
						+ "Press <- to go back to the recieving options Page(if you want to change the method)\n"
						+ "Press Saved Card to fill information with the saved card in the system",
				getClass());

	}

	/**
	 * Method for going back to the previous page in this case the Receiving Options
	 * Page
	 * 
	 * @param event event if the the arrow (back) icon clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void back(MouseEvent event) throws Exception // close window
	{
		CommonMethods.switchSceneBack(getClass(), event);
	}
	
	/**
	 * Method to get saved card from database and represent it to the customer
	 * @param event event on clicking the saved card button
	 */
	public void savedCard(ActionEvent event) {
		flag = 1;
		ArrayList<ArrayList<Object>> info ;
		ClientMethods.SendMessage(Commands.getCreditCardInfo,Customer.customerID);
		info = ChatClient.CreditCardArr;
		String holderName =(String)(info.get(0).get(0)+" ");
		String lastName =(String)(info.get(0).get(1)+"");
		holderName += lastName;
		System.out.println();
		String cardNumber = info.get(0).get(2)+"";
		String date = info.get(0).get(3)+"";
		String[] arrDate = date.split("/");
		cvv = info.get(0).get(4)+"";
		IDHolderName.setText(holderName);
		IDCreditCard.setText(cardNumber);
		IDDateMonth.setText(arrDate[0]);
		IDDateYear.setText("20"+arrDate[1]);
		IDCvv.setText(cvv);

	
		
	}
	/**
	 * Method to confirm payment and checks the customer's payment information
	 * legality in case the customer is a subscriber he can pay by credit option
	 * (monthly payment) after the customer confirms the payment it takes him back
	 * to his home page(switch scenes/stage)
	 * 
	 * @param event event if the confirm Button is clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	@SuppressWarnings("unlikely-arg-type")
	public void Confirm(ActionEvent event) throws Exception {
		// get the arrival time to put it in the message for the costumer
		List<String> AreaLocationToSwap = Arrays.asList(Order.area, Order.location );
		Integer ArriveTime = AreaLocationToArrivaltime.get(AreaLocationToSwap);
		
		if (Order.customerType.equals("Subscriber") && IDSubPayment.isSelected()) {
			Customer.confirmationMessage("Your total price is \n"
					+ String.format("%.2f", Double.parseDouble(price)) + "$ Do you want to proceed",
					  "Payment\n", getClass());
			if (Customer.respond == "yes") {
				Order.orderPrice = price;
				this.orderCode = "ekrut-" + rand.nextInt(1000);
				this.paymentMethod = "subscription";
				IDCompleteMark.setVisible(true);
				IDErrorLabel.setVisible(false);
				// viewing the message depending on the delivery method
				if (Order.methodOfDelivery.equals("PickUp")) {
					CommonMethods.CompletionMessage(
							"Thank you\n Payment has been added\n" + " to your monthly subscription payment\n "
									+ "your order " + this.orderCode + " has been submited \n"
									+ "A message with the receipt would be sent to your email Adress and phone number\n"
									+ Customer.customerEmail + "\n" + Customer.CustomerPhoneNumber + "\n",
							getClass());
				} else {
					CommonMethods.CompletionMessage(
							"Thank you\n Payment has been added\n" + " to your monthly subscription payment\n "
									+ "your order " + this.orderCode + " has been submited \n"
									+ "A message with the receipt would be sent to your email Adress and phone number\n"
									+ Customer.customerEmail + "\n" + Customer.CustomerPhoneNumber + "\n"
									+ "The Estimated ArrivalTime is " + ArriveTime + " Minutes",
							getClass());
				}
				saveInDB();
				deleteCoupon();
				Order.clearOrder();
				CommonMethods.switchToHomepageScene(getClass(), event);
			}
		} else if (checkEmptyFields(IDHolderName, IDCreditCard, IDDateMonth, IDDateYear, null)
				|| IDCvv.getText() == null || IDCvv.getText().length() != 3
				|| checkEmptyFields(IDHolderName, IDCreditCard, IDDateMonth, IDDateYear, "") || IDCvv.equals("")
				|| IDDateMonth.getText().length() != 2 || IDDateYear.getText().length() != 4
				|| IDCreditCard.getText().length() != 16 || Integer.parseInt(IDDateYear.getText()) > 2040
				|| Integer.parseInt(IDDateYear.getText()) < 2023 || Integer.parseInt(IDDateMonth.getText()) > 12) {
			clearFields();
		} 

		else {
			Customer.confirmationMessage("Your total price is \n"
					+ String.format("%.2f", Double.parseDouble(Order.orderPrice)) + "$ Do you want to proceed",
					"Payment\n", getClass());
			if (Customer.respond == "yes") {
				Order.orderPrice = price;
				this.orderCode = "ekrut-" + rand.nextInt(1000);
				this.paymentMethod = "CreditCard";
				IDCompleteMark.setVisible(true);
				IDErrorLabel.setVisible(false);
				// viewing the message depending on the delivery method
				if (Order.methodOfDelivery.equals("Delivery")) {
					CommonMethods.CompletionMessage("Thank you\n Payment has been Confirmed ,your order "
							+ this.orderCode + " has been submited \n"
							+ "A message with the receipt would be sent to your email Adress and phone number\n"
							+ Customer.customerEmail + "\n" + Customer.CustomerPhoneNumber + "\n"
							+ "The Estimated ArrivalTime is " + ArriveTime + " Minutes", getClass());
				} else {
					CommonMethods.CompletionMessage("Thank you\n Payment has been Confirmed ,your order "
							+ this.orderCode + " has been submited \n"
							+ "A message with the receipt would be sent to your email Adress and phone number\n"
							+ Customer.customerEmail + "\n" + Customer.CustomerPhoneNumber + "\n", getClass());
				}
				saveInDB();
				deleteCoupon();
				Order.clearOrder();
				CommonMethods.switchToHomepageScene(getClass(), event);
			}
		}

	}

	/**
	 * Method to check if there is an empty field empty fields in any TextField
	 * given as a parameter true in case there is an empty field and false if there
	 * isn't
	 * 
	 * @param IDFN  first name text field
	 * @param IDLN  last name text field
	 * @param IDPN  phone number text field
	 * @param IDHN  house number text field
	 * @param check another parameter if needed
	 * @return returns true in case there is an empty field and false if there isn't
	 */
	private boolean checkEmptyFields(TextField IDFN, TextField IDLN, TextField IDPN, TextField IDHN, String check) {
		if (IDFN.getText().equals(check) || IDLN.getText().equals(check) || IDPN.getText().equals(check)
				|| IDHN.getText().equals(check))
			return true;
		return false;
	}

	/**
	 * Method that  the order in case  Order button is clicked the
	 * method would show a message of confirmation for the customer and ask
	 * confirmation from the customer, in case the answer is yes the stage goes back
	 * to the Customer Page
	 * 
	 * @param event event of the Cancel Order button clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void CancelOrder(ActionEvent event) throws Exception {// cancel order
		Customer.confirmationMessage("Do you want to cancel this order\n", "Cancel Order\n", getClass());
		if (Customer.respond == "yes") {
			Order.clearNotCompleteOrder();
			Order.clearOrder();// clear order of everything
			CommonMethods.switchToHomepageScene(getClass(), event);
		}
	}

	/**
	 * Method to save the order in the data base
	 */
	private void saveInDB() {
		// get the machine id from database
		String machineID = getMachineId();
		ArrayList<String> DBProductsInOrder = new ArrayList<>();
		ArrayList<String> DBQuantities = new ArrayList<>();
		ArrayList<String> DBArea = new ArrayList<>();
		@SuppressWarnings("unused")
		ArrayList<String> DBLocation = new ArrayList<>();
		String DBcustomerId = Order.customerID;// need to set it from data base at the beginning when you set the
												// Customer HomePage
		String DBPaymentMethod = this.paymentMethod;// setted
		String DBmethodOfDelivery = Order.methodOfDelivery;// setted
		String DBPrice = String.format("%.2f", Double.parseDouble(Order.orderPrice));// setted
		// Notes:* you can get delivery information from Order.deliveryInfo if you need
		// it
		// Can't know the current order id must know what is in data base and add the
		// order number accordingly

		// putting the data i need all in one array to send to the server
		ArrayList<Object> AllDataNeeded = new ArrayList<>();
		AllDataNeeded.add(Order.productsInOrder.size()); // index 0
		AllDataNeeded.add(DBPaymentMethod); // index 1
		AllDataNeeded.add(DBmethodOfDelivery); // index 2
		AllDataNeeded.add(DBPrice); // index 3
		AllDataNeeded.add(DBcustomerId); // index 4

		for (int i = 0; i < Order.productsInOrder.size(); i++) {
			AllDataNeeded.add(Order.productsInOrder.get(i).getProductID()); // next indexes are products ids then
																			// quantities
			AllDataNeeded.add(Order.productsInOrder.get(i).getQuantity()); //
			DBProductsInOrder.add(Order.productsInOrder.get(i).getProductName());
			DBQuantities.add(Order.productsInOrder.get(i).getQuantity());
			DBArea.add(Order.productsInOrder.get(i).getArea());

			System.out.println("Name: " + Order.productsInOrder.get(i).getProductName());
			System.out.println("Quantity: " + Order.productsInOrder.get(i).getQuantity());
			System.out.println("Area: " + Order.productsInOrder.get(i).getArea());
			System.out.println("Location: " + Order.productsInOrder.get(i).getLocation());

		}
		AllDataNeeded.add(orderCode); // index index1 * 2 + 5
		AllDataNeeded.add(machineID);// index index1 * 2 + 6
		
		if (Order.methodOfDelivery.equals("Delivery")) {
			AllDataNeeded.add(Order.deliveryInfo.getFirstName());// index index1 * 2 + 7
			AllDataNeeded.add(Order.deliveryInfo.getLastName());// index index1 * 2 + 8
			AllDataNeeded.add(Order.deliveryInfo.getPhoneNumber());// index index1 * 2 + 9
			AllDataNeeded.add(Order.deliveryInfo.getHouseNumber());// index index1 * 2 + 10
			AllDataNeeded.add(Order.deliveryInfo.getStreet());// index index1 * 2 + 11
			AllDataNeeded.add(Order.deliveryInfo.getArea());// index index1 * 2 + 12
		}
		// System.out.println(DBcustomerId);
		System.out.println(DBPaymentMethod);
		System.out.println(DBmethodOfDelivery);
		System.out.println(DBPrice);
		System.out.println(AllDataNeeded);
		ClientMethods.SendMessage(Commands.OrderPaymentDone, AllDataNeeded);
		// get the arrival time before sending it for update
		if (Order.methodOfDelivery.equals("Delivery")) {
		List<String> AreaLocationToSwap = Arrays.asList(Order.area,Order.location);
		Integer ArriveTime=AreaLocationToArrivaltime.get(AreaLocationToSwap);
		ClientMethods.SendMessage(Commands.UpdateToRightArrivalTimeAfterPayment , ArriveTime );
		}
		// delete not completed order
		Integer orderid = Order.checkNotCompleteOrderInDB();
		if (orderid > -1)
			ClientMethods.SendMessage(Commands.DeleteOrder, orderid);
		
	}

	/**
	 * Method to clear every field (TextField)
	 */
	private void clearFields() {
		IDHolderName.clear();
		IDCreditCard.clear();
		IDDateMonth.clear();
		IDDateYear.clear();
		IDCvv.clear();
		IDErrorLabel.setVisible(true);
		IDErrorLabel.setText("All fields with * mark must be filled correctly");
	}

	/**
	 * Method to get the machine id from database with the help of location and area
	 * 
	 * @return return the machine id or empty string
	 */
	private String getMachineId() {

		String id = "";
		ClientMethods.SendMessage(Commands.getMachines, "Nothing");
		ArrayList<ArrayList<Object>> machines = new ArrayList<ArrayList<Object>>();
		machines = ChatClient.MachinesArr;
		for (int i = 0; i < machines.size(); i++)
			if (Order.area.equals(machines.get(i).get(2)) && Order.location.equals(machines.get(i).get(1)))
				id = machines.get(i).get(0) + "";
		return id;

	}

	/**
	 * Method to get the coupons for the customer from the data base
	 */
	private void getDBcoupons() {

		ClientMethods.SendMessage(Commands.getCoupons, "Nothing");
		ArrayList<ArrayList<Object>> DBcoupons = new ArrayList<ArrayList<Object>>();
		DBcoupons = ChatClient.CouponsArr;
		for (int i = 0; i < DBcoupons.size(); i++)
			if (Order.customerID.equals(DBcoupons.get(i).get(1) + ""))
				coupons.add(DBcoupons.get(i).get(10) + "");

	}

	/**
	 * Method to delete coupon from database after the customer used it and payed
	 */
	private void deleteCoupon() {

		if (usedCouponID != null && !usedCouponID.equals("None") && !usedCouponID.equals("")) {
			ArrayList<String> toDelelte = new ArrayList<String>();
			toDelelte.add(usedCouponID);
			toDelelte.add(Order.customerID);
			ClientMethods.SendMessage(Commands.deleteCoupon, toDelelte);

		}
	}

	/**
	 * This method checks the input of IDCreditCard, IDDateMonth, IDDateYear, IDCvv and IDHolderName
	 * by calling the textLegality and textLengthLegality methods of the CommonMethods class.
	 */
	private void checkInput() {
		CommonMethods.textLegality(IDCreditCard, 16);
		CommonMethods.textLegality(IDDateMonth, 2);
		CommonMethods.textLegality(IDDateYear, 4);
		CommonMethods.textLegality(IDCvv, 3);
		CommonMethods.textLengthLegality(IDHolderName, 30);
	}
	 /**
	 * This method sets the "*" before the text of the IDLabelCvv, IDLabelName, 
	 * IDLabelCard and IDLabelDate to indicate that these labels are important.
	 */
	private void setImportantLabel() {
		CommonMethods.importantLabel(IDLabelCvv);
		CommonMethods.importantLabel(IDLabelName);
		CommonMethods.importantLabel(IDLabelCard);
		CommonMethods.importantLabel(IDLabelDate);
	}
	/**
	 * Method to activate the ability of moving between text fields by 
	 * clicking on TAB key (keyboard)
	 * @param event event on clicking on text field
	 */
	public void activateTab(MouseEvent event) {
		IDHolderName.setFocusTraversable(true);
		IDCreditCard.setFocusTraversable(true);
		IDDateYear.setFocusTraversable(true);
		IDDateMonth.setFocusTraversable(true);
		IDCvv.setFocusTraversable(true);
		
		
		   
	    }
	/**
	 * A method that sets the event listeners for the enter key press event on all the text fields.
	 * When the enter key is pressed, it triggers the action of the confirm button.
	 */
	private void setEnter() {
		CommonMethods.continueWithEnter(IDCreditCard, IDConfirm);
		CommonMethods.continueWithEnter(IDHolderName, IDConfirm);
		CommonMethods.continueWithEnter(IDDateMonth, IDConfirm);
		CommonMethods.continueWithEnter(IDDateYear, IDConfirm);
		CommonMethods.continueWithEnter(IDCvv, IDConfirm);
	}
	/**
	 * method for initializing the HashMap values
	 */
	
	public void InitializeArrivaltimeHashMap()
	{

		AreaLocationToArrivaltime.put(Arrays.asList("Haifa","the Baha'i Gardens"),10);
		AreaLocationToArrivaltime.put(Arrays.asList("Haifa","Down Town"),20);
		AreaLocationToArrivaltime.put(Arrays.asList("Haifa","Maritime Museum"),30);
		AreaLocationToArrivaltime.put(Arrays.asList("Haifa","Haifa-University"),40);
		
		AreaLocationToArrivaltime.put(Arrays.asList("Shefa-Amer","Old City"),50);
		AreaLocationToArrivaltime.put(Arrays.asList("Shefa-Amer","Down Town"),60);
		AreaLocationToArrivaltime.put(Arrays.asList("Shefa-Amer","The Castle"),70);
		AreaLocationToArrivaltime.put(Arrays.asList("Shefa-Amer","Alna'ma"),80);
		
		AreaLocationToArrivaltime.put(Arrays.asList("Karmiel","Ort Braude"),90);
		AreaLocationToArrivaltime.put(Arrays.asList("Karmiel","Down Town"),100);
		AreaLocationToArrivaltime.put(Arrays.asList("Karmiel","North"),110);
		AreaLocationToArrivaltime.put(Arrays.asList("Karmiel","Park"),120);
		
		AreaLocationToArrivaltime.put(Arrays.asList("Tel-Aviv","Jaffa"),130);
		AreaLocationToArrivaltime.put(Arrays.asList("Tel-Aviv","Yemenite Quarter"),140);
		AreaLocationToArrivaltime.put(Arrays.asList("Tel-Aviv","Tel Aviv Museum"),150);
		AreaLocationToArrivaltime.put(Arrays.asList("Tel-Aviv","Tel-Aviv University"),160);
				
	}

}
