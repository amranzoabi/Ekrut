package client;

import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;

import common.CommonMethods;
import javafx.application.Platform;
import othercontrollers.StartApplication;

/**
 * LogOutTimer is a class that extends the Thread class and it used to implement
 * a timer function to log out the user after a specific amount of time. The
 * timer starts when the mouse is inactive and the thread will be running and
 * checking the mouse activity and if the mouse is inactive for a specific
 * amount of time the thread will log out the user.
 * 
 * @author Shadi
 * @author Mahran
 *
 */
public class LogOutTimer extends Thread {
	/**
	 * to save maximum time
	 */
	private Integer MaxTime = 10; // time in seconds

	/**
	 * to save the instances number
	 */
	private static Integer InstancesNumber = 0;

	/**
	 * Constructor for LogOutTimer. It's used to increase the number of instances of
	 * the class by 1.
	 */
	public LogOutTimer() {
		InstancesNumber++;
	}

	/**
	 * A getter method that used to get the number of instances of the class.
	 * 
	 * @return the number of instances of the class
	 */
	public static Integer getNumberOfInstances() {
		return InstancesNumber;
	}

	/**
	 * A setter method that used to set the time in seconds after which the user
	 * will be logged out.
	 * 
	 * @param Seconds time in seconds
	 */
	public void setLogOutTime(Integer Seconds) {
		MaxTime = Seconds;
	}

	/**
	 * The run method is used to check the mouse activity every second, if the mouse
	 * is inactive for a specific amount of time the user will be logged out.
	 */
	@Override
	public void run() {
		Integer timer = 0;

		while (true) {
			try {
				Thread.sleep(1000);
				System.out.println(timer);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			PointerInfo pf = MouseInfo.getPointerInfo();
			Point sbefore = pf.getLocation();

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			PointerInfo pf1 = MouseInfo.getPointerInfo();
			Point snext = pf1.getLocation();

			if (sbefore.equals(snext)) {
				timer++;
			} else
				timer = 0;

			if ((timer.equals(MaxTime))) {
				CommonMethods.setLogOutTimerFlag(true);
				ClientMethods.LogOut();
				InstancesNumber--;
				javafx.application.Platform.runLater(() ->
				CommonMethods.switchScene(getClass(),StartApplication.primaryStage, "LoginHomePage.fxml", "Logininterface.css"));
				break;

			}

		}

	}

}
