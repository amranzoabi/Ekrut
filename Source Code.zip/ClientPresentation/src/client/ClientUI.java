package client;

import javafx.application.Application;
import javafx.stage.Stage;
import othercontrollers.StartApplication;

/**
 * The ClientUI class extends the Application class and serves as the entry point for the JavaFX application.
 * It contains a single static instance of the ClientController class and a main method to launch the application.
 * The start method is overridden to create an instance of the StartApplication class and call its start method.
 * @author Mahran
 *
 */
public class ClientUI extends Application {
	/**
	 * only one instance
	 */
	public static ClientController chat; 
	

	
	/**
	 * The main method is the entry point of the application and used to launch the JavaFX Application.
	 *
	 * @param args command line arguments passed to the application
	 * @throws Exception when the launch method fails
	 */
	public static void main( String args[] ) throws Exception
	   { 
		    launch(args);  
	   }

	 /**
	  *  The start method is used to start the application and creates an instance of the StartApplication class.
	  *  @param primaryStage The stage of the application window
 	  *  @throws Exception when the start method fails
	  */
	@Override
	public void start(Stage primaryStage) throws Exception {
						  		
		 StartApplication aFrame = new StartApplication(); 
		 
		aFrame.start(primaryStage);
	}
}
