// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

package client;

import java.io.IOException;
import java.util.ArrayList;

import common.ChatIF;
import common.Commands;
import common.CommonMethods;
import common.Message;
import ocsf.client.AbstractClient;
import othercontrollers.StartApplication;

/**
 * This class overrides some of the methods defined in the abstract superclass
 * in order to give more functionality to the client.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;
 * @author Fran&ccedil;ois B&eacute;langer
 * @version July 2000
 */
public class ChatClient extends AbstractClient {
	// Instance variables **********************************************

	/**
	 * The interface type variable. It allows the implementation of the display
	 * method in the client.
	 */
	ChatIF clientUI;
	/**
	 * to save response
	 */
	public static boolean awaitResponse = false;
	/**
	 * ArrayList to save Login answer
	 */
	public static ArrayList<String> LoginAnswer;
	/**
	 * to save subscriber ID answer
	 */
	public static boolean CheckingSubscriberIDAnswer;
	/**
	 * ArrayList to save response for updates
	 */
	public static ArrayList<String> ResponseForUpdate;
	/**
	 * ArrayList to save the products
	 */
	public static ArrayList<ArrayList<Object>> ProductsArr;
	/**
	 * ArrayList to save all data about products
	 */
	public static ArrayList<?> AllDataAboutProductsArr;
	/**
	 * ArrayList to save cart answer
	 */
	public static ArrayList<String> AddToCartAnswer;
	/**
	 * ArrayList to save Orders
	 */
	public static ArrayList<ArrayList<Object>> OrdersArr;
	/**
	 * ArrayList to save Sale Requests
	 */
	public static ArrayList<ArrayList<Object>> SaleRequestsArr;
	/**
	 * ArrayList to save Monthly Orders Report
	 */
	public static ArrayList<ArrayList<Object>> MonthlyOrdersReportsArr;
	/**
	 * ArrayList to save Monthly Stock Report
	 */
	public static ArrayList<ArrayList<Object>> MonthlyStockReportsArr;
	/**
	 * ArrayList to save Monthly Customers Report
	 */
	public static ArrayList<ArrayList<Object>> MonthlyCustomerskReportsArr;
	/**
	 * ArrayList to save Customers Registrations
	 */
	public static ArrayList<ArrayList<Object>> CustomerRegistrationsArr;
	/**
	 * ArrayList to save workers Registrations
	 */
	public static ArrayList<ArrayList<Object>> WorkerRegistrationsArr;
	/**
	 * ArrayList to save Machines
	 */
	public static ArrayList<ArrayList<Object>> MachinesArr;
	/**
	 * ArrayList to save Machines And Product
	 */
	public static ArrayList<ArrayList<Object>> MachinesPlusProductArr;
	/**
	 * ArrayList to save Category profit Per Month
	 */
	public static ArrayList<ArrayList<Object>> CategoryProfitPerMonth;
	/**
	 * ArrayList to save Customers
	 */
	public static ArrayList<ArrayList<Object>> Customers;
	/**
	 * ArrayList to save users
	 */
	public static ArrayList<ArrayList<Object>> Users;
	/**
	 * ArrayList to save Numbers Of CustomersSubscribers
	 */
	public static ArrayList<ArrayList<Object>> NumbersOfCustomersSubscribers;
	/**
	 * ArrayList to save Category Stock Percentage Per Month
	 */
	public static ArrayList<ArrayList<Object>> CategoryStockPercentagePerMonth;
	/**
	 * to save/get Stock Report Answer
	 */
	public static boolean CheckStockReportAnswer;
	/**
	 * to save/get Orders Report Answer
	 */
	public static boolean CheckOrdersReportAnswer;
	/**
	 * to save/get Customers Report Answer
	 */
	public static boolean CheckCustomersReportAnswer;
	/**
	 * to save the low level of re stocking
	 */
	public static Integer LowLevel;
	/**
	 * ArrayList to save Users that also customers
	 */
	public static ArrayList<ArrayList<Object>> UsersJoinsCostumers;
	/**
	 * ArrayList to save the orders report data
	 */
	public static ArrayList<ArrayList<Object>> ProduceOrdersTableData;
	/**
	 * ArrayList to save the stock report data
	 */
	public static ArrayList<ArrayList<Object>> ProduceStockTableData;
	/**
	 * ArrayList to save the re stock requests
	 */
	public static ArrayList<ArrayList<Object>> RestockRequestsArr;
	/**
	 * ArrayList to save the products in the orders information
	 */
	public static ArrayList<ArrayList<Object>> ProductsInOrdersWithInfo;
	/**
	 * ArrayList to save the coupons
	 */
	public static ArrayList<ArrayList<Object>> CouponsArr;
	/**
	 * ArrayList to save the orders from machines
	 */
	public static ArrayList<ArrayList<Object>> OrdersFromMachineArr;
	/**
	 * ArrayList to save the IDNumber
	 */
	public static ArrayList<ArrayList<Object>> regesterIDNumberArr;
	/**
	 * ArrayList to save the password
	 */
	public static ArrayList<ArrayList<Object>> password;
	
	/**
	 * ArrayList to save the number of customers and subscribers table from database
	 */
	public static ArrayList<ArrayList<Object>> NumberOfCustomersSubscribers;
	/**
	 * ArrayList to save the credit card info
	 */
	public static ArrayList<ArrayList<Object>> CreditCardArr;
	
	

	// Constructors ****************************************************

	/**
	 * Constructs an instance of the chat client.
	 *
	 * @param host     The server to connect to.
	 * @param port     The port number to connect on.
	 * @param clientUI The interface type variable.
	 * @throws IOException IO Exception occurred
	 */


	public ChatClient(String host, int port, ChatIF clientUI) throws IOException {
		super(host, port); // Call the superclass constructor
		this.clientUI = clientUI;
		openConnection();
	}

	// Instance methods ************************************************

	/**
	 * This method handles all data that comes in from the server.
	 *
	 * @param msg The message from the server.
	 */

	/**
	 * Method that checks first Element in Array
	 * 
	 * @param arr     array
	 * @param Command command
	 * @return true/false
	 */
	public boolean CheckCommand(Object arr, String Command) {
		if (arr instanceof ArrayList<?>)
			if (((ArrayList<?>) arr).get(0).equals(Command)) {
				return true;
			}

		return false;
	}

	/**
	 * Method to handle all the commands from the server and deals with them
	 * according to given command
	 */
	@SuppressWarnings("unchecked")
	public void handleMessageFromServer(Object msg) {

		System.out.println("im at handlemessagefromserver");
		System.out.println("-> Message Recieved : " + msg);
		// check if the message is matrix then check command
		if (msg instanceof Message) {
			System.out.println("im at Message in client");
			Message clientrecieved = (Message) msg;
			String command = clientrecieved.getCommand();
			switch (command) {
			case Commands.Login:
				LoginAnswer = (ArrayList<String>) clientrecieved.getContents();
				break;

			case Commands.UpdateInfo:
				System.out.println("done updating");
				break;

			case Commands.Getallproducts:
				ProductsArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;

			case Commands.Getallorders:
				OrdersArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;

			case Commands.SaveSaleRequest:
				System.out.println("Savec Successfully");
				break;

			case Commands.Getallsalerequests:
				SaleRequestsArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;

			case Commands.Getallmonthlyrorderseports:
				MonthlyOrdersReportsArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
			case Commands.Getallmonthlystockreports:
				MonthlyStockReportsArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
			case Commands.Getallmonthlycostumersreports:
				MonthlyCustomerskReportsArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
			case Commands.RegisterNewCustomer:
				System.out.println("registiration done successfully");
				break;

			case Commands.RegisterNewWorker:
				System.out.println("registiration done successfully");
				break;

			case Commands.GetAllCustomersRegistirations:
				CustomerRegistrationsArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;

			case Commands.GetAllWorkersRegistirations:
				WorkerRegistrationsArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
			case Commands.UpdateCustomerRegistirationStatusToNotApproved:
				System.out.println("update done successfully");
				break;

			case Commands.GetAllMachinesJoinsProductsInsideThem:
				MachinesPlusProductArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
			case Commands.UpdateProductInMachineQuantity:
				System.out.println("done updating the product in machine quantity");
				break;
			case Commands.GetallproductsJoinsMachines:
				GetAllProductsJoinsMachines(clientrecieved);
				break;

			case Commands.OrderDone:
				System.out.println("saving the order data has been done successfully");
				break;

			case Commands.CancelOrder:
				System.out.println("done canceling the order");
				break;

			case Commands.ApproveOrderDelivery:
				System.out.println("order delivery approved");
				break;

			case Commands.GetCategoryProfitPerMonthTable:
				CategoryProfitPerMonth = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;

			case Commands.GetAllCustomers:
				Customers = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
			case Commands.GetAllUsers:
				Users = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;

			case Commands.GetNumberOfCustomers_Subscriber:
				NumbersOfCustomersSubscribers = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;

			case Commands.GetCategoryPercentagePerMonth:
				CategoryStockPercentagePerMonth = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;

			case Commands.CheckStockReports:
				CheckStockReportAnswer = (Boolean) clientrecieved.getContents();
				break;

			case Commands.CheckOrdersReports:
				CheckOrdersReportAnswer = (Boolean) clientrecieved.getContents();
				break;

			case Commands.CheckCustomerskReports:
				CheckCustomersReportAnswer = (Boolean) clientrecieved.getContents();
				break;

			case Commands.GetUsersJoinsCostumers:
				UsersJoinsCostumers = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;

			case Commands.InsertNewMonthlyCustomersReport:
				System.out.println("Insert done successfully");
				break;

			case Commands.GetProduceReportsTableData:
				ProduceOrdersTableData = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
			case Commands.GetProduceStockReportTableData:
				ProduceStockTableData = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;

			case Commands.MakeSale:
				System.out.println("making sale done successfully");
				break;

			case Commands.InsertRestockRequest:
				System.out.println("done inserting the sale request");
				break;

			case Commands.GetAllRestockRequests:
				RestockRequestsArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;

			case Commands.SetLowLevel:
				System.out.println("Done Changing LowLevel");
				break;

			case Commands.GetLowLevel:
				LowLevel = (Integer) clientrecieved.getContents();
				break;

			case Commands.ProductsJoinsOrdersJoinsProductsInOrders:
				ProductsInOrdersWithInfo = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;

			case Commands.TerminateClient:
				System.out.println("Client disconnected from the server side");
				break;
				
			case Commands.DeleteOrder:
				System.out.println("Deleted Order");
				break;
			case Commands.OrderPaymentDone:
				System.out.println("saving the order after payment  data has been done successfully");
				break;
			case Commands.RefundOrderAfterDelivery:
				System.out.println("order Refunded");
				break;
			case Commands.getMachines:
				MachinesArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
			case Commands.getCoupons:
				CouponsArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
			case Commands.deleteCoupon:
				System.out.println("Deleted coupon");
				break;
			case Commands.getOrderFromMachine:
				OrdersFromMachineArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
			case Commands.ChangeOrderStatus:
				System.out.println("changed Order");
				break;
			case Commands.getRegestrationIDNumber:
				regesterIDNumberArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
				
			case Commands.GetCostumersSubscribersNumberPerMonthTable:
				NumberOfCustomersSubscribers = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
				
			case Commands.CancelAppliededSale:
				System.out.println("Cancel Applied sale done successfully");
				break;
			
			case Commands.ChangeClientScreenToLogin:
				javafx.application.Platform.runLater(() ->
				CommonMethods.switchScene(getClass(),StartApplication.primaryStage, "LoginHomePage.fxml", "Logininterface.css"));
				break;
				
			case Commands.ChangeClientScreenToConnection:
				javafx.application.Platform.runLater(() ->
				CommonMethods.switchScene(getClass(),StartApplication.primaryStage, "ConnectionPage.fxml", "ConnectionInterface.css"));
				break;
				
			case Commands.DeleteRestockRequest:
				System.out.println("done deleting the request");
				break;
			case Commands.getUserPassword:
				password = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
			case Commands.getCreditCardInfo:
				CreditCardArr = (ArrayList<ArrayList<Object>>) clientrecieved.getContents();
				break;
			}

		}

		System.out.println("Done in chatclient");
		awaitResponse = false;

	}

	/**
	 * Method to disconnect client and exit
	 */
	public void DisconnectClientAndQuit() {
		try {
			System.out.println("closed connection");
			closeConnection();
			quit();
		} catch (IOException e) {

			System.out.println("nothing happend");
			e.printStackTrace();
		}
	}

	/**
	 * Method to get all the products in machine from database
	 * 
	 * @param clientrecieved what client receives
	 */
	public void GetAllProductsJoinsMachines(Message clientrecieved) {
		Object o = new Object();
		o = clientrecieved.getContents();
		System.out.println(("O=" + o + o.getClass()));
		if (o instanceof ArrayList<?>) {
			System.out.println("im at the checkpoint");
			AllDataAboutProductsArr = (ArrayList<?>) o;
			System.out.println("im done casting" + AllDataAboutProductsArr);
		}
		System.out.println("Done");
	}

	/**
	 * This method handles all data coming from the UI
	 *
	 * @param o The message from the UI.
	 */
	public void handleMessageFromClientUI(Object o) {
		try {
			openConnection();
			awaitResponse = true;
			System.out.println("-> Message sent : " + o);
			sendToServer(o);
			// wait for response
			while (awaitResponse) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			;
		} catch (IOException e) {
			// e.printStackTrace();
			clientUI.display("Could not send message to server: Terminating client." + e);
			quit();
		}
	}

	/**
	 * This method terminates the client.
	 */
	public void quit() {
		try {
			closeConnection();
		} catch (IOException e) {
		}
		System.exit(0);
	}
}
//End of ChatClient class
