package client;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import common.Commands;
import common.Message;
import javafx.event.Event;
import javafx.scene.Node;
import javafx.stage.Stage;

/**
 * This class contains methods related to client management, sending message,
 * closing a window and logging out a user, also contain variable UserID.
 * 
 * @author Mahran
 *
 */
public class ClientMethods {
	/**
	 * to save UserID
	 */
	public static int UserID;

	/**
	 * SendMessage method creates and sends a message with a command and contents
	 * passed as arguments to it, using the accept method of the chat field of the
	 * ClientUI class.
	 * 
	 * @param command  The command of the message
	 * @param contents The contents of the message
	 */
	public static void SendMessage(String command, Object contents) {
		Message send = new Message();
		send.setCommand(command);
		send.setContents(contents);
		ClientUI.chat.accept(send);
	}

	/**
	 * Close method is used to log out the user, send a termination message to the
	 * server and close the window.
	 * 
	 * @param event The event that trigger the close method
	 */
	public static void close(Event event) {
		LogOut();
		Stage stage = (Stage) ((Node) (event.getSource())).getScene().getWindow();
		stage.close();
		Timer T = new Timer();
		TimerTask closeEverythig = new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
			System.exit(0);	
			}
		};
		T.schedule(closeEverythig , 2000);
		ClientMethods.SendMessage( Commands.TerminateClient , "hey");
	}

	/**
	 * SaveUserID is used to save a user ID passed as a parameter.
	 *
	 * @param userid The user ID that needs to be saved
	 */
	public static void SaveUserID(int userid) {
		UserID = userid;
	}

	/**
	 * LogOut method is used to send a logout message to the server which contains
	 * the user's ID.
	 */
	public static void LogOut() {
		ClientMethods.SendMessage(Commands.Logout, UserID);
	}

}
