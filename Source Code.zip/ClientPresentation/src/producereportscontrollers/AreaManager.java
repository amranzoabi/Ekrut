package producereportscontrollers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

/**
 * This Class is a helper class for AreaManger Controller and the methods that
 * uses it this class is used to set/save information and show/get it
 * 
 * @author Shadi
 *
 */
public class AreaManager {
	private static String Area;
	private static HashMap<String, ArrayList<String>> AreaToLocations = new HashMap<String, ArrayList<String>>();

	/**
	 * Method to get area
	 * 
	 * @return return this area
	 */
	public static String getArea() {
		return Area;
	}

	/**
	 * Method to set area
	 * 
	 * @param area set this area to area
	 */
	public static void setArea(String area) {
		Area = area;
	}

	/**
	 * Method to set information about locations
	 */
	public static void SetAreaToLocations() {
		AreaToLocations.put("Haifa", new ArrayList<>(
				Arrays.asList("the Baha'i Gardens", "Down Town", "Maritime Museum", "Haifa-University")));
		AreaToLocations.put("Shefa-Amer",
				new ArrayList<>(Arrays.asList("Old City", "Down Town", "The Castle", "Alna'ma")));
		AreaToLocations.put("Karmiel", new ArrayList<>(Arrays.asList("Ort Braude", "Down Town", "North", "Park")));
		AreaToLocations.put("Tel-Aviv",
				new ArrayList<>(Arrays.asList("Jaffa", "Yemenite Quarter", "Tel Aviv Museum", "Tel-Aviv University")));
	}

	/**
	 * Method to get Locations for an area
	 * 
	 * @return return locations
	 */
	public static ArrayList<String> getLocations() {
		return AreaToLocations.get(Area);
	}

}
