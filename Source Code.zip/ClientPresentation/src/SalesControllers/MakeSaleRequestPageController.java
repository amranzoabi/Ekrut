package SalesControllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * This Class is a Make Sale Request Page Controller for
 * MakeSaleRequestPage.fxml ,it runs all the methods that functions the choices
 * of making a sale : Choose Template Choose Percentage Choose Area Write the
 * product's id that the manager wants to apply sale on Note: this class uses
 * help from CommonMethods class
 * 
 * @author Shadi
 *
 */
public class MakeSaleRequestPageController implements Initializable {
	@FXML
	private Label IDErrorLabel;
	/**
	 * to help with counting
	 */
	public static int counter;
	/**
	 * ComboBox to save/show the areas of sale
	 */
	@FXML
	private ComboBox<String> Area;

	/**
	 * ComboBox to save/show the percentage of sale
	 */
	@FXML
	private ComboBox<String> Percentage;

	/**
	 * TextField to get the Products Id
	 */
	@FXML
	private TextField ProductIDs;

	/**
	 * Button for request
	 */
	@FXML
	private Button Request;

	/**
	 * ComboBox to save template
	 */
	@FXML
	private ComboBox<String> Template;

	/**
	 * initialize all the data needed in that class
	 *
	 */
	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		CommonMethods.continueWithEnter(ProductIDs, Request);
		String[] AreaContent = { "Haifa", "Shefa-Amer", "Karmiel", "Tel-Aviv" };
		String[] TemplateContent = { "BlackFriday", "Nearest Holiday", "Dead Hours", "Weekend" };
		String[] PercentageContent = { "5%", "10%", "15%", "20%", "25%", "30%", "40%", "45%", "50%" };
		ObservableList<String> Arealist = FXCollections.observableArrayList(AreaContent);
		ObservableList<String> Templatelist = FXCollections.observableArrayList(TemplateContent);
		ObservableList<String> Percentagelist = FXCollections.observableArrayList(PercentageContent);
		Area.setItems(Arealist);
		Template.setItems(Templatelist);
		Percentage.setItems(Percentagelist);
		CommonMethods.textLengthLegality(ProductIDs, 40);

	}

	/**
	 * Method for going back to the previous page in this case the Area Manager Page
	 * 
	 * @param event event if the the arrow (back) icon clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void back(MouseEvent event) throws Exception // close window
	{
		CommonMethods.switchSceneBack(getClass(), event);
	}

	/**
	 * Method for clicking the help icon ,a windows will show with a message and
	 * explain the scene/page
	 * 
	 * @param event event of the help icon clicked the scene/page and what every
	 *              button do
	 * @throws Exception Exception will be thrown if an error occurs from Customer
	 *                   class
	 */

	public void help(MouseEvent event) throws Exception {

		CommonMethods
				.help("This is Create Sale Request Page" + "\nYou Can Choose the template (holiday/reason) for the sale"
						+ "\nYou Can Choose the Percentage that you want " + "\nYou Can Choose the Area of the sale"
						+ "\nYou Can write the products that you want to apply sale to"
						+ "\nPress Create and the sale request would be created", getClass());
	}

	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}

	/**
	 * Method to create and save the sale request in Data Base by clicking on create
	 * Button in case any field is empty an error message/label would be thrown
	 * 
	 * @param event event of Clicking on create Button
	 */
	public void Request(ActionEvent event) {
		ClientMethods.SendMessage(Commands.Getallproducts, "Nothing");
		ArrayList<ArrayList<Object>> arr1 = new ArrayList<ArrayList<Object>>();
		arr1 = ChatClient.ProductsArr;
		String products = ProductIDs.getText();
		String[] productsArr = products.split(",");
		int productFlag = 0;

		if (Template.getValue() == null || Percentage.getValue() == null || Area.getValue() == null
				|| ProductIDs.getText() == null || ProductIDs.getText().equals("")) {
			IDErrorLabel.setText("You must choose all fields and fill them correctly");
			ProductIDs.clear();
		} else {
			for (int i = 0; i < productsArr.length; i++) {
				if (!isNumeric(productsArr[i])) {
					IDErrorLabel.setText("one product or more isn't correct");
					productFlag = 1;
					break;

				} else {
					if (Integer.parseInt(productsArr[i]) > arr1.size() || Integer.parseInt(productsArr[i]) < 1
							|| checkProductExists(productsArr[i])) {

						IDErrorLabel.setText("one product or more isn't found in this area");
						productFlag = 1;
						break;
					}

				}
			}

			if (productFlag == 0) {
				checkAndSaveInDataBase();
			}
		}

	}

	/**
	 * Method to get Products ID
	 * 
	 * @return return products id
	 */
	public String getProductsIDs() {
		return ProductIDs.getText().toString();
	}

	/**
	 * Method to get the template (the reason/holiday for the sale)
	 * 
	 * @return return template
	 */
	public String getTemplate() {
		String save = (String) Template.getValue();
		return save;
	}

	/**
	 * Method to get the area
	 * 
	 * @return return this area
	 */
	public String getArea() {
		String save = (String) Area.getValue();
		return save;
	}

	/**
	 * Method to get the percentage
	 * 
	 * @return return this percentage
	 */
	public String getPercentage() {
		String save = (String) Percentage.getValue();
		return save;
	}

	/**
	 * Method to check if the string is a number
	 * 
	 * @param string string
	 * @return return true in case its a number else false
	 */
	private boolean isNumeric(String string) {
		int intValue;

		if (string == null || string.equals("")) {
			return false;
		}

		try {
			intValue = Integer.parseInt(string);
			return true;
		} catch (NumberFormatException e) {

			System.out.println("Error: in is numeric");
		}
		return false;
	}

	/**
	 * Method to check if sale exist a message would be shown to the user else the
	 * sale request would be added
	 */
	private void checkAndSaveInDataBase() {
		boolean flag = false;
		ArrayList<ArrayList<Object>> arrdata = new ArrayList<ArrayList<Object>>();
		ClientMethods.SendMessage(Commands.Getallsalerequests, "nothing");
		arrdata = ChatClient.SaleRequestsArr;
		;
		for (int i = 0; i < arrdata.size(); i++)
			if (arrdata.get(i).get(0).equals(Template.getValue() + "")
					&& arrdata.get(i).get(2).equals(ProductIDs.getText() + "")
					&& arrdata.get(i).get(4).equals(Area.getValue() + "")
					&& arrdata.get(i).get(5).equals(Percentage.getValue()))
				flag = true;

		if (flag == false) {
			IDErrorLabel.setText("");
			String pi = getProductsIDs();
			String temp = getTemplate();
			String area = Area.getValue();
			String per = Percentage.getValue();
			ArrayList<String> arr = new ArrayList<String>();
			arr.add(temp);
			arr.add(null); // null because the primary key of the table is auto_increment
			arr.add(pi);
			arr.add("NOT_Applyed");
			arr.add(area);
			arr.add(per);
			ClientMethods.SendMessage(Commands.SaveSaleRequest, arr);
			CommonMethods.CompletionMessage("Sale has been created for these products\n" + pi, getClass());
			System.out.println("saving request done");
			ProductIDs.clear();
		} else
			IDErrorLabel.setText("this sale has been made");

	}

	/**
	 * Method to check if product exists in the area that was choosen
	 * 
	 * @param productid the product id
	 * @return true if product exists else false
	 */
	private boolean checkProductExists(String productid) {
		ClientMethods.SendMessage(Commands.GetAllMachinesJoinsProductsInsideThem, "Nothing");
		ArrayList<ArrayList<Object>> arr1 = new ArrayList<ArrayList<Object>>();
		arr1 = ChatClient.MachinesPlusProductArr;
		for (int i = 0; i < arr1.size(); i++)
			if ((arr1.get(i).get(4) + "").equals(productid) && Area.getValue().equals(arr1.get(i).get(2) + ""))
				return false;

		return true;
	}

}
