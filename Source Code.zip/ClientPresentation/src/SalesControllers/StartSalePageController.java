package SalesControllers;

import java.net.URL;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import homepagescontrollers.MarketingWorkerController;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

/**
 * This class is a Apply Sales Page Controller for StartSalePage.fxml the
 * function of this class is to display all sales associated with the area of
 * Marketing Manager Note: this class uses help from CommonMethods class
 * 
 * @author Shadi
 *
 */
public class StartSalePageController implements Initializable {

	/**
	 * Label to show the area
	 */
	@FXML
	private Label IDDownPageArea;

	Connection conn;

	/**
	 * TableView to show the information in a table
	 */
	@FXML
	private TableView<TableRow> tableView;

	/**
	 * TableColumn to show the holidays/reason
	 */
	@FXML
	private TableColumn<TableRow, String> Template;

	/**
	 * TableColumn to show the id of the request
	 */
	@FXML
	private TableColumn<TableRow, String> RequestID;

	/**
	 * TableColumn to show to IDs of the products
	 */
	@FXML
	private TableColumn<TableRow, String> ProductsIDs;

	/**
	 * TableColumn for Approve Buttons
	 */
	@FXML
	private TableColumn<TableRow, Button> ApplySale;

	/**
	 * initialize all the data needed in that class
	 */
	ObservableList<TableRow> data;

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		IDDownPageArea.setText(MarketingWorkerController.workingarea);
		Template.setCellValueFactory(new PropertyValueFactory<TableRow, String>("Template"));
		RequestID.setCellValueFactory(new PropertyValueFactory<TableRow, String>("RequestID"));
		ProductsIDs.setCellValueFactory(new PropertyValueFactory<TableRow, String>("ProductsIDs"));
		ApplySale.setCellValueFactory(new PropertyValueFactory<TableRow, Button>("ApplySale"));

		ArrayList<ArrayList<Object>> arr = new ArrayList<ArrayList<Object>>();
		ClientMethods.SendMessage(Commands.Getallsalerequests, "nothing");
		arr = ChatClient.SaleRequestsArr;
		;
		System.out.println(arr);
		data = tableView.getItems();
		if (arr != null)
			for (ArrayList<Object> inside : arr) {
				String saleArea = (String) inside.get(4);
				if (saleArea.equals(MarketingWorkerController.workingarea)) {
					TableRow save = new TableRow();
					save.setTemplate((String) inside.get(0));
					save.setRequestID((Integer) inside.get(1));
					save.setProductsIDs((String) inside.get(2));
					save.setApplySale(MakeApplySaleButton(save.getRequestID(), save, inside));

					String RequestStatus = (String) inside.get(3);

					if (RequestStatus.equals("NOT_Applyed"))
						data.add(save);
				}

			}
		tableView.setItems(data);
	}

	/**
	 * Method to create and connect a Apply Sale button
	 * 
	 * @param requestid the request id
	 * @param row the current row 
	 * @param DataToSend the data we need
	 * @return Apply sale Button
	 */

	public Button MakeApplySaleButton(int requestid, TableRow row, ArrayList<Object> DataToSend) {
		Button applySalebtn = new Button("Apply Sale");
		applySalebtn.requestFocus();
		applySalebtn.setOnMouseClicked(event -> {
			ClientMethods.SendMessage(Commands.MakeSale, DataToSend);
			data.remove(row);
		});
		applySalebtn.setStyle("-fx-background-radius: 50;" + "-fx-background-color: #90BB14;" + "-fx-font-weight:bold;"
				+ "-fx-font-size: 12px;" + "-fx-effect: dropshadow( three-pass-box , #A2A09F, 13, 0 , 7 , 7 );"
				+ "-fx-text-fill: white;");
		return applySalebtn;

	}

	/**
	 * Method to remove row from the table (sale request)
	 */
	void removerow() {
		int selectedID = tableView.getSelectionModel().getSelectedIndex();
		System.out.println("selectedID=" + selectedID);
		tableView.getItems().remove(selectedID);
	}

	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event on clicking the close X icon
	 * @throws Exception exception if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}

	/**
	 * Method for going back to the page that precedes the current page
	 * 
	 * @param event event on clicking back arrow icon
	 * @throws Exception exception if an error occurs
	 */
	public void back(MouseEvent event) throws Exception {
		CommonMethods.switchSceneBack(getClass(), event);
	}

	/**
	 * Method for showing help information, a popup with explanation of current page
	 * will show up to the user
	 * 
	 * @param event event on clicking the help icon
	 * @throws Exception exception if an error occurs
	 */
	public void help(MouseEvent event) throws Exception {
		CommonMethods.help("This is Apply Sales Page:" + "\nYou Can Apply the Sale on a product/s", getClass());
	}

	/**
	 * 
	 * This class is a TableRow for the table which the request will be shown in
	 * parameters of the class are Template, RequestID, ProductsIDs another variable
	 * is a Button (Apply Sale), this button will be used to issue the sale the
	 * class has a constructor that allows us to set the data through it, we also
	 * have getters and setters for each variables as well we use this class mainly
	 * to add each instance into a row of the table we have
	 * 
	 * @author Shadi
	 *
	 */
	public class TableRow {

		/**
		 * Integer RequestID to store ID of sale
		 */
		private Integer RequestID;
		/**
		 * String ProductIDs to store IDs of products included in sale
		 */
		private String ProductsIDs;
		/**
		 * Button ApplySale that confirms the application of sale
		 */
		private Button ApplySale;
		/**
		 * String Template to hold what kind of sale we're doing
		 */
		private String Template;

		/**
		 * Constructor for TableRow class - that allows us to initiate an instance with
		 * values already assigned
		 * 
		 * @param template    string
		 * @param requestID   integer
		 * @param productsIDs string
		 * @param applySale   button
		 */
		public TableRow(String template, Integer requestID, String productsIDs, Button applySale) {
			super();
			Template = template;
			RequestID = requestID;
			ProductsIDs = productsIDs;
			ApplySale = applySale;
		}

		/**
		 * Constructor for TableRow class - we can use this constructor to initiate an
		 * instance of TableRow without assigning any values
		 */
		public TableRow() {

		}

		/**
		 * getter for value Template of this User class
		 * 
		 * @return Template value of current (this) instance
		 */
		public String getTemplate() {
			return Template;
		}

		/**
		 * setter for value Template of this User class
		 * 
		 * @param template is used to be assigned to Template's value
		 */
		public void setTemplate(String template) {
			Template = template;
		}

		/**
		 * getter for value RequestID of this User class
		 * 
		 * @return RequestID value of current (this) instance
		 */
		public Integer getRequestID() {
			return RequestID;
		}

		/**
		 * setter for value RequestID of this User class
		 * 
		 * @param requestID is used to be assigned to RequestID's value
		 */
		public void setRequestID(Integer requestID) {
			RequestID = requestID;
		}

		/**
		 * getter for value ProductsIDs of this User class
		 * 
		 * @return ProductsIDs value of current (this) instance
		 */
		public String getProductsIDs() {
			return ProductsIDs;
		}

		/**
		 * setter for value ProductsIDs of this User class
		 * 
		 * @param productsIDs is used to be assigned to ProductsIDs's value
		 */
		public void setProductsIDs(String productsIDs) {
			ProductsIDs = productsIDs;
		}

		/**
		 * getter for value ApplySale of this User class
		 * 
		 * @return ApplySale value of current (this) instance
		 */
		public Button getApplySale() {
			return ApplySale;
		}

		/**
		 * setter for value ApplySale of this User class
		 * 
		 * @param applySale is used to be assigned to ApplySale's value
		 */
		public void setApplySale(Button applySale) {
			ApplySale = applySale;
		}

	}
}
