package homepagescontrollers;

import client.ClientMethods;
import common.CommonMethods;
import interfaces.CloseablePage;
import interfaces.HelpablePage;
import interfaces.SetableHomepage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

/**
 * This Class is a Operation Worker Page Controller for
 * OperationsWorkerPage.fxml ,it runs all the methods that functions the choices
 * of the Marketing Worker : to Renew Stock Note: this class uses help from
 * CommonMethods class
 * 
 * @author Amran
 *
 */
public class OPWorkerHomepageController implements SetableHomepage, CloseablePage, HelpablePage {

	@FXML
	private Label IDArea;

	/**
	 * Label to show/save the stock percentage
	 */
	@FXML
	private Label IDStockPer;

	/**
	 * Label to show/save the total products
	 */
	@FXML
	private Label IDTotalProducts;

	/**
	 * Label to show/save the user ID
	 */
	@FXML
	private Label IDid;

	/**
	 * Label to show/save the user Name
	 */
	@FXML
	private Label IDnamelabel1;

	/**
	 * Label to show/save page title
	 */
	@FXML
	private Label IDwelcome1;
	/**
	 * Label to show Area
	 */
	@FXML
	private Label LBLArea;
	/**
	 * Label to show user id
	 */
	@FXML
	private Label LBLUserID;
	/**
	 * to save the area that the workers works in
	 */
	public static String workingarea;
	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);

	}

	/**
	 * Method for logging out from customer page , switches stage to the login page
	 * 
	 * @param event event of the logout Button clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void logout(ActionEvent event) throws Exception {

		ClientMethods.LogOut();
		CommonMethods.switchToLoginScene(getClass(), event);
	}

	/**
	 * Method for clicking the help icon ,a windows will show with a message and
	 * explain the scene/page
	 * 
	 * @param event event of the help icon clicked the scene/page and what every
	 *              button do
	 * @throws Exception Exception will be thrown if an error occurs from Customer
	 *                   class
	 */
	public void help(MouseEvent event) throws Exception {
		CommonMethods
				.help("This is the Operations Worker homepage:\n" + "\nPress Renew Stock to start renew stock process"
						+ "\nPress Logout to logout from your current page", getClass());
	}

	/**
	 * Method for clicking Renew Stock ,switches stage to the next page(to Confirm
	 * stock renewed)
	 * 
	 * @param event event of the Renew Stock request Button clicked
	 * @throws Exception Exception Exception will be thrown if an error occurs when
	 *                   switching the stage
	 */
	public void renewStock(ActionEvent event) throws Exception {
		CommonMethods.switchScene(getClass(), "DoneRestockingPage.fxml", "DoneRestockingPage.css", event);
	}

	/**
	 * Method to set Marketing Manager Information
	 */
	@Override
	public void SetPageInfo(String Label, String UserID, String Area) {

		IDnamelabel1.setText(Label);
		LBLUserID.setText(UserID);
		LBLArea.setText(Area);
		workingarea = Area.substring(6);
	}

}
