package homepagescontrollers;



import client.ClientMethods;
import common.CommonMethods;
import customermethods.Customer;
import interfaces.SetableHomepage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * This Class is a Customer Page Controller for CustomerPage.fxml ,it runs all
 * the methods that functions the choices of the customer : to Start Order to
 * manage Orders to MyCart Note: this class uses help from Customer and Order
 * class to set and get some functionalities
 * 
 * @author Mahran
 *
 */
public class CustomerPageInterFaceController implements  SetableHomepage {

	/**
	 * Label that shows the customer's type {subscriber,regular}
	 */
	@FXML
	private Label IDCustomerType;
	/**
	 * Label that shows the customer's statues {approved , suspended..}
	 */
	@FXML
	private Label IDCustomerStatues;
	/**
	 * Label that shows the customer's id
	 */
	@FXML
	private Label IDCustomerid;
	/**
	 * Label that shows the customer's number of orders that he made
	 */
	@FXML
	private Label IDNumOrders;
	/**
	 * Label that shows the customer's name
	 */
	@FXML
	private Label IDnamelabel1;
	/**
	 * ImageView that contains a small cart icon for decoration
	 */
	@FXML
	private ImageView IDcartimg1;
	/**
	 * ImageView that contains a small managing kit icon for decoration
	 */
	@FXML
	private ImageView IDsmanageordersimg1;
	/**
	 * ImageView that contains a small starting choice icon for decoration
	 */
	@FXML
	private ImageView IDstartorderimg1;
	/**
	 * Button to MyCart
	 */
	@FXML
	private Button IDcart;
	/**
	 * Button to Logout
	 */
	@FXML
	private Button logoutBtn;
	/**
	 * Button to Manage Orders
	 */
	@FXML
	private Button manageO1;
	/**
	 * Button to Start Order
	 */
	@FXML
	private Button startO1;
	/**
	 * Label to show the user id
	 */
	@FXML
	private Label LBLUserID;

	/**
	 * to save and show the stage
	 */
	Stage stage;
	/**
	 * to save and the root
	 */
	Parent root;


	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {

		ClientMethods.close(event);

	}

	/**
	 * Method for logging out from customer page , switches stage to the login page
	 * 
	 * @param event event of the logout Button clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void logout(ActionEvent event) throws Exception {

		ClientMethods.LogOut();
		CommonMethods.switchToLoginScene(getClass(), event);
	}

	/**
	 * Method for clicking the help icon ,a windows will show with a message and
	 * explain the scene/page
	 * 
	 * @param event event of the help icon clicked the scene/page and what every
	 *              button do
	 * @throws Exception Exception will be thrown if an error occurs from Customer
	 *                   class
	 */
	public void help(MouseEvent event) throws Exception {

		CommonMethods.help("This is a Customer homepage:\n" + "\nPress Start Order to create a new order"
				+ "\nPress Manage Orders to check your previous Orders(or cancel an order)"
				+ "\nPress Cart to go to your Current Cart(saved)" + "\nPress Logout to logout from your current page",
				this.getClass());

	}



	/**
	 * Method that changes stages when Start Order button is clicked
	 * 
	 * @param event event of the Start Order Button clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void startOrder(ActionEvent event) throws Exception {

		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		CommonMethods.switchScene(getClass(), stage, "StartOrderInterFace.fxml", "StartOrderInterFace.css");

	}

	/**
	 * Method that changes stages when My Cart button is clicked
	 * 
	 * @param event event of the My Cart Button clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void myCart(ActionEvent event) throws Exception {
		CommonMethods.switchScene(getClass(), "CartPage.fxml", "CartPage.css", event);
	}

	/**
	 * Method that changed stages when Manage Orders button is clicked
	 * 
	 * @param event event of the Manage Orders Button clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void manageOrders(ActionEvent event) throws Exception {
		CommonMethods.switchScene(getClass(), "ManageOrdersPage.fxml", "ManageOrdersPage.css", event);
	}

	/**
	 * Method to set Customers Information
	 * Note: area in customer page is a type of customer not the area(need to change)
	 */
	@Override
	public void SetPageInfo(String Label, String UserID, String Area) {
		LBLUserID.setText(UserID);
		Customer.customerID = UserID.substring(13);
		IDnamelabel1.setText(Label);
		IDCustomerType.setText("Type: "+Area);

	}
}
