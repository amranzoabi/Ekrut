package homepagescontrollers;

import client.ClientMethods;
import common.CommonMethods;
import interfaces.SetableHomepage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * This Class is a Marketing Worker Page Controller for
 * MarketingWorkerHomePage.fxml ,it runs all the methods that functions the
 * choices of the Marketing Worker : to Apply Sale Request Note: this class uses
 * help from CommonMethods class
 * 
 * @author Mahran
 *
 */
public class MarketingWorkerController implements SetableHomepage {
	/**
	 * to save the stage
	 */
	private Stage stage;
	/**
	 * Label to show/save the user ID
	 */
	@FXML
	private Label IDMWid;
	/**
	 * Label to show/save page title
	 */
	@FXML
	private Label IDwelcome1;
	/**
	 * Label to show/save the user Name
	 */
	@FXML
	private Label IDnamelabel1;
	/**
	 * Label to show/save the user Role
	 */
	@FXML
	private Label IDRole;
	/**
	 * Label to show/save the user Area
	 */
	@FXML
	private Label IDArea;
	/**
	 * Label to show/save the user Status
	 */
	@FXML
	private Label IDMWStatues;
	/**
	 * Label to show the worker area
	 */
	@FXML
	private Label LBLArea;
	/**
	 * Label to show label id
	 */
	@FXML
	private Label LBLUserID;
	/**
	 * to save the area that the workers works in
	 */
	public static String workingarea;

	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}

	/**
	 * Method for clicking Apply Sale Request ,switches stage to the next page(to
	 * Apply the sale request)
	 * 
	 * @param event event of the Apply Sale request Button clicked
	 */
	public void ApplySaleRequest(ActionEvent event) {
		stage = (Stage) ((Node) (event.getSource())).getScene().getWindow();
		CommonMethods.switchScene(getClass(), stage, "StartSalePage.fxml", "StartSaleInterface.css");
	}

	/**
	 * Method for logging out from customer page , switches stage to the login page
	 * 
	 * @param event event of the logout Button clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void logout(ActionEvent event) throws Exception {
		ClientMethods.LogOut();
		CommonMethods.switchToLoginScene(getClass(), event);
	}

	/**
	 * Method for clicking the help icon ,a windows will show with a message and
	 * explain the scene/page
	 * 
	 * @param event event of the help icon clicked the scene/page and what every
	 *              button do
	 * @throws Exception Exception will be thrown if an error occurs from Customer
	 *                   class
	 */

	public void help(MouseEvent event) throws Exception {
		CommonMethods.help(
				"This is the Marketing Woker homepage:\n"
						+ "\nPress Apply Sale Request to apply the sale that was received from the marketing manager ",
				getClass());
	}

	/**
	 * Method to set Marketing Manager Information
	 */
	@Override
	public void SetPageInfo(String Label, String UserID, String Area) {
		IDnamelabel1.setText(Label);
		LBLArea.setText(Area);
		LBLUserID.setText(UserID);
		workingarea = Area.substring(6);

	}

}
