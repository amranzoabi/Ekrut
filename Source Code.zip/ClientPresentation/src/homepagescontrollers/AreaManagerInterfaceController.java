package homepagescontrollers;

import client.ClientMethods;
import common.CommonMethods;
import interfaces.SetableHomepage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

/**
 * This Class is a Area Manager Page Controller for AreaManagerPage.fxml ,it
 * runs all the methods that functions the choices of the Area Manager : to
 * Review Worker Register to Review Customer Register to Command Re Stock to
 * Produce Orders Report to Produce Customers Report to Produce Stock Report
 * Note: this class uses help from CommonMethods class
 * 
 * @author Amran
 *
 */
public class AreaManagerInterfaceController implements SetableHomepage {

	/**
	 * Label to show area
	 */
	@FXML
	private Label LBLArea;

	/**
	 * Label to show user id
	 */
	@FXML
	private Label LBLUserID;
	/**
	 * Label to show the name
	 */
	@FXML
	private Label IDnamelabel1;
	/**
	 * to save the area that the workers works in
	 */
	public static String workingarea;

	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event on clicking the close X icon 
	 * @throws Exception exception if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);

	}

	/**
	 * Method for logging out of current account, the window will be redirected to
	 * the login screen
	 * 
	 * @param event event on clicking logout button
	 * @throws Exception exception if an error occurs
	 */
	public void logout(ActionEvent event) throws Exception {
		ClientMethods.LogOut();
		CommonMethods.switchToLoginScene(getClass(), event);
	}

	/**
	 * Method for displaying help popup message
	 * 
	 * @param event event on clicking help icon
	 * @throws Exception exception if an error occurs
	 */
	@SuppressWarnings("static-access")
	public void help(MouseEvent event) throws Exception {
		CommonMethods.help("This is the AreaManager homepage:\n"
				+ "\nPress Review Registrations to review requests(for Customer or worker)"
				+ "\nPress Produce Stock Reports to produce new reports"
				+ "\nPress Produce Orders Reports to produce new reports"
				+ "\nPress Produce Customers Reports to produce new reports"
				+ "\nPress Logout to logout from your current page", getClass());

	}

	/**
	 * Method for redirecting page - this method will redirect the user to the
	 * commandRestock page
	 * 
	 * @param event event on clicking the command restock button
	 * @throws Exception exception if an error occurs
	 */
	public void commandRestock(ActionEvent event) throws Exception {
		CommonMethods.switchScene(getClass(), "CommandRestockPage.fxml", "CommandRestockInterface.css", event);
	}

	/**
	 * Method for redirecting page - this method will redirect the user to the
	 * reviewRegistrations page
	 * 
	 * @param event event on clicking review customer registration button
	 * @throws Exception exception if an error occurs
	 */
	public void reviewCustomerRegister(ActionEvent event) throws Exception {
		CommonMethods.switchScene(getClass(), "ReviewCustomersRegistrationsPage.fxml",
				"ReviewRegistrationsInterface.css", event);
	}

	/**
	 * Method for redirecting page - this method will redirect the user to the
	 * reviewRegistrations page
	 * 
	 * @param event event on clicking review worker registration button
	 * @throws Exception exception if an error occurs
	 */
	public void reviewWorkerRegister(ActionEvent event) throws Exception {
		CommonMethods.switchScene(getClass(), "ReviewWorkersRegistrationsPage.fxml", "ReviewRegistrationsInterface.css",
				event);
	}

	/**
	 * Method for redirecting page - this method will redirect the user to the
	 * stockReport page
	 * 
	 * @param event event on clicking stock report
	 * @throws Exception exception if an error occurs
	 */
	public void stockReport(ActionEvent event) throws Exception {
		CommonMethods.switchScene(getClass(), "ProduceStockPage.fxml", "ProduceStockInterface.css", event);
	}

	/**
	 * Method for redirecting page - this method will redirect the user to the
	 * orderReport page
	 * 
	 * @param event event on clicking order report
	 * @throws Exception exception if an error occurs
	 */
	public void ordersReport(ActionEvent event) throws Exception {

		CommonMethods.switchScene(getClass(), "ProduceOrdersPage.fxml", "ProduceOrdersInterface.css", event);
	}

	/**
	 * Method for redirecting page - this method will redirect the user to the
	 * customersReport page
	 * 
	 * @param event event on clicking customer report
	 * @throws Exception exception if an error occurs
	 */
	public void customersReport(ActionEvent event) throws Exception {

		CommonMethods.switchScene(getClass(), "ProduceCustomersPage.fxml", "ProduceCustomersInterface.css", event);
	}

	/**
	 * Method to set information
	 */
	@Override
	public void SetPageInfo(String Label, String UserID, String Area) {
		IDnamelabel1.setText(Label);
		LBLUserID.setText(UserID);
		LBLArea.setText(Area);
		workingarea = Area.substring(6);
	}

}
