package homepagescontrollers;

import client.ClientMethods;
import common.CommonMethods;
import interfaces.SetableHomepage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * This Class is a Marketing Manger Page Controller for
 * MarketingManagerHomePage.fxml ,it runs all the methods that functions the
 * choices of the Marketing Manager : to Create Sale to Manage Sale Requests
 * Note: this class uses help from CommonMethods class
 * 
 * @author Mahran
 *
 */
public class MarketingManagerController implements SetableHomepage {
	/**
	 * to save the stage
	 */
	private Stage stage;
	/**
	 * Label to show/save the user ID
	 */
	@FXML
	private Label IDid;
	/**
	 * Label to show/save the user Name
	 */
	@FXML
	private Label IDnamelabel1;
	/**
	 * Label to show/save the user role
	 */
	@FXML
	private Label IDRole;
	/**
	 * Label to show/save the user status
	 */
	@FXML
	private Label IDStatues;
	/**
	 * Label to show/save the Page title
	 */
	@FXML
	private Label IDwelcome1;
	/**
	 * Label to show user id
	 */
	@FXML
	private Label LBLUserID;


	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}

	/**
	 * Method for clicking the Create Sale ,switches stage to the next page(to
	 * command a sale)
	 * 
	 * @param event event of the Create Sale Button clicked
	 */
	public void MakeSaleRequest(ActionEvent event) {
		stage = (Stage) ((Node) (event.getSource())).getScene().getWindow();
		CommonMethods.switchScene(getClass(), stage, "MakeSaleRequestPage.fxml", "StartSaleInterface.css");
	}

	/**
	 * Method for clicking the Manage Sale Requests ,switches stage to the next
	 * page(to Manage the sales requests)
	 * 
	 * @param event event of the Manage Sales Requests Button clicked
	 */
	public void manageSaleRequests(ActionEvent event) {
		stage = (Stage) ((Node) (event.getSource())).getScene().getWindow();
		CommonMethods.switchScene(getClass(), stage, "ManageSaleRequestsPage.fxml",
				"ManageSaleRequestsPageInterface.css");
	}

	/**
	 * Method for logging out from customer page , switches stage to the login page
	 * 
	 * @param event event of the logout Button clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void logout(ActionEvent event) throws Exception {
		ClientMethods.LogOut();
		CommonMethods.switchToLoginScene(getClass(), event);
	}

	/**
	 * Method for clicking the help icon ,a windows will show with a message and
	 * explain the scene/page
	 * 
	 * @param event event of the help icon clicked the scene/page and what every
	 *              button do
	 * @throws Exception Exception will be thrown if an error occurs from Customer
	 *                   class
	 */
	public void help(MouseEvent event) throws Exception {

		CommonMethods.help("This is the Marketing Manager homepage:\n" + "\nPress Create Sale to create a new sale "
				+ "\nPress Manage Sale Requests to manage the sale requests"
				+ "\nPress Logout to logout from your current page", getClass());

	}

	/**
	 * Method to set Marketing Manager Information
	 */
	@Override
	public void SetPageInfo(String Label, String UserID, String Area) {

		IDnamelabel1.setText(Label);
		LBLUserID.setText(UserID);
	}

}
