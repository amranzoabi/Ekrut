package homepagescontrollers;

import java.net.URL;
import java.util.ResourceBundle;

import client.ClientMethods;
import common.CommonMethods;
import interfaces.SetableHomepage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

/**
 * This Class is a Service Agent Page Controller for ServiceAgentHomePage.fxml
 * ,it runs all the methods that functions the choices of the Service Agent : to
 * Register New Customer to Register New Worker Note: this class uses help from
 * CommonMethods class
 * 
 * @author Mahran
 *
 */
public class ServiceAgentController implements Initializable, SetableHomepage {

	@FXML
	private Label LBLUserID;

	@FXML
	private Label IDSubscriberReq;
	/**
	 * Label to show user id
	 */
	@FXML
	private Label IDUserId;
	/**
	 * Label to show user requests
	 */
	@FXML
	private Label IDUserRequests;
	/**
	 * Label to show name
	 */
	@FXML
	private Label IDnamelabel1;

	/**
	 * Label to show/save page title
	 */
	@FXML
	private Label IDwelcome1;

	/**
	 * initialize Data
	 *
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		ObservableList<String> TypeArr = FXCollections.observableArrayList();
		TypeArr.addAll("Costumer", "Subscriber", "Service Agent", "Marketing Worker", "Marketing Manager",
				"Delivery Operator", "Area Manager", "Operations Worker", "CEO");

	}

	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}

	/**
	 * Method for logging out from customer page , switches stage to the login page
	 * 
	 * @param event event of the logout Button clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void logout(ActionEvent event) throws Exception {
		ClientMethods.LogOut();
		CommonMethods.switchToLoginScene(getClass(), event);
	}

	/**
	 * Method for clicking the help icon ,a windows will show with a message and
	 * explain the scene/page
	 * 
	 * @param event event of the help icon clicked the scene/page and what every
	 *              button do
	 * @throws Exception Exception will be thrown if an error occurs from Customer
	 *                   class
	 */
	public void help(MouseEvent event) throws Exception {
		CommonMethods.help("This is the Service agent homepage:\n"
				+ "\nPress Register New Customer to register a new user as a customer"
				+ "\nPress Register New Worker to register a new user as a Worker"
				+ "\nPress Logout to logout from your current page", getClass());

	}

	/**
	 * Method to set the name label
	 */
	public void setNameLabel() {
		IDnamelabel1.setText("Agent Manager");
	}

	/**
	 * Method for clicking Register New Worker ,switches stage to the next page(to
	 * fill Worker information for registration)
	 * 
	 * @param event event of the Register New Worker Button clicked
	 *                   switching the stage
	 */
	public void registerUser(ActionEvent event) {
		CommonMethods.switchScene(getClass(), "RegistirationCustomer.fxml", "CustomersRegistrationInterface.css",
				event);
	}

	/**
	 * Method for clicking Register New Customer ,switches stage to the next page(to
	 * fill Customer information for registration)
	 * 
	 * @param event event of the Register New Customer Button clicked
	 */
	public void registerWorker(ActionEvent event) {
		CommonMethods.switchScene(getClass(), "RegistirationWorkers.fxml", "WorkersRegistrationInterface.css", event);
	}

	/**
	 * Method to set Marketing Manager Information
	 */
	@Override
	public void SetPageInfo(String Label, String UserID, String Area) {
		IDnamelabel1.setText(Label);
		LBLUserID.setText(UserID);

	}

}
