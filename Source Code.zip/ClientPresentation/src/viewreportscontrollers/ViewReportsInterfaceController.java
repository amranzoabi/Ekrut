package viewreportscontrollers;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.ResourceBundle;
import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

/**
 * This Class is a Choice of the report depending on the Area, Location, Month
 * and type of the report Page Controller for ViewReportsInterface.fxml ,it runs
 * all the methods that functions the choice of the CEO (the kind of report) CEO
 * chooses area ,location ,report type and month from four combo boxes Area Box
 * Location Box Report Box Month Box Note: this class uses help other classes to
 * set and get some functionality
 * 
 * @author Mahran
 *
 */
public class ViewReportsInterfaceController implements Initializable {

	/**
	 * map that helps save a group of locations for specific area
	 */
	private HashMap<String, ArrayList<String>> locationsByArea = new HashMap<String, ArrayList<String>>();
	/**
	 * to save the areas
	 */
	private String[] areas = { "Haifa", "Shefa-Amer", "Karmiel", "Tel-Aviv" };
	/**
	 * to save the reports type
	 */
	private String[] reports = { "Stock Report", "Orders Report", "Customers Report" };
	/**
	 * to save the months (of the year)
	 */
	private String[] months = { "January", "February", "March", "April", "May", "June", "July", "August", "September",
			"October", "November", "December" };

	/**
	 * ComboBox to save/show Reports to choose from
	 */
	@FXML
	private ComboBox<String> IDReportsBox;
	/**
	 * ComboBox to save/show Areas to choose from
	 */
	@FXML
	private ComboBox<String> IDAreaBox;
	/**
	 * ComboBox to save/show Months to choose from
	 */
	@FXML
	private ComboBox<String> IDMonthBox;
	/**
	 * ComboBox to save/show Location to choose from
	 */
	@FXML
	private ComboBox<String> IDLocationBox;
	/**
	 * Label to show error message
	 */
	@FXML
	private Label errorLabel;

	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}

	/**
	 * Method for going back to the previous page in this case the CEO page
	 * 
	 * @param event event of the arrow (back) icon clicked
	 * @throws Exception Exception will be thrown if an error occurs when switching
	 *                   the stage
	 */
	public void back(MouseEvent event) throws Exception {
		CommonMethods.switchSceneBack(getClass(), event);
	}

	/**
	 * Method for clicking the help icon ,a windows will show with a message and
	 * explain the scene/page
	 * 
	 * @param event event of the help icon clicked the scene/page and what every
	 *              button do
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void help(MouseEvent event) throws Exception {
		CommonMethods.help("You must choose Area, Location, report type and month to proceed:", getClass());

	}

	/**
	 * initialize the data into the box and the hash map
	 *
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		errorLabel.setText("");
		IDAreaBox.getItems().addAll(areas);
		locationsByArea.put("Haifa", new ArrayList<>(
				Arrays.asList("the Baha'i Gardens", "Down Town", "Maritime Museum", "Haifa-University")));
		locationsByArea.put("Shefa-Amer",
				new ArrayList<>(Arrays.asList("Old City", "Down Town", "The Castle", "Alna'ma")));
		locationsByArea.put("Karmiel", new ArrayList<>(Arrays.asList("Ort Braude", "Down Town", "North", "Park")));
		locationsByArea.put("Tel-Aviv",
				new ArrayList<>(Arrays.asList("Jaffa", "Yemenite Quarter", "Tel Aviv Museum", "Tel-Aviv University")));
		IDReportsBox.setPromptText("Choose Report");
		IDReportsBox.getItems().addAll(reports);
		IDMonthBox.getItems().addAll(months);
		IDAreaBox.setOnAction(this::getLocation);

		IDAreaBox.addEventHandler(ActionEvent.ACTION,
				event -> IDLocationBox.setStyle(IDLocationBox.getStyle() + "-fx-cursor:hand;"));
	}

	/**
	 * Method for implementing the locations of the area that customer chooses gets
	 * the value from area ComboBox and implements the locations that area with help
	 * from the HashMap (locationsByArea) key
	 * 
	 * @param event event of the choosing from ComboBox (choose area)
	 */
	public void getLocation(ActionEvent event) {

		String location = IDAreaBox.getValue();
		IDLocationBox.getItems().clear();

		if (location.equals("Haifa")) {
			IDLocationBox.getItems().addAll(locationsByArea.get("Haifa"));
		} else if (location.equals("Shefa-Amer")) {
			IDLocationBox.getItems().addAll(locationsByArea.get("Shefa-Amer"));

		} else if (location.equals("Karmiel")) {
			IDLocationBox.getItems().addAll(locationsByArea.get("Karmiel"));
		} else if (location.equals("Tel-Aviv")) {
			IDLocationBox.getItems().addAll(locationsByArea.get("Tel-Aviv"));
		}

	}

	/**
	 * Method to check the reports in data base ,in case they exists the method
	 * would switch the stage/scene to the next page in case the user doesn't fill
	 * the information properly an error message would be thrown (didn't choose
	 * location for example)
	 * 
	 * @param event event on clicking the arrow (forward) Button
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void showReport(MouseEvent event) throws Exception {
		String reportType = IDReportsBox.getValue();
		String Area = IDAreaBox.getValue();
		String Month = IDMonthBox.getValue();
		String Location = IDLocationBox.getValue();
		ArrayList<String> reportInfo = new ArrayList<>();
		reportInfo.add(Month);
		reportInfo.add(Area);
		reportInfo.add(Location);
		boolean Available = false;
		if (reportType == null || Area == null || Month == null || Location == null)
			errorLabel.setText("One of the ComboBoxes \nstill empty choose please");
		else if (reportType.equals("") || Area.equals("") || Month.equals("") || Location.equals(""))
			errorLabel.setText("One of the ComboBoxes \nstill empty choose please");
		else {
			switch (reportType) {
			
			case "Stock Report":
				ClientMethods.SendMessage(Commands.CheckStockReports, reportInfo);
				Available = ChatClient.CheckStockReportAnswer;
				if (Available) {
					errorLabel.setText("");
					StockReportInterfaceController.SetReportInformation(Area, Month, Location);
					CommonMethods.switchScene(getClass(), "StockReportInterface.fxml", "StockReportInterface.css",
							event);
				} else {
					errorLabel.setText("This report for the isn't available");
				}
				break;

			case "Orders Report":
				ClientMethods.SendMessage(Commands.CheckOrdersReports, reportInfo);
				Available = ChatClient.CheckOrdersReportAnswer;

				if (Available) {
					errorLabel.setText("");
					OrdersReportInterfaceController.SetReportInformation(Area, Month, Location);
					CommonMethods.switchScene(getClass(), "OrdersReportInterface.fxml", "OrdersReportInterface.css",
							event);
				} else {
					errorLabel.setText("This report isn't available");
				}
				break;

			case "Customers Report":
				ClientMethods.SendMessage(Commands.CheckCustomerskReports, reportInfo);
				Available = ChatClient.CheckCustomersReportAnswer;
				if (Available) {
					errorLabel.setText("");
					CustomersReportInterfaceController.SetReportInformation(Area, Month, Location);
					CommonMethods.switchScene(getClass(), "CustomersReportInterface.fxml",
							"CustomersReportInterface.css", event);
				} else {
					errorLabel.setText("This report for the isn't available");
				}
				break;
			}
		}

	}

}
