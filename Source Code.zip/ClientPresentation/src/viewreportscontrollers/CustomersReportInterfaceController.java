package viewreportscontrollers;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * This Class is Customer report Information class for
 * CustomersReportInterface.fxml , it runs all the methods to get data from the
 * data base and represent it in this page Note: this class uses help from other
 * classes
 * 
 * @author Amran
 *
 */
public class CustomersReportInterfaceController implements Initializable {

	/**
	 * PieCHart for percentage
	 */
	@FXML
	private PieChart percentageChart;
	/**
	 * PieChart for sales
	 */
	@FXML
	private PieChart salesChart;
	/**
	 * Bar chart to show information
	 */
	@FXML
	private BarChart<String, Integer> customersReportChart;
	/**
	 * Label to show area
	 */
	@FXML
	private Label AreaID;
	/**
	 * Label to show location
	 */
	@FXML
	private Label LocationID;
	/**
	 * Label to show chart title
	 */
	@FXML
	private Label IDChartTitle;
	/**
	 * Label to show most valuable
	 */
	@FXML
	private Label MostValuable;
	/**
	 * Label to show least valuable
	 */
	@FXML
	private Label LeastValuable;

	/**
	 * Variables To save the information from the previous page
	 */
	private static String Area, Month, Location;

	/**
	 * function to save report information so we can display the correct report for
	 * the ceo
	 * 
	 * @param area     to save the area of the report
	 * @param month    to save the month of the report
	 * @param location to save the location of the report
	 */
	public static void SetReportInformation(String area, String month, String location) {
		System.out.println("set report information function info :" + area + " " + month + " " + location);
		Area = area;
		Month = month;
		Location = "All locations";

	}

	/**
	 * Method for closing the application, the window of the application would be
	 * closed this method activates in case the X icon is clicked
	 * 
	 * @param event event on clicking the X icon
	 * @throws Exception exception if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}

	/**
	 * Method for going back to the page that precedes the current page
	 * 
	 * @param event event on clicking the arrow back
	 * @throws Exception exception if an error occurs
	 */
	public void back(MouseEvent event) throws Exception {
		CommonMethods.switchSceneBack(getClass(), event);
	}

	/**
	 * Method for showing help information, a popup with explanation of current page
	 * will show up to the user
	 * 
	 * @param event event clicking on the question mart (help) icon
	 * @throws Exception Exception will be thrown if in error occurs
	 */

	public void help(MouseEvent event) throws Exception {
		CommonMethods.help("This Page contains data concerning Customers " + "\nin the choosen area"
				+ "\nand every location per this area and month",
				getClass());

	}

	/**
	 * initialize the location and area initialize all the server methods and
	 * connections to get the data and set it in this page
	 */

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		AreaID.setText(Area);
		LocationID.setText(Location);
		buildGraphFromDB(Month, Area);
		buildPieChartFromDB(Month,Area);

	}

	/**
	 * Method to build the pie chart using the data from the data base
	 * @param month the month
	 * @param area the area
	 */
	public void buildPieChartFromDB(String month, String area) {

		ClientMethods.SendMessage(Commands.GetCostumersSubscribersNumberPerMonthTable, "Nothing");
		ArrayList<ArrayList<Object>> outer= ChatClient.NumberOfCustomersSubscribers;
		ArrayList<Object> report= new ArrayList<>();
		// loop to traverse on all reports in the database and pick the right one
				for (ArrayList<Object> inner : outer) {
					String DBMonth = (String) inner.get(1);
					String DBArea = (String) inner.get(2);
					// check if its the report the ceo picked it then save it
					if (DBMonth.equals(month) && DBArea.equals(area) )
						report = inner;

			}
				
		Integer customersnum = (Integer)report.get(3);
		Integer subscribersnum = (Integer)report.get(4);

		ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList( 
				new PieChart.Data("Regular", customersnum), new PieChart.Data("Subscribers", subscribersnum));
		Double sum = (Double) ((customersnum + subscribersnum) / 1.0);
		percentageChart.setData(pieData);
		percentageChart.getData().forEach(data -> {
			String percentage = String.format("%.2f%%", ((data.getPieValue() / sum) * 100));
			Tooltip toolTip = new Tooltip(percentage);
			Tooltip.install(data.getNode(), toolTip);

		});
	}

	/**
	 * Method to build the chart using the data from the data base
	 * 
	 * @param month    the needed month
	 * @param area     the needed area
	 */
	@SuppressWarnings("unchecked")
	public void buildGraphFromDB(String month, String area) {

		ClientMethods.SendMessage(Commands.Getallmonthlycostumersreports, "Nothing");
		ArrayList<ArrayList<Object>> outer = new ArrayList<>();
		outer = ChatClient.MonthlyCustomerskReportsArr;
		System.out.println("the array arrived here : " + outer);
		IDChartTitle.setText(month + " Customers Report - Based Orders Number");

		ArrayList<Object> report = null; // array to save the report we need

		// loop to traverse on all reports in the database and pick the right one
		for (ArrayList<Object> inner : outer) {
			String DBMonth = (String) inner.get(1);
			String DBArea = (String) inner.get(2);
			// check if its the report the ceo picked it then save it
			if (DBMonth.equals(month) && DBArea.equals(area) )
				report = inner;

		}

		// put the products IDs in array to get their names from server
		ArrayList<Integer> costumersIDs = new ArrayList<>();
		if (report!=null) {
		costumersIDs.add((Integer) report.get(3));
		costumersIDs.add((Integer) report.get(5));
		costumersIDs.add((Integer) report.get(7));
		costumersIDs.add((Integer) report.get(9));
		costumersIDs.add((Integer) report.get(10));
		
		ArrayList<Integer> Temp = new ArrayList<>(); // array to work on it and not play with the data i already have
		Temp = (ArrayList<Integer>) costumersIDs.clone(); // clone the data of costumers i already have
		HashSet<Integer> hshhosh = new HashSet<>();
		hshhosh.addAll(Temp); // get rid from the duplicates
		Temp.clear(); // clear the old array before adding the new no duplicates array
		Temp.addAll(hshhosh); // return the old array without duplicates
		Temp.sort(null); // sort the IDs array in an ascending way
		System.out.println(Temp);

		// get all the products details to get their names using the ids
		ClientMethods.SendMessage(Commands.GetAllUsers, "Nothing");
		ArrayList<ArrayList<Object>> Users = ChatClient.Users;
		System.out.println(Users);

		int j = 0;
		HashMap<Integer, String> IdToName = new HashMap<>(); // map from customer ID to Name

		for (ArrayList<Object> user : Users) // traverse on all users to get all names needed
		{
			if ( ((Integer)user.get(12)).equals(Temp.get(j)))  {
				IdToName.put(Temp.get(j), (String) user.get(4)); // add to name map
				j++;
				if (j == Temp.size()) // get out of the loop before getting out of array index
					break;
			}
		}

		System.out.println("HashMap is -> " + IdToName);
		System.out.println("costumersIDs=" + costumersIDs);
		System.out.println("Temp=" + Temp);
		/////// here starts the problem how to put the data inside the barchart ///////
		Integer NumOfOrders1 = (Integer) report.get(5);
		Integer NumOfOrders2 = (Integer) report.get(7);
		Integer NumOfOrders3 = (Integer) report.get(9);
		XYChart.Series<String, Integer> customer1 = new XYChart.Series<>();
		XYChart.Series<String, Integer> customer2 = new XYChart.Series<>();
		XYChart.Series<String, Integer> customer3 = new XYChart.Series<>();
		customer1.getData().add(new Data<String, Integer>(IdToName.get(costumersIDs.get(0)), NumOfOrders1)); // product 1
		customer2.getData().add(new Data<String, Integer>(IdToName.get(costumersIDs.get(1)), NumOfOrders2)); // product 2
		customer3.getData().add(new Data<String, Integer>(IdToName.get(costumersIDs.get(2)), NumOfOrders3)); // product 3
		customer1.setName(IdToName.get(costumersIDs.get(0)));
		customer2.setName(IdToName.get(costumersIDs.get(1)));
		customer3.setName(IdToName.get(costumersIDs.get(2)));
		customersReportChart.getData().add(customer1);
		customersReportChart.getData().add(customer2);
		customersReportChart.getData().add(customer3);
		MostValuable.setText(IdToName.get(costumersIDs.get(3))); // most sold
		LeastValuable.setText(IdToName.get(costumersIDs.get(4))); // least sold
		}

	}

	/**
	 * Method to convert to PDF file and save it in the the path that was inserted
	 * Note: this method uses a static method from CommonMethods class
	 * 
	 * @param event event on clicking the GetPDF File
	 */
	public void GetPDF(ActionEvent event) {
		String fileName = "Customers";
		FileChooser fileChooser = new FileChooser();

		// Set extension filter for text files
		FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("pdf files (*.pdf)", "*.pdf");
		fileChooser.getExtensionFilters().add(extFilter);

		// Show save file dialog
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		File file = fileChooser.showSaveDialog(stage);
		if (file != null) {
			CommonMethods.convertToPdf(fileName, file.toString());
			CommonMethods.CompletionMessage("A PDF File was created and saved in " + file.toString(), getClass());
		}

	}

}
