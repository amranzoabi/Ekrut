package viewreportscontrollers;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * This Class is Order report Information class for OrdersReportInterface.fxml ,
 * it runs all the methods to get data from the data base and represent it in
 * this page Note: this class uses help from other classes
 * 
 * @author Mahran
 *
 */
public class OrdersReportInterfaceController implements Initializable {

	/**
	 * PieChart for categories
	 */
	@FXML
	private PieChart categoriesPieChart;
	/**
	 * PieChart for profits
	 */
	@FXML
	private PieChart profitPChart;
	/**
	 * Bar chart to show information
	 */
	@FXML
	private BarChart<String, Integer> ordersReportChart;
	/**
	 * Label to show the chart title
	 */
	@FXML
	private Label IDChartTitle;

	/**
	 * Label to show least sold
	 */
	@FXML
	private Label LeastSold;

	/**
	 * Label to show most sold
	 */
	@FXML
	private Label MostSold;
	/**
	 * Label to show area
	 */
	@FXML
	private Label AreaID;
	/**
	 * Label to show location
	 */
	@FXML
	private Label LocationID;

	/**
	 * Variables To save the information from the previous page
	 */
	private static String Area, Month, Location;

	/**
	 * function to save report information so we can display the correct report for
	 * the ceo
	 * 
	 * @param area     to save the area of the report
	 * @param month    to save the month of the report
	 * @param location to save the location of the report
	 */
	public static void SetReportInformation(String area, String month, String location) {
		System.out.println("set report information function info :" + area + " " + month + " " + location);
		Area = area;
		Month = month;
		Location = location;
	}

	/**
	 * Method for closing the application, the window of the application would be
	 * closed this method activates in case the X icon is clicked
	 * 
	 * @param event event on clicking the X icon
	 * @throws Exception exception if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception // close window
	{
		ClientMethods.close(event);
	}

	/**
	 * Method for going back to the page that precedes the current page
	 * 
	 * @param event event on clicking the arrow back
	 * @throws Exception exception if an error occurs
	 */
	public void back(MouseEvent event) throws Exception {
		CommonMethods.switchSceneBack(getClass(), event);
	}

	/**
	 * Method for showing help information, a popup with explanation of current page
	 * will show up to the user
	 * 
	 * @param event event clicking on the question mart (help) icon
	 * @throws Exception Exception will be thrown if in error occurs
	 */
	public void help(MouseEvent event) throws Exception {
		CommonMethods.help("This Page contains data concerning orders of specefic machine "
				+ "\nin the choosen area,location and month", getClass());

	}

	/**
	 * initialize the location and area initialize all the server methods and
	 * connections to get the data and set it in this page
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {// intilaize the charts
		AreaID.setText(Area);
		LocationID.setText(Location);
		buildGraphFromDB(Month, Area, Location);
		buildPieChartFromDB(Month, Area, Location);

		

	}
	/**
	 * Method to build the chart using the data from the data base
	 * @param month the needed month
	 * @param area the needed area
	 * @param location the needed location
	 */
	@SuppressWarnings("unchecked")
	public void buildGraphFromDB(String month, String area, String location) {

		ClientMethods.SendMessage(Commands.Getallmonthlyrorderseports, "Nothing");
		ArrayList<ArrayList<Object>> outer = new ArrayList<>();
		outer = ChatClient.MonthlyOrdersReportsArr;
		System.out.println("the array arrived here : " + outer);
		IDChartTitle.setText(month + " Orders Report - Based on Products in Orders");

		ArrayList<Object> report = null; // array to save the report we need

		// loop to traverse on all reports in the database and pick the right one
		for (ArrayList<Object> inner : outer) {
			String DBMonth = (String) inner.get(1);
			String DBArea = (String) inner.get(2);
			String DBLocation = (String) inner.get(3);
			// check if its the report the ceo picked it then save it
			if (DBMonth != null && DBArea != null && DBLocation != null)
				if (DBMonth.equals(month) && DBArea.equals(area) && DBLocation.equals(location))
						report = inner;

					

		}
		// put the products IDs in array to get their names from server
		ArrayList<Integer> productsIDs = new ArrayList<>();
		productsIDs.add((Integer) report.get(4));
		productsIDs.add((Integer) report.get(6));
		productsIDs.add((Integer) report.get(8));
		productsIDs.add((Integer) report.get(10));
		productsIDs.add((Integer) report.get(11));
		ArrayList<Integer> Temp = new ArrayList<>();
		Temp = (ArrayList<Integer>) productsIDs.clone();
		HashSet<Integer> hshhosh = new HashSet<>();
		hshhosh.addAll(Temp);
		Temp.clear();
		Temp.addAll(hshhosh);
		Temp.sort(null);
		System.out.println(Temp);

		ClientMethods.SendMessage(Commands.Getallproducts, "Nothing");
		ArrayList<ArrayList<Object>> products = ChatClient.ProductsArr;
		System.out.println(products);

		int j = 0;
		HashMap<Integer, String> IdToName = new HashMap<>();
		HashMap<Integer, String> IdToCategory = new HashMap<>();

		for (ArrayList<Object> product : products) {
			if (product.contains(Temp.get(j))) {
				IdToName.put(Temp.get(j), (String) product.get(0));
				IdToCategory.put(Temp.get(j), (String) product.get(2));
				j++;
				if (j == Temp.size())
					break;
			}
		}
		System.out.println("HashMap is -> " + IdToName);
		System.out.println("productsids=" + productsIDs);
		System.out.println("Temp=" + Temp);
		Integer quantity1 = (Integer) report.get(5);
		Integer quantity2 = (Integer) report.get(7);
		Integer quantity3 = (Integer) report.get(9);
		XYChart.Series<String, Integer> product1 = new XYChart.Series<>();
		XYChart.Series<String, Integer> product2 = new XYChart.Series<>();
		XYChart.Series<String, Integer> product3 = new XYChart.Series<>();
		product1.getData().add(new Data<String, Integer>(IdToName.get(productsIDs.get(0)), quantity1)); // product 1
		product2.getData().add(new Data<String, Integer>(IdToName.get(productsIDs.get(1)), quantity2)); // product 2
		product3.getData().add(new Data<String, Integer>(IdToName.get(productsIDs.get(2)), quantity3)); // product 3
		product1.setName(IdToCategory.get(productsIDs.get(0)));
		product2.setName(IdToCategory.get(productsIDs.get(1)));
		product3.setName(IdToCategory.get(productsIDs.get(2)));
		ordersReportChart.getData().add(product1);
		ordersReportChart.getData().add(product2);
		ordersReportChart.getData().add(product3);

		MostSold.setText(IdToName.get(productsIDs.get(3))); // most sold
		LeastSold.setText(IdToName.get(productsIDs.get(4))); // least sold
	}
	
	/**
	 * Method to build the pie chart using the data from the data base
	 * @param month the needed month
	 * @param area the needed area
	 * @param location the needed location
	 */
	public void buildPieChartFromDB(String month, String area, String location) {

		XYChart.Series<String, Integer> Drinks = new XYChart.Series<>(); // series for data of drinks - orders bar chart
		XYChart.Series<String, Integer> Chocolate = new XYChart.Series<>();// series for data of chocolate - orders bar																// chart
		XYChart.Series<String, Integer> Sweets = new XYChart.Series<>();// series for data of sweets - orders bar chart
		XYChart.Series<String, Integer> Chips = new XYChart.Series<>();// series for data of chips - orders bar chart
		XYChart.Series<String, Integer> Others = new XYChart.Series<>();// series for data of other categories- orders																// bar chart
		Drinks.setName("Soft-Drinks");
		Chocolate.setName("Choclate-Bars");
		Sweets.setName("jelly-Sweets");
		Chips.setName("Chips");
		Others.setName("Others");
		ClientMethods.SendMessage(Commands.GetCategoryProfitPerMonthTable, "Nothing");
		ArrayList<ArrayList<Object>> TableData = ChatClient.CategoryProfitPerMonth;
		ArrayList<Object> MyReport = null;
		// loop to traverse on all reports in the database and pick the right one
		for (ArrayList<Object> inner : TableData) {
			String DBMonth = (String) inner.get(1);
			String DBArea = (String) inner.get(2);
			String DBLocation = (String) inner.get(3);
			// check if its the report the ceo picked it then save it
			if (DBMonth != null && DBArea != null && DBLocation != null)
				if (DBMonth.equals(month) && DBArea.equals(area) && DBLocation.equals(location))
					
						MyReport = inner;

					

		}
		ObservableList<PieChart.Data> pieData2 = FXCollections.observableArrayList( // data for pie chart of profit by
																					// category
				new PieChart.Data("Soft-Drinks", (Integer) MyReport.get(4)),
				new PieChart.Data("Choclate-Bars", (Integer) MyReport.get(5)),
				new PieChart.Data("jelly-Sweets", (Integer) MyReport.get(6)),
				new PieChart.Data("Chips", (Integer) MyReport.get(7)),
				new PieChart.Data("Others", (Integer) MyReport.get(8)));
		Double sum = (Double) (((Integer) MyReport.get(4) + (Integer) MyReport.get(5) + (Integer) MyReport.get(6)
				+ (Integer) MyReport.get(7) + (Integer) MyReport.get(8)) / 1.0);
		profitPChart.setData(pieData2);
		profitPChart.getData().forEach(data -> {
			String percentage = String.format("%.2f%%", ((data.getPieValue() / sum) * 100));
			Tooltip toolTip = new Tooltip(percentage);
			Tooltip.install(data.getNode(), toolTip);

		});

	}
	
	
	/**
	 * Method to convert to PDF file and save it in the the path that was inserted
	 * Note: this method uses a static method from CommonMethods class
	 * 
	 * @param event event on clicking the GetPDF File
	 */
	public void GetPDF(ActionEvent event) {
		String fileName = "Orders";
		FileChooser fileChooser = new FileChooser();

		// Set extension filter for text files
		FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("pdf files (*.pdf)", "*.pdf");
		fileChooser.getExtensionFilters().add(extFilter);

		// Show save file dialog
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		File file = fileChooser.showSaveDialog(stage);
		if (file != null) {
			CommonMethods.convertToPdf(fileName, file.toString());
			CommonMethods.CompletionMessage("A PDF File was created and saved in " + file.toString(), getClass());
		}

	}
}
