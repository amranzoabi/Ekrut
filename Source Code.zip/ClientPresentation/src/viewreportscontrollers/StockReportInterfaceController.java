package viewreportscontrollers;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientMethods;
import common.Commands;
import common.CommonMethods;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * This Class is Stock report Information class for StockReportInterface.fxml ,
 * it runs all the methods to get data from the data base and represent it in
 * this page Note: this class uses help from other classes
 * 
 * @author Shadi
 * @author Amran
 *
 */
public class StockReportInterfaceController implements Initializable {

	/**
	 * PieCHart for categories
	 */
	@FXML
	private PieChart categoriesPieChart;
	/**
	 * LineChart to show information
	 */
	@FXML
	private LineChart<String, Integer> reportChart;
	/**
	 * Label to show area
	 */
	@FXML
	private Label AreaID;
	/**
	 * Label to show chart title
	 */
	@FXML
	private Label IDChartTitle;
	/**
	 * Label to show location
	 */
	@FXML
	private Label LocationID;
	/**
	 * Label to show least sold
	 */
	@FXML
	private Label LeastSold;

	/**
	 * Label to show most sold
	 */
	@FXML
	private Label MostSold;

	/**
	 * Variables To save the information from the previous page
	 */
	private static String Area, Month, Location;

	/**
	 * initialize the location and area initialize all the server methods and
	 * connections to get the data and set it in this page
	 */
	
    /**
     * overall products
     */
    @FXML
    private Label OverAllProducts;

    /**
     * number of restocks done
     */
    @FXML
    private Label Restocks;
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {// intilaize the charts
		AreaID.setText(Area);
		LocationID.setText(Location);
		@SuppressWarnings("unused")
		boolean res = buildGraphFromDB(Month, Area, Location);
		@SuppressWarnings("unused")
		boolean res2 = buildPieChartFromDB(Month, Area, Location);
	}
	/**
	 * function to save report information so we can display the correct report for
	 * the ceo
	 * 
	 * @param area     to save the area of the report
	 * @param month    to save the month of the report
	 * @param location to save the location of the report
	 */
	public static void SetReportInformation(String area, String month, String location) {
		System.out.println("set report information function info :" + area + " " + month + " " + location);
		Area = area;
		Month = month;
		Location = location;

	}

	/**
	 * Method for closing the application, the window of the application would be
	 * closed this method activates in case the X icon is clicked
	 * 
	 * @param event event on clicking the X icon
	 * @throws Exception exception if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception {
		ClientMethods.close(event);
	}

	/**
	 * Method for going back to the page that precedes the current page
	 * 
	 * @param event event on clicking the arrow back
	 * @throws Exception exception if an error occurs
	 */
	public void back(MouseEvent event) throws Exception {
		CommonMethods.switchSceneBack(getClass(), event);
	}

	/**
	 * Method for showing help information, a popup with explanation of current page
	 * will show up to the user
	 * 
	 * @param event event clicking on the question mart (help) icon
	 * @throws Exception Exception will be thrown if in error occurs
	 */
	public void help(MouseEvent event) throws Exception {
		CommonMethods.help("This Page contains data concerning Stocks of specefic machine "
				+ "\nin the choosen area,location and month", getClass());

	}
	
	/**
	 * Method to build the chart using the data from the data base
	 * @param month the needed month
	 * @param area the needed area
	 * @param location the needed location
	 * @return true or false
	 */
	public boolean buildGraphFromDB(String month, String area, String location) {
		boolean res = false;
		
		ClientMethods.SendMessage(Commands.Getallmonthlystockreports, "Nothing");
		ArrayList<ArrayList<Object>> outer = new ArrayList<>();
		outer = ChatClient.MonthlyStockReportsArr;
		System.out.println("the array arrived here : " + outer);
		IDChartTitle.setText(Month + " Stock Report");
		XYChart.Series<String, Integer> series = new XYChart.Series<>();
		ArrayList<Object> report = null; // array to save the report we need
		for (ArrayList<Object> inner : outer) {
			String DBMonth = (String) inner.get(1);
			String DBArea = (String) inner.get(2);
			String DBLocation = (String) inner.get(3);
			// check if its the report the ceo picked it then save it
			if (DBMonth.equals(month) && DBArea.equals(area) && DBLocation.equals(location))
				{report = inner; res = true;}
		}

		series.getData().add(new Data<String, Integer>("Day 1", (Integer) report.get(5)));
		series.getData().add(new Data<String, Integer>("Day 5", (Integer) report.get(6)));
		series.getData().add(new Data<String, Integer>("Day 10", (Integer) report.get(7)));
		series.getData().add(new Data<String, Integer>("Day 15", (Integer) report.get(8)));
		series.getData().add(new Data<String, Integer>("Day 20", (Integer) report.get(9)));
		series.getData().add(new Data<String, Integer>("Day 25", (Integer) report.get(10)));
		series.getData().add(new Data<String, Integer>("Day 30", (Integer) report.get(11)));
		reportChart.getData().add(series);
		MostSold.setText((String) report.get(12)); // most sold
		LeastSold.setText((String) report.get(13)); // least sold
		OverAllProducts.setText(((Integer)report.get(4))+""); // overall products
		Restocks.setText(  ((Integer)report.get(14))+""   ); // Restocks
		return res;
	}
	
	/**
	 * Method to build the pie chart using the data from the data base
	 * @param month the needed month
	 * @param area the needed area
	 * @param location the needed location
	 * @return true or false
	 */
	public boolean buildPieChartFromDB(String month, String area, String location) {
		boolean res = false;
		ClientMethods.SendMessage(Commands.GetCategoryPercentagePerMonth, "Nothing");
		ArrayList<ArrayList<Object>> TableData = ChatClient.CategoryStockPercentagePerMonth;

		ArrayList<Object> MyReport = null;

		// loop to traverse on all reports in the database and pick the right one
		for (ArrayList<Object> inner : TableData) {
			String DBMonth = (String) inner.get(1);
			String DBArea = (String) inner.get(2);
			String DBLocation = (String) inner.get(3);
			// check if its the report the ceo picked it then save it
			if (DBMonth.equals(month) && DBArea.equals(area) && DBLocation.equals(location))
				{MyReport = inner; res = true;}

		}

		ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList(
				new PieChart.Data("Soft-Drinks", (Integer) MyReport.get(4)),
				new PieChart.Data("Choclate-Bars", (Integer) MyReport.get(5)),
				new PieChart.Data("jelly-Sweets", (Integer) MyReport.get(6)),
				new PieChart.Data("Chips", (Integer) MyReport.get(7)),
				new PieChart.Data("Others", (Integer) MyReport.get(8)));
		Double sum = (Double) (((Integer) MyReport.get(4) + (Integer) MyReport.get(5) + (Integer) MyReport.get(6)
				+ (Integer) MyReport.get(7) + (Integer) MyReport.get(8)) / 1.0);
		categoriesPieChart.setData(pieData);
		categoriesPieChart.getData().forEach(data -> {
			String percentage = String.format("%.2f%%", ((data.getPieValue() / sum) * 100));
			Tooltip toolTip = new Tooltip(percentage);
			Tooltip.install(data.getNode(), toolTip);

		});
		return res;
	}



	/**
	 * Method to convert to PDF file and save it in the the path that was inserted
	 * Note: this method uses a static method from CommonMethods class
	 * 
	 * @param event event on clicking the GetPDF File
	 */
	public void GetPDF(ActionEvent event) {
		String fileName = "Stock";
		FileChooser fileChooser = new FileChooser();

		// Set extension filter for text files
		FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("pdf files (*.pdf)", "*.pdf");
		fileChooser.getExtensionFilters().add(extFilter);

		// Show save file dialog
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		File file = fileChooser.showSaveDialog(stage);
		if (file != null) {
			CommonMethods.convertToPdf(fileName, file.toString());
			CommonMethods.CompletionMessage("A PDF File was created and saved in " + file.toString(), getClass());
		}
	}

}
