package interfaces;

import javafx.scene.input.MouseEvent;

/**
 * Interface to help with the arrow back (previous pages) for all pages
 * 
 * @author Shadi
 *
 */
public interface BackablePage {
	/**
	 * Method for the interface to help implement the back method
	 * @param event event on clicking the back arrow icon
	 * @throws Exception exception if an error occurs
	 */
	public void back(MouseEvent event) throws Exception;
}
