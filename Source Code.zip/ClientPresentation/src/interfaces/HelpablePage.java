package interfaces;

import javafx.scene.input.MouseEvent;

/**
 * Interface to help specify the help Button for all pages
 * 
 * @author Shadi
 *
 */
public interface HelpablePage {
	/**
	 * Method for the interface to help implement the help method
	 * @param event event on clicking the help icon
	 * @throws Exception exception if an error occurs
	 */
	public void help(MouseEvent event) throws Exception;
}
