package interfaces;

/**
 * Interface to help set data in home Page for each user
 * 
 * @author Mahran
 *
 */
public interface SetableHomepage {
	/**
	 * Method for the interface to help implement the setPageinfo method
	 * @param Label label to show information
	 * @param UserID the user id 
	 * @param Area the area
	 */
	public void SetPageInfo(String Label, String UserID, String Area);
}
