package interfaces;

import javafx.scene.input.MouseEvent;

/**
 * Interface to help with the closing of the window/ stage for all pages
 * 
 * @author Mahran
 *
 */
public interface CloseablePage {
	/**
	 * Method for the interface to help implement the close method
	 * @param event event on clicking the close icon
	 * @throws Exception exception if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception;
}
