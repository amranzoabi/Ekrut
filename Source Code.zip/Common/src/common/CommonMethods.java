package common;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.image.WritableImage;
import javafx.scene.image.PixelReader;
import java.io.File;

import javax.imageio.ImageIO;

/**
 * this is a class that includes all the common methods that were used in
 * different classes/controllers
 * 
 * @author Mahran
 * @author Shadi
 *
 */
public class CommonMethods {
	/**
	 * to recognize when the smart phone icon is moving
	 */
	public static int smartPhoneMoving = 0;

	/**
	 * to save window xOffset
	 */
	private static double xOffset = 0;
	/**
	 * to save window yOffset
	 */
	private static double yOffset = 0;
	/**
	 * to save the root parent
	 */
	private static Parent root1;
	/**
	 * to save the scene
	 */
	private static ArrayList<Scene> BackScenes=new ArrayList<Scene>();

	/**
	 * to check if the client stayed away for long time
	 */
	private static boolean LogOutTimerFlag = false;
	
	/**
	 * to save the login scene
	 */
	private static Scene LoginScene;
	/**
	 * to save all the home pages
	 */
	private static String[] HomepagesNames = { "AreaManagerPage.fxml", "CEOPage.fxml", "CustomerPage.fxml",
			"DeliveryOperatorHomepage.fxml", "MarketingManagerHomepage.fxml", "MarketingWorkerHomepage.fxml",
			"OperationsWorkerPage.fxml", "ServiceAgentHomepage.fxml" };
	/**
	 * to save the home scene
	 */
	private static Scene HomepageScene;

	/**
	 * Method to set and get the flag
	 * 
	 * @param value to change the flag into it
	 */
	public static void setLogOutTimerFlag(boolean value) {
		LogOutTimerFlag = value;
	}

	/**
	 * Method to get the out timer flag
	 * 
	 * @param value the value
	 * @return return the logout timer flag
	 */
	public static boolean getLogOutTimerFlag(boolean value) {
		return LogOutTimerFlag;
	}

	/**
	 * Method to save the login scene and improve the performance of getting back to
	 * it
	 * 
	 * @param c     class
	 * @param stage the stage
	 */
	public static void SaveLoginScene(Class<?> c, Stage stage) {
		Parent root = null;
		Scene scene;
		String filename;
		String filecss;

		filename = "/FXMLs/" + "LoginHomePage.fxml";
		filecss = "/CssF/" + "Logininterface.css";
		try {
			FXMLLoader loader = new FXMLLoader(c.getResource(filename));
			root = loader.load();
			// make the window moveable
			root.setOnMousePressed(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {

					xOffset = event.getSceneX();
					yOffset = event.getSceneY();

				}

			});
			root.setOnMouseDragged(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					if (smartPhoneMoving == 0) {
						stage.setX(event.getScreenX() - xOffset);
						stage.setY(event.getScreenY() - yOffset);
					}

				}

			});

		} catch (IOException e) {
			e.printStackTrace();
		}
		scene = new Scene(root);
		scene.getStylesheets().add(c.getResource(filecss).toExternalForm());
		LoginScene = scene;
	}

	/**
	 * Method to switch to the login scene
	 * 
	 * @param c     class
	 * @param event event of switching
	 */
	public static void switchToLoginScene(Class<?> c, Event event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Parent root = (Parent) LoginScene.getRoot();
		Scene scene = LoginScene;
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * Method to switch to home page scene
	 * 
	 * @param c     class
	 * @param event event of switching
	 */
	public static void switchToHomepageScene(Class<?> c, Event event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Parent root = (Parent) HomepageScene.getRoot();
		Scene scene = HomepageScene;
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * Method to switch scenes/stages this method is used to move between pages this
	 * method implements the application decoration (App)
	 * 
	 * @param c           for the class type
	 * @param stage       for the current stage
	 * @param newPageName for the new page name
	 * @param cssFileName for the CSS name
	 * @return return the loader controller
	 */
	public static Object switchScene(Class<?> c, Stage stage, String newPageName, String cssFileName) {

		// save the current scene before changing it
		CommonMethods.saveBackScene(stage.getScene());

		Parent root = null;
		Scene scene;
		String filename;
		String filecss;
		if (!LogOutTimerFlag) {
			filename = "/FXMLs/" + newPageName;
			filecss = "/CssF/" + cssFileName;
		} else {
			filename = "/FXMLs/" + "LoginHomePage.fxml";
			filecss = "/CssF/" + "Logininterface.css";
			CommonMethods.CompletionMessage("Disconnected because there is no activity", c);

		}

		FXMLLoader loader = new FXMLLoader(c.getResource(filename));
		try {
			root = loader.load();
			scene = new Scene(root);
			scene.getStylesheets().add(c.getResource(filecss).toExternalForm());
			// save the homepage scene if it was a homepage
			for (String Homepage : HomepagesNames)
				if (newPageName.equals(Homepage))
					HomepageScene = scene;
			stage.setScene(scene);
			stage.show();
			root.setOnMousePressed(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					xOffset = event.getSceneX();
					yOffset = event.getSceneY();
				}

			});
			root.setOnMouseDragged(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					stage.setX(event.getScreenX() - xOffset);
					stage.setY(event.getScreenY() - yOffset);
				}

			});
		} catch (IOException e) {
			System.out.println("in switch 1");
			e.printStackTrace();
		}
		return loader.getController();
	}

	/**
	 * Method to switch scenes/stages this method is used to move between pages this
	 * method implements the application decoration (App) this message similar to
	 * the first Method but doesn't get the stage as a parameter it gets an event of
	 * switching and using it gets the stage Note: same as the first method but
	 * without CSS files
	 * 
	 * @param c           class
	 * @param newPageName page name
	 * @param cssFileName css name
	 * @param event       event on switching
	 * @return null
	 */
	public static Object switchScene(Class<?> c, String newPageName, String cssFileName, Event event) {

		// save the current scene before moving to the next one
		CommonMethods.saveBackScene((Scene) (((Node) (event.getSource())).getScene()));

		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Parent root = null;
		Scene scene;
		String filename;

		String filecss;
		if (!LogOutTimerFlag) {
			filename = "/FXMLs/" + newPageName;
			filecss = "/CssF/" + cssFileName;
		} else {
			filename = "/FXMLs/" + "LoginHomePage.fxml";
			filecss = "/CssF/" + "Logininterface.css";
			Alert alert = new Alert(AlertType.WARNING);
			DialogPane dialogPane = alert.getDialogPane();
			dialogPane.getStylesheets().add(c.getResource("/cssF/myDialogs.css").toExternalForm());
			dialogPane.getStyleClass().add("myDialog");
			alert.initStyle(StageStyle.DECORATED.UNDECORATED);
			alert.setContentText("You are disconnected duo unactivity for long time");
			Optional<ButtonType> result = alert.showAndWait();

		}

		FXMLLoader loader = new FXMLLoader(c.getResource(filename));
		try {
			root = loader.load();
			root1 = root;
			scene = new Scene(root);
			scene.getStylesheets().add(c.getResource(filecss).toExternalForm());
			// save the homepage scene if it was a homepage
			for (String Homepage : HomepagesNames)
				if (newPageName.equals(Homepage))
					HomepageScene = scene;
			stage.setScene(scene);
			stage.show();
			root.setOnMousePressed(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {

					xOffset = event.getSceneX();
					yOffset = event.getSceneY();

				}

			});
			root.setOnMouseDragged(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					if (smartPhoneMoving == 0) {
						stage.setX(event.getScreenX() - xOffset);
						stage.setY(event.getScreenY() - yOffset);
					}

				}

			});

			return loader.getController();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	/**
	 * Method to get back the previous scene this method uses event to get the stage
	 * 
	 * @param c     class
	 * @param event event of switching stages
	 */
	public static void switchSceneBack(Class<?> c, Event event) {
		if (LogOutTimerFlag != true) {
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			Scene scene = BackScenes.get(BackScenes.size()-1);
			stage.setScene(scene);
			stage.show();
			BackScenes.remove(BackScenes.size()-1);
		} else {
			// if the logout timer was true then go back to the login screen
			CommonMethods.switchScene(c, "LoginHomePage.fxml", "Logininterface.css", event);
		}
	}

	/**
	 * Method to save the current scene
	 * 
	 * @param backscene set backScene to backScene
	 */
	public static void saveBackScene(Scene backscene) {
		BackScenes.add(backscene);
	}

	/**
	 * Static Method to check the TextField legality such as : the input are only
	 * numbers the input length is less or equals to limit parameter
	 * 
	 * @param tFID  the TextField
	 * @param limit the length limit
	 */
	public static void textLegality(TextField tFID, int limit) {
		tFID.textProperty().addListener(new ChangeListener<String>() {// only numbers are allowed
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {

				if (!newValue.matches("\\d*"))
					tFID.setText(newValue.replaceAll("[^\\d]", ""));// if not a number don't change
				else if (tFID.getText().length() > limit) {
					tFID.setText(tFID.getText().substring(0, limit));
				}

			}
		});
	}

	/**
	 * Static Method to check the TextField legality such as : the input length is
	 * less or equals to limit parameter
	 * 
	 * @param tFID  the TextField
	 * @param limit the length limit
	 */
	public static void textLengthLegality(TextField tFID, int limit) {
		tFID.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {

				if (tFID.getText().length() > limit) {
					tFID.setText(tFID.getText().substring(0, limit));
				}

			}
		});
	}

	/**
	 * Method to Convert from the stage/scene to pdf file with the report name the
	 * method takes a picture for the stage and resize it and implements it to the
	 * pdf file it also writes the name of the report with a message to the user at
	 * the top of the page
	 * 
	 * @param reportName name of the report
	 * @param path for the path
	 */
	public static void convertToPdf(String reportName, String path) {

		WritableImage nodeshot1 = root1.snapshot(new SnapshotParameters(), null);
		PixelReader reader = nodeshot1.getPixelReader();
		WritableImage nodeshot = new WritableImage(reader, 0, 100, 1060, 600);
		File file = new File("chart.png");

		try {
			ImageIO.write(SwingFXUtils.fromFXImage(nodeshot, null), "png", file);
		} catch (IOException e) {
			System.out.println("Error Catched in snap image");

		}

		PDDocument doc = new PDDocument();
		PDPage page = new PDPage();
		PDImageXObject pdimage;
		PDPageContentStream content;
		try {

			pdimage = PDImageXObject.createFromFile("chart.png", doc);
			content = new PDPageContentStream(doc, page);
			content.drawImage(pdimage, 0, 150, 625, 500);
			content.beginText();
			content.setFont(PDType1Font.TIMES_ROMAN, 20);
			content.newLineAtOffset(100, 730);
			String text = "This is the " + reportName + " Report that you requested:";
			content.showText(text);
			content.endText();
			content.close();
			doc.addPage(page);
			doc.save(path);
			doc.close();
			file.delete();

		} catch (IOException ex) {
			System.out.println("Error in Converting to pdf");

		}

	}

	/**
	 * Static Method to set and shows a help message (for question mark "help" icon)
	 * as the message parameter that was sent
	 * 
	 * @param message message to show in the help window
	 * @param c to get the class that was sent from
	 */
	@SuppressWarnings("static-access")
	public static void help(String message, Class<?> c) {
		ButtonType ok = new ButtonType("Ok");
		Alert alert1 = new Alert(AlertType.NONE, "Help", ok);
		alert1.setContentText(message);
		DialogPane dialogPane = alert1.getDialogPane();
		dialogPane.getStylesheets().add(c.getResource("/common/myDialogs.css").toExternalForm());
		dialogPane.getStyleClass().add("myDialog");
		alert1.initStyle(StageStyle.DECORATED.UNDECORATED);
		alert1.showAndWait();
	}

	/**
	 * Static Method to show the completion message that was sent as a parameter
	 * 
	 * @param message message to show
	 * @param c to get the class that was sent from
	 */
	@SuppressWarnings("static-access")
	public static void CompletionMessage(String message, Class<?> c) {

		ButtonType ok = new ButtonType("Ok");
		Alert alert1 = new Alert(AlertType.NONE, "", ok);
		alert1.setContentText(message);
		DialogPane dialogPane = alert1.getDialogPane();
		dialogPane.getStylesheets().add(c.getResource("/common/myDialogs.css").toExternalForm());
		dialogPane.getStyleClass().add("myDialog");
		alert1.initStyle(StageStyle.DECORATED.UNDECORATED);
		alert1.showAndWait();

	}
	
	/**
	 * Static Method to show the completion message that was sent as a parameter
	 * 
	 * @param message message to show
	 * @param c to get the class that was sent from
	 */
	@SuppressWarnings("static-access")
	public static void ShowDialog(String message, Class<?> c) {

		ButtonType ok = new ButtonType("Ok");
		Alert alert1 = new Alert(AlertType.NONE, "", ok);
		alert1.setContentText(message);
		DialogPane dialogPane = alert1.getDialogPane();
		dialogPane.getStylesheets().add(c.getResource("/common/myDialogs.css").toExternalForm());
		dialogPane.getStyleClass().add("myDialog");
		alert1.initStyle(StageStyle.DECORATED.UNDECORATED);
		alert1.showAndWait();

	}
	/**
	 * This method sets a red "*" before the text of the passed Label object, indicating that it is important.
	 * 
	 * @param important the Label object that is to be indicated as important
	 */
	public static void importantLabel(Label important) {
		Text star = new Text("*");
		star.setFill(Color.RED);
		Text label = new Text(important.getText().toString());
		TextFlow textFlow = new TextFlow(star);
		important.setGraphic(textFlow);
	}
	/**
	 * A method that allows the user to press the enter key to trigger a button's action.
	 * @param field the TextField where the event listener will be added
	 * @param button the button that will be triggered when the enter key is pressed
	 */
	public static void continueWithEnter(TextField field,Button button) {
		
		   field.addEventFilter(KeyEvent.KEY_PRESSED, event1 -> {
			    if (event1.getCode() == KeyCode.ENTER) {
			    	button.fire();
					   
			    }
			});
	}

}
