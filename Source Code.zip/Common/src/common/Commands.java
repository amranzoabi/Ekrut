package common;

/**
 * The class contains final static strings for commands used in the application.
 * 
 * @author Shadi
 * @author Mahran
 *
 */
public class Commands {

	/**
	 * The command for client connecting to the server
	 */
	public final static String ClientConnect = "clientconnect";

	/**
	 * The command for saving a user
	 */
	public final static String SaveUser = "saveuser";

	/**
	 * The command for deleting a user
	 */
	public final static String DeleteUser = "deleteuser";

	/**
	 * The command for editing a user
	 */
	public final static String EditUser = "edituser";

	/**
	 * The command for saving a product
	 */
	public final static String SaveProduct = "saveproduct";

	/**
	 * The command for deleting a product
	 */
	public final static String DeleteProduct = "deleteproduct";

	/**
	 * The command for editing a product
	 */
	public final static String EditProduct = "editproduct";

	/**
	 * The command for adding an item to the cart
	 */
	public final static String AddToCart = "addtocart";

	/**
	 * The command for removing an item from the cart
	 */
	public final static String RemoveFromCart = "removefromcart";

	/**
	 * The command for editing an item in the cart
	 */
	public final static String EditCartProduct = "EditCartProduct";

	/**
	 * The command for getting reports data
	 */
	public final static String GetReportsData = "getreportsdata";

	/**
	 * The command for setting reports data
	 */
	public final static String SetReportsData = "setreportsdata";

	/**
	 * The command for logging out
	 */
	public final static String Logout = "logout";

	/**
	 * The command for logging in
	 */
	public final static String Login = "login";

	/**
	 * The command for closing a window
	 */
	public final static String CloseWindow = "closewindow";

	/**
	 * The command for opening a customer window
	 */
	public final static String OpenCustomerWindow = "opencostumerwindow";
	/**
	 * The command for opening login window
	 */
	public final static String OpenLoginWindow = "openloginwindow";
	/**
	 * The command for opening DM window
	 */
	public final static String OpenDMWindow = "openDMWindow";
	/**
	 * The command for open order catalog window
	 */
	public final static String OpenOrdersCatalogWindow = "openorderscatalogwindow";
	/**
	 * The command for showing the data base data
	 */
	public final static String ShowDBData = "showdbdata";
	/**
	 * The command for checking Subscriber ID
	 */
	public final static String CheckSubscriberID = "checksubscriberid";
	/**
	 * The command for updating information
	 */
	public final static String UpdateInfo = "updateinfo";
	/**
	 * The command for getting all products data
	 */
	public final static String Getallproducts = "getallproducts";
	/**
	 * The command for getting all orders data
	 */
	public final static String Getallorders = "getallorders";
	/**
	 * The command for saving sale request
	 */
	public final static String SaveSaleRequest = "savesalerequest";
	/**
	 * The command for adding re stock request
	 */
	public final static String AddRestockRequest = "addrestockrequest";
	/**
	 * The command for getting all sales requests
	 */
	public final static String Getallsalerequests = "getallsalerequests";
	/**
	 * the command for getting all monthly orders reports
	 */
	public final static String Getallmonthlyrorderseports = "getallmonthlyordersreports";
	/**
	 * the command for getting all monthly customers reports
	 */
	public final static String Getallmonthlycostumersreports = "getallmonthlycostumersreports";
	/**
	 * the command for getting all monthly stock reports
	 */
	public final static String Getallmonthlystockreports = "getallmonthlystockreports";
	/**
	 * the command for registering new customer
	 */
	public final static String RegisterNewCustomer = "registernewcustomer";
	/**
	 * the command for registering new worker
	 */
	public final static String RegisterNewWorker = "registernewworker";
	/**
	 * the command for getting all customers registrations
	 */
	public final static String GetAllCustomersRegistirations = "getcustomerregistrations";
	/**
	 * the command for getting all workers registrations
	 */
	public final static String GetAllWorkersRegistirations = "getworkersregistrations";
	/**
	 * the command for updating customer registration status
	 */
	public final static String UpdateCustomerRegistirationStatus = "changecustomerstatus";
	/**
	 * the command for updating customer registration status to not approved
	 */
	public final static String UpdateCustomerRegistirationStatusToNotApproved = "changecustomerstatustonotapproved";
	/**
	 * the command for adding new customer
	 */
	public final static String AddNewCustomer = "addnewcustomer";
	/**
	 * the command for updating worker registration status
	 */
	public final static String UpdateWorkerRegistirationStatus = "updateworkerregistirationstatus";
	/**
	 * the command for adding new worker
	 */
	public final static String AddNewWorker = "addnewworker";
	/**
	 * the command for getting all machines data
	 */
	public final static String GetAllMachines = "GetAllMachines";
	/**
	 * the command for updating worker registration status to not approved
	 */
	public final static String UpdateWorkerRegistirationStatusToNotApproved = "updateworkerregistirationstatustonotapproved";
	/**
	 * the command for getting all products in every machine
	 */
	public final static String GetAllMachinesJoinsProductsInsideThem = "getallmchinesjoinsproductsinsidethem";
	/**
	 * the command for updating quantity of products in a machine
	 */
	public final static String UpdateProductInMachineQuantity = "updateproductinmachinequantity";
	/**
	 * the command for getting all products in a machine
	 */
	public final static String GetallproductsJoinsMachines = "getallproductsjoinsmachines";
	/**
	 * the command for submitting/saving the order (mostly saved last order)
	 */
	public final static String OrderDone = "orderdone";
	/**
	 * the command for canceling the order
	 */
	public final static String CancelOrder = "cancelorder";
	/**
	 * the command for approving order Delivery
	 */
	public final static String ApproveOrderDelivery = "ApproveOrderDelivery";// gdfgfdhfghfgh
	/**
	 * the command for getting category profit per month data
	 */
	public final static String GetCategoryProfitPerMonthTable = "getcategoryprofitpermonth";
	/**
	 * the command for getting all customers data
	 */
	public final static String GetAllCustomers = "getallcustomers";
	/**
	 * the command for getting all users data
	 */
	public final static String GetAllUsers = "getallusersss";
	/**
	 * the command for getting number of customers and subscribers
	 */
	public final static String GetNumberOfCustomers_Subscriber = "getnumberofcustomerssubscribers";
	/**
	 * the command for getting category percentage per month
	 */
	public final static String GetCategoryPercentagePerMonth = "getcategorypercentagepermonth";
	/**
	 * the command for checking stock reports
	 */
	public final static String CheckStockReports = "checkstockreports";
	/**
	 * the command for checking orders reports
	 */
	public final static String CheckOrdersReports = "checkordersreports";
	/**
	 * the command for checking customers reports
	 */
	public final static String CheckCustomerskReports = "checkcustomersreports";
	/**
	 * the command for getting users as customers
	 */
	public final static String GetUsersJoinsCostumers = "getusersjoinscostumers";
	/**
	 * the command for terminate a client
	 */
	public final static String TerminateClient = "terminateclient";
	/**
	 * the command for inserting new monthly customers report
	 */
	public final static String InsertNewMonthlyCustomersReport = "insertnewmonthlycustomersreport";
	/**
	 * the command for inserting new monthly orders report
	 */
	public final static String InsertNewMonthlyOrdersReport = "insertnewmonthlyordersreport";
	/**
	 * the command for inserting new category profit report
	 */
	public final static String InsertNewCategoryProfitReport = "insertnewcategoryprofitreport";
	/**
	 * the command for inserting new monthly stock report
	 */
	public final static String InsertNewMonthlyStockReport = "insertnewmonthlystockreport";
	/**
	 * the command for inserting new category percentage report
	 */
	public final static String InsertNewCategoryPercentageReport = "insertnewcategorypercentagereport";
	/**
	 * the command for getting products with total sales
	 */
	public final static String GetProductsWithTotalSales = "getproductswithtotalsales";
	/**
	 * the command for getting produce report data
	 */
	public final static String GetProduceReportsTableData = "getproducereportstabledata";
	/**
	 * the command for getting produce stock report data
	 */
	public final static String GetProduceStockReportTableData = "getproducestockreporttabledata";
	/**
	 * the command for making a sale
	 */
	public final static String MakeSale = "makesale";
	/**
	 * the command for inserting re stock request
	 */
	public final static String InsertRestockRequest = "insertrestockrequest";
	/**
	 * the command for getting all re stock requests
	 */
	public final static String GetAllRestockRequests = "getallrestockrequests";
	/**
	 * the command for getting cancel requests data
	 */
	public final static String CancelSaleRequest = "cancelsalerequest";
	/**
	 * the command for setting low level
	 */
	public final static String SetLowLevel = "setlowlevel";
	/**
	 * the command for getting low level
	 */
	public final static String GetLowLevel = "getlowlevel";
	/**
	 * the command for getting products in every order
	 */
	public final static String ProductsJoinsOrdersJoinsProductsInOrders = "productsjoinsordersjoinsproductsinmachines";
	/**
	 * the command for deleting order
	 */
	public final static String DeleteOrder = "deleteorder";
	/**
	 * the command for saving the order after payment
	 */
	public final static String OrderPaymentDone = "OrderPaymentDone";
	/**
	 * the command for refund the order
	 */
	public final static String RefundOrderAfterDelivery = "RefundOrderAfterDelivery";
	/**
	 * the command for getting machines
	 */
	public final static String getMachines = "getMachines";
	/**
	 * the command for getting coupons data
	 */
	public final static String getCoupons = "getCoupons";
	/**
	 * the command for deleting coupon
	 */
	public final static String deleteCoupon = "deleteCoupon";
	/**
	 * the command for getting order from the machine
	 */
	public final static String getOrderFromMachine = "getOrderFromMachine";
	/**
	 * the command for changing order status
	 */
	public final static String ChangeOrderStatus = "ChangeOrderStatus";
	/**
	 * the command for getting registration id number
	 */
	public final static String getRegestrationIDNumber = "getRegestrationIDNumber";
	/**
	 * the command for canceling applied sale
	 */
	public final static String CancelAppliededSale = "CancelAppliededSale";
	
	/**
	 * the command for Deleting re stock request 
	 */
	public final static String DeleteRestockRequest="deleterestockrequest";
	
	/**
	 * the command for Changing client screen to login home page
	 */
	public final static String ChangeClientScreenToLogin="changeclientsscreentologin";
	
	/**
	 * the command for adding quantity to products
	 */
	public final static String addQuantitiesToProducts="addquantitiestoproducts";
	
	/**
	 * the command for changing clients screen to connection home page
	 */
	public final static String ChangeClientScreenToConnection="changeclientsscreentoconnection";
	/**
	 * the command for getting the password of a user  
	 */
	public final static String getUserPassword = "getUserPassword";
	
	/**
	 * command for updating the last order arrival time after payment
	 */
	public final static String UpdateToRightArrivalTimeAfterPayment="updatetorightarrivaltimeafterpayment";
	
	/**
	 * command to change the order status to confirmed
	 */
	public final static String ChangeOrderStatusToConfirmed="changeorderstatustoconfirmed";
	
	/**
	 * get costumers and subscribers number for that month
	 */
	public final static String GetCostumersSubscribersNumberPerMonthTable="getcostumerssubscribersnumberpermonthtable";
	
	/**
	 * command to insert new report to the costumers and subscribers number reports 
	 */
	public final static String InsertNewCostumersNumberReport="insertnewcostumersnumberreport";
	
	/**
	 * update the restockrequeststatus to no sent
	 */
	public final static String UpdateRestockRequestStatusToSent="updaterestockrequeststatustosent";
	
	/**
	 * update the restockrequeststatus to no request
	 */
	public final static String UpdateRestockRequestStatusToNoRequest="updaterestockrequeststatustonorequest";
	/**
	 * the command for getting credit card info
	 */
	public final static String getCreditCardInfo = "getCreditCardInfo";

	

}
