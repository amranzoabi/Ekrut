package common;

import java.io.Serializable;

/**
 * This is Class to transfer messages between Client and server
 * 
 * @author Shadi
 *
 */
public class Message implements Serializable {
	/**
	 * to save the serializable serial version id
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * to save contents
	 */
	Object contents;
	/**
	 * to save the client
	 */
	String client;
	/**
	 * to save the command
	 */
	String command;
	/**
	 * to save message id
	 */
	int msgId = 0;
	/**
	 * to save the message type
	 */
	MessageType type = MessageType.Info;

	/**
	 * constructor to produce and set an instance of message
	 */
	public Message() {
		this.contents = new Object();
		this.contents = new String("nothing");
		this.client = new String();
		this.command = new String();
		type = MessageType.Info;
	}

	/**
	 * constructor to produce and set an instance of message
	 * 
	 * @param contents the contents
	 * @param client   the client
	 * @param command  the command
	 * @param type     the type
	 */
	public Message(Object contents, String client, String command, MessageType type) {
		this.contents = contents;
		this.client = client;
		this.command = command;
		this.type = type;

	}

	/**
	 * Method to get contents
	 * 
	 * @return return this contents
	 */
	public Object getContents() {
		return contents;
	}

	/**
	 * Method to set contents
	 * 
	 * @param contents set this contents to contents parameter
	 */
	public void setContents(Object contents) {
		this.contents = contents;
	}

	/**
	 * Method to get the client
	 * 
	 * @return return this client
	 */
	public String getClient() {
		return client;
	}

	/**
	 * Method to set the client
	 * 
	 * @param client set this client to client
	 */
	public void setClient(String client) {
		this.client = client;
	}

	/**
	 * Method to get command
	 * 
	 * @return return this command
	 */
	public String getCommand() {
		return command;
	}

	/**
	 * Method to set this command
	 * 
	 * @param command set this command to command
	 */
	public void setCommand(String command) {
		this.command = command;
	}

	/**
	 * Method to get message id
	 * 
	 * @return return this message id
	 */
	public int getMsgId() {
		return msgId;
	}

	/**
	 * Method to set this message id
	 * 
	 * @param msgNumber set this message id to msgNumber
	 */
	public void setMsgId(int msgNumber) {
		this.msgId = msgNumber;
	}

	/**
	 * Method to get this type
	 * 
	 * @return return this type
	 */
	public MessageType getType() {
		return type;
	}

	/**
	 * Method to set this type
	 * 
	 * @param type set this type to type
	 */
	public void setType(MessageType type) {
		this.type = type;
	}

	/**
	 * Method to override toString and get it in the format we need
	 */
	@Override
	public String toString() {
		return "<" + msgId + ">" + "Message [contents=" + contents + ", client=" + client + ", command=" + command
				+ ", type=" + type + "]";
	}

}
