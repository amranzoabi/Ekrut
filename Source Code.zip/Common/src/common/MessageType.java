package common;

/**
 * ENUM for message Types
 * 
 * @author Shadi
 *
 */
public enum MessageType {
	/**
	 * for info
	 */
	Info, 
	/**
	 * for
	 */
	Get,
	/**
	 * to update
	 */
	Update,
	/**
	 * to insert
	 */
	Insert,
}
