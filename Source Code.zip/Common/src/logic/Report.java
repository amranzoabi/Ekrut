package logic;

/**
 * This class represents a report.
 * 
 * @author Shadi
 *
 */
public class Report {
	/**
	 * to save report id
	 */
	String ReportID;
	/**
	 * to save report type
	 */
	ReportType type;

	/**
	 * An enumeration of report types.
	 * 
	 * @author Shadi
	 *
	 */
	public static enum ReportType {
		/**
		 * customer report
		 */
		CostumersReport,
		/**
		 * order report
		 */
		OrdersReport, 
		/**
		 * stock report
		 */
		StockReport
	}

	/**
	 * Creates a new report with the given ID and type.
	 * 
	 * @param reportID The report's ID.
	 * @param type     The report's type.
	 */
	public Report(String reportID, ReportType type) {
		this.ReportID = reportID;
		this.type = type;
	}

	/**
	 * Returns the report's ID.
	 * 
	 * @return The report's ID.
	 */
	public String getReportID() {
		return ReportID;
	}

	/**
	 * Sets the report's ID.
	 * 
	 * @param reportID The report's ID.
	 */
	public void setReportID(String reportID) {
		ReportID = reportID;
	}

	/**
	 * Returns the report's type.
	 * 
	 * @return The report's type.
	 */
	public ReportType getType() {
		return type;
	}

	/**
	 * Sets the report's type.
	 * 
	 * @param type The report's type.
	 */
	public void setType(ReportType type) {
		this.type = type;
	}

}
