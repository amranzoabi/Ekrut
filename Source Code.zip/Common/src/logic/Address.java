package logic;

/**
 * this is a class to help store/save the address
 * 
 * @author Shadi
 *
 */
public class Address {
	/**
	 * to save the city
	 */
	private String City;
	/**
	 * to save the street name
	 */
	private String StreetName;
	/**
	 * to save the street number
	 */
	private String StreetNumber;
	/**
	 * to save the building number
	 */
	private String BuildingNumber;
	/**
	 * to save apartment number
	 */
	private String ApartmentNumber;

	/**
	 * Constructor to create an instance and set the data
	 * 
	 * @param city            the city
	 * @param streetName      the street name
	 * @param streetNumber    the street number
	 * @param buildingNumber  the building number
	 * @param apartmentNumber the apartment number
	 */
	public Address(String city, String streetName, String streetNumber, String buildingNumber, String apartmentNumber) {
		super();
		City = city;
		StreetName = streetName;
		StreetNumber = streetNumber;
		BuildingNumber = buildingNumber;
		ApartmentNumber = apartmentNumber;
	}

	/**
	 * Method to get city
	 * 
	 * @return this City
	 */
	public String getCity() {
		return City;
	}

	/**
	 * Method to set the city
	 * 
	 * @param city set this city to city
	 */
	public void setCity(String city) {
		City = city;
	}

	/**
	 * Method to get street name
	 * 
	 * @return return the StreetName
	 */
	public String getStreetName() {
		return StreetName;
	}

	/**
	 * Method to set the street name
	 * 
	 * @param streetName set this street name to streetName
	 */
	public void setStreetName(String streetName) {
		StreetName = streetName;
	}

	/**
	 * Method to get street number
	 * 
	 * @return return this StreetNumber
	 */
	public String getStreetNumber() {
		return StreetNumber;
	}

	/**
	 * Method to set this street number
	 * 
	 * @param streetNumber set this street number to streetNumber
	 */
	public void setStreetNumber(String streetNumber) {
		StreetNumber = streetNumber;
	}

	/**
	 * Method to get Building Number
	 * 
	 * @return return this buildingNumber
	 */
	public String getBuildingNumber() {
		return BuildingNumber;
	}

	/**
	 * Method to set the building number
	 * 
	 * @param buildingNumber set this building number to buildingNumber
	 */
	public void setBuildingNumber(String buildingNumber) {
		BuildingNumber = buildingNumber;
	}

	/**
	 * Method to get apartment number
	 * 
	 * @return return this ApartmentNumber
	 */
	public String getApartmentNumber() {
		return ApartmentNumber;
	}

	/**
	 * Method to set apartment number
	 * 
	 * @param apartmentNumber set this apartment number to apartmentNumber
	 */
	public void setApartmentNumber(String apartmentNumber) {
		ApartmentNumber = apartmentNumber;
	}

	/**
	 * Method override to string to get it in the format we need
	 */
	@Override
	public String toString() {
		return "Address [City=" + City + ", StreetName=" + StreetName + ", StreetNumber=" + StreetNumber
				+ ", BuildingNumber=" + BuildingNumber + ", ApartmentNumber=" + ApartmentNumber + "]";
	}

}
