package logic;

/**
 * This class represents a registration system for users.
 * 
 * @author Shadi
 */
public class Registiration {
	/**
	 * An enumeration of user types.
	 */
	public static enum UserType {
		/**
		 * customer type
		 */
		Costumer,
		/**
		 * subscriber type
		 */
		Subscriber,
		/**
		 * worker type
		 */
		Worker
	}

	/**
	 * Registers a new user.
	 * 
	 * @param user The user to register.
	 * @return true if the registration was successful, false otherwise.
	 */
	public boolean RegisterNewUser(User user)// needs to be implemented
	{
		return true;
	}

}
