package logic;

/**
 * This class represents a subscriber
 * 
 * @author Mahran
 * @author Shadi
 *
 */
public class Subscriber {
	/**
	 * to save subscriber information
	 */
	private String firstName, lastName, idNumber, phoneNumber, email, creditCardNum, subscriberNum;

	/**
	 * Creates a new subscriber with the given personal information.
	 * 
	 * @param fN  The subscriber's first name.
	 * @param lN  The subscriber's last name.
	 * @param idN The subscriber's ID number.
	 * @param pN  The subscriber's phone number.
	 * @param em  The subscriber's email address.
	 * @param ccN The subscriber's credit card number.
	 * @param sN  The subscriber's subscriber number.
	 */
	public Subscriber(String fN, String lN, String idN, String pN, String em, String ccN, String sN) {
		this.firstName = fN;
		this.lastName = lN;
		this.idNumber = idN;
		this.phoneNumber = pN;
		this.email = em;
		this.creditCardNum = ccN;
		this.subscriberNum = sN;
	}

	/**
	 * Returns the subscriber's first name.
	 * 
	 * @return The subscriber's first name.
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Returns the subscriber's last name.
	 * 
	 * @return The subscriber's last name.
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Returns the subscriber's ID number.
	 * 
	 * @return The subscriber's ID number.
	 */
	public String getIdNumber() {
		return idNumber;
	}

	/**
	 * Returns the subscriber's phone number.
	 * 
	 * @return The subscriber's phone number.
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Returns the subscriber's email address.
	 * 
	 * @return The subscriber's email address.
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Returns the subscriber's credit card number.
	 * 
	 * @return The subscriber's credit card number.
	 */
	public String getCreditCardNum() {
		return creditCardNum;
	}

	/**
	 * Returns the subscriber's subscriber number.
	 * 
	 * @return The subscriber's subscriber number.
	 */
	public String getSubscriberNum() {
		return subscriberNum;
	}

}
