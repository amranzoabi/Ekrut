package logic;

/**
 * The User class represents a user with various attributes such as user 
 * ID, ID number, name, password, contact information and user type.
 * It also includes methods to get and set the values of these attributes 
 * as well as a toString method to print the user's information.
 * 
 * @author Mahran
 *
 */
public class User {
	/**
	 * to save the user id
	 */
	private Integer UserID;
	/**
	 * to save the id number
	 */
	private String IDNumber;
	/**
	 * to save the user name
	 */
	private String UserName;
	/**
	 * to save the password
	 */
	private String Password;
	/**
	 * to save the home area
	 */
	/**
	 * to save the first name
	 */
	private String FirstName;
	/**
	 * to save the last nameS
	 */
	private String LastName;
	
	/**
	 * to save the home area
	 */
	private String HomeArea;

	/**
	 * to save the email
	 */
	private String Email;
	/**
	 * to save the phone number
	 */
	private String PhoneNumber;
	/**
	 * to save the type
	 */
	private String type;
	/**
	 * to save the area
	 */
	private String Area;
	/**
	 * to save is logged in
	 */
	private Integer isLoggedin;
	/**
	 * to save the customer id
	 */
	private Integer costumerID;
	
	/**
     * Constructor for creating a new User instance with the given attributes.
     * @param userID the user's ID
     * @param iDNumber the user's ID number
     * @param userName the user's username
     * @param password the user's password
     * @param firstName the user's first name
     * @param lastName the user's last name
     * @param homeArea the user's home area
     * @param email the user's email address
     * @param phoneNumber the user's phone number
     * @param type the user's type (e.g. administrator, customer)
     * @param area the user's area
     * @param isLoggedin whether the user is currently logged in
     * @param costumerID the user's customer ID
	 */
	public User(Integer userID, String iDNumber, String userName, String password, String firstName, String lastName,
			String homeArea, String email, String phoneNumber, String type, String area, Integer isLoggedin,
			Integer costumerID) {
		super();
		UserID = userID;
		IDNumber = iDNumber;
		UserName = userName;
		Password = password;
		FirstName = firstName;
		LastName = lastName;
		HomeArea = homeArea;
		Email = email;
		PhoneNumber = phoneNumber;
		this.type = type;
		Area = area;
		this.isLoggedin = isLoggedin;
		this.costumerID = costumerID;
	}

	/**
     * Returns the user's ID.
     * @return the user's ID
     */
    public Integer getUserID() {
        return UserID;
    }

    /**
     * Sets the user's ID.
     * @param userID the user's ID
     */
    public void setUserID(Integer userID) {
        UserID = userID;
    }

    /**
     * Returns the user's ID number.
     * @return the user's ID number
     */
    public String getIDNumber() {
        return IDNumber;
    }

    /**
     * Sets the user's ID number.
     * @param iDNumber the user's ID number
     */
    public void setIDNumber(String iDNumber) {
        IDNumber = iDNumber;
    }

    /**
     * Returns the user's username.
     * @return the user's username
     */
    public String getUserName() {
        return UserName;
    }

    /**
     * Sets the user's username.
     * @param userName the user's username
     */
    public void setUserName(String userName) {
        UserName = userName;
    }

    /**
     * Returns the user's password.
     * @return the user's password
     */
    public String getPassword() {
        return Password;
    }

    /**
     * Sets the user's password.
     * @param password the user's password
     */
    public void setPassword(String password) {
        Password = password;
    }

    /**
     * Returns the user's first name.
     * @return the user's first name
     */
    public String getFirstName() {
        return FirstName;
    }

    /**
     * Sets the user's first name.
     * @param firstName the user's first name
     */
    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    /**
     * Returns the user's last name.
     * @return the user's last name
     */
    public String getLastName() {
        return LastName;
    }

    /**
     * Sets the user's last name.
     * @param lastName the user's last name
     */
    public void setLastName(String lastName) {
        LastName = lastName;
    }

    /**
     * Returns the user's home area.
     * @return the user's home area
     */
    public String getHomeArea() {
        return HomeArea;
    }

    /**
     * Sets the user's home area.
     * @param homeArea the user's home area
     */
    public void setHomeArea(String homeArea) {
        HomeArea = homeArea;
    }

    /**
     * Returns the user's email address.
     * @return the user's email address
     */
    public String getEmail() {
        return Email;
    }

    /**
     * Sets the user's email address.
     * @param email the user's email address
     */
    public void setEmail(String email) {
        Email = email;
    }

    /**
     * Returns the user's phone number.
     * @return the user's phone number
     */
    public String getPhoneNumber() {
        return PhoneNumber;
    }

    /**
     * Sets the user's phone number.
     * @param phoneNumber the user's phone number
     */
    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    /**
     * Returns the user's type.
     * @return the user's type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the user's type.
     * @param type the user's type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Returns the user's area.
     * @return the user's area
     */
    public String getArea() {
        return Area;
    }

    /**
     * Sets the user's area.
     * @param area the user's area
     */
    public void setArea(String area) {
        Area = area;
    }

    /**
     * Returns whether the user is currently logged in.
     * @return whether the user is currently logged in
     */
    public Integer getIsLoggedin() {
        return isLoggedin;
    }

    /**
     * Sets whether the user is currently logged in.
     * @param isLoggedin whether the user is currently logged in
     */
    public void setIsLoggedin(Integer isLoggedin) {
        this.isLoggedin = isLoggedin;
    }

    /**
     * Returns the user's customer ID.
     * @return the user's customer ID
     */
    public Integer getCostumerID() {
        return costumerID;
    }

    /**
     * Sets the user's customer ID.
     * @param costumerID the user's customer ID
     */
    public void setCostumerID(Integer costumerID) {
        this.costumerID = costumerID;
    }

	/**
	 *Returns a string representation of the user's information.
	 * @return a string representation of the user's information
	 */
	@Override
	public String toString() {
		return "User [UserID=" + UserID + ", IDNumber=" + IDNumber + ", UserName=" + UserName + ", Password=" + Password
				+ ", FirstName=" + FirstName + ", LastName=" + LastName + ", HomeArea=" + HomeArea + ", Email=" + Email
				+ ", PhoneNumber=" + PhoneNumber + ", type=" + type + ", Area=" + Area + ", isLoggedin=" + isLoggedin
				+ ", costumerID=" + costumerID + "]";
	}
	
	
	
	
	
	

	

}
