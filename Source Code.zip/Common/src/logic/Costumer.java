package logic;

/**
 * The class represents a costumer with additional CreditCardNumber attribute.
 * 
 * @author Mohamad
 *
 */
public class Costumer extends User {
	
	/**
	 * Creates a new costumer with the given information.
	 * @param userID the costumer's user ID
	 * @param iDNumber the costumer's ID number
	 * @param userName the costumer's username
	 * @param password the costumer's password
	 * @param firstName the costumer's first name
	 * @param lastName the costumer's last name
	 * @param homeArea the costumer's home area
	 * @param email the costumer's email address
	 * @param phoneNumber the costumer's phone number
	 * @param type the costumer's type
	 * @param area the costumer's area
	 * @param isLoggedin whether the costumer is currently logged in
	 * @param costumerID the costumer's customer ID
	 */
	public Costumer(Integer userID, String iDNumber, String userName, String password, String firstName,
			String lastName, String homeArea, String email, String phoneNumber, String type, String area,
			Integer isLoggedin, Integer costumerID) {
		super(userID, iDNumber, userName, password, firstName, lastName, homeArea, email, phoneNumber, type, area, isLoggedin,
				costumerID);
		
	}

	private String CreditCardNumber;

	/**
	 * Constructs a Costumer object with the specified properties.
	 *
	 * @param userName         the user name
	 * @param password         the password
	 * @param userID           the user ID
	 * @param homeArea         the home area
	 * @param firstName        the first name of the person
	 * @param lastName         the last name of the person
	 * @param iDNumber         the identification number of the person
	 * @param email            the email address of the person
	 * @param phoneNumber      the phone number of the person
	 * @param creditCardNumber the credit card number of the person
	 */



	/**
	 * Returns the credit card number of the customer.
	 * 
	 * @return the credit card number of the customer
	 */
	public String getCreditCardNumber() {
		return CreditCardNumber;
	}

	/**
	 * Sets the credit card number of the customer.
	 *
	 * @param creditCardNumber the new credit card number of the customer
	 */
	public void setCreditCardNumber(String creditCardNumber) {
		CreditCardNumber = creditCardNumber;
	}

}
