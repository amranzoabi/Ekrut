package logic;

/**
 * Class representing a worker.
 * 
 * @author Mahran
 *
 */
public class Worker extends User {
	
	/**
	 * Creates a new worker with the given information.
	 * @param userID the worker's user ID
	 * @param iDNumber the worker's ID number
	 * @param userName the worker's username
	 * @param password the worker's password
	 * @param firstName the worker's first name
	 * @param lastName the worker's last name
	 * @param homeArea the worker's home area
	 * @param email the worker's email address
	 * @param phoneNumber the worker's phone number
	 * @param type the worker's type
	 * @param area the worker's area
	 * @param isLoggedin whether the worker is currently logged in
	 * @param costumerID the worker's customer ID
	 */
	public Worker(Integer userID, String iDNumber, String userName, String password, String firstName, String lastName,
			String homeArea, String email, String phoneNumber, String type, String area, Integer isLoggedin,
			Integer costumerID) {
		super(userID, iDNumber, userName, password, firstName, lastName, homeArea, email, phoneNumber, type, area, isLoggedin,
				costumerID);
		// TODO Auto-generated constructor stub
	}

	/**
	 * to save the role
	 */
	private String Role;

	/**
	 * Constructs a new worker with the given parameters.
	 * 
	 * @param userName    the user name of the worker
	 * @param password    the password of the worker
	 * @param userID      the ID of the worker
	 * @param homeArea    the home area of the worker
	 * @param firstName   the first name of the worker
	 * @param lastName    the last name of the worker
	 * @param iDNumber    the ID number of the worker
	 * @param email       the email of the worker
	 * @param phoneNumber the phone number of the worker
	 * @param role        the role of the worker
	 * 
	 */
	

}
