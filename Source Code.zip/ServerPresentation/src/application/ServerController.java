package application;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import Server.DBController;
import Server.EchoServer;
import Server.ServerUI;
import common.Commands;
import common.Message;

/**
 * This is class controller for server Controller page
 * 
 * @author Mohamed
 *
 */
public class ServerController extends Application {
	/**
	 * to save the root
	 */
	AnchorPane root;
	/**
	 * to save the server controller
	 */
	public static ServerController cp;

	/**
	 * Label to show server IP
	 */
	@FXML
	Label ServerIP;
	/**
	 * Label to show Server Host Name
	 */
	@FXML
	Label ServerHostName;
	/**
	 * Button for exit Button
	 */
	@FXML
	private Label lbllist;
	/**
	 * exit button
	 */
	@FXML
	private Button btnExit = null;
	/**
	 * Button for connect Button
	 */
	@FXML
	private Button btnconnect = null;
	/**
	 * Button for discount Button
	 */
	@FXML
	private Button btdisnconnect = null;
	/**
	 * TextField to get the iP
	 */
	@FXML
	private TextField IPtxt;
	/**
	 * TextField to get the port
	 */
	@FXML
	private TextField portxt;
	/**
	 * TextField to get password
	 */
	@FXML
	private TextField passwordtxt;
	/**
	 * TextField to get user name
	 */
	@FXML
	private TextField UserNametxt;
	/**
	 * TextField to get name
	 */
	@FXML
	private TextField Nametxt;
	/**
	 * TextArea to show the Clients Connections information
	 */
	@FXML
	private TextArea ClientConnections;
	/**
	 * TextArea to show the event log information
	 */
	@FXML
	private TextArea EventLog;

	/**
	 * Method to start the server
	 */
	/**
	 * to save window xOffset
	 */
	private double xOffset = 0;
	/**
	 * to save window yOffset
	 */
	private double yOffset = 0;
	/**
	 * to save if there is a connection
	 */
	private int connected = 0;

	/**
	 * Method to start the stage of the server
	 */
	@Override
	public void start(Stage stage) throws Exception {
		Image icon = new Image("/icons/server.png");
		FXMLLoader loader = new FXMLLoader();
		stage.initStyle(StageStyle.UNDECORATED);
		loader.setLocation(getClass().getResource("ServerPort.fxml"));
		try {
			root = loader.load();
			root.setOnMousePressed(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					xOffset = event.getSceneX();
					yOffset = event.getSceneY();
				}

			});
			root.setOnMouseDragged(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					stage.setX(event.getScreenX() - xOffset);
					stage.setY(event.getScreenY() - yOffset);
				}

			});
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cp = loader.getController();
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("ServerPage.css").toExternalForm());// implement css design
		stage.setTitle("Ekrut Server");
		stage.getIcons().add(icon);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * Method to set the server IP
	 * 
	 * @param s set the server IP to s
	 */
	public void setserverip(String s) {
		ServerIP.setText(s);
	}

	/**
	 * Method to set server host name
	 * 
	 * @param s set host name to s
	 */
	public void setserverhostname(String s) {
		ServerHostName.setText(s);
	}

	/**
	 * Method to get port
	 * 
	 * @return return this port
	 */
	private String getport() {
		return portxt.getText();
	}

	/**
	 * Method to get data base user name
	 * 
	 * @return return this user name
	 */
	private String DBUserName() {
		return UserNametxt.getText();
	}

	/**
	 * Method to get the data base name
	 * 
	 * @return return this data base name
	 */
	private String DBName() {
		return Nametxt.getText();
	}

	/**
	 * Method to return data base Password
	 * 
	 * @return return this data base password
	 */
	private String DBpassword() {
		return passwordtxt.getText();
	}

	/**
	 * Method to add message to the event log
	 * 
	 * @param msg add msg to the event log
	 */
	public void addMessage(String msg) {
		EventLog.appendText(msg);
		EventLog.appendText("\n");
	}

	/**
	 * Method to connect to the data base on clicking connect
	 * 
	 * @param event connect button is clicked
	 * @throws Exception exception will be thrown when there is an error
	 */
	public void connect(ActionEvent event) throws Exception {
		connected = 1;
		System.out.println("im here");
		String port, DBName, DBUserName, DBpassword;
		port = getport();
		DBUserName = DBUserName();
		DBName = DBName();
		DBpassword = DBpassword();
		if (port.trim().isEmpty() || DBUserName.trim().isEmpty() || DBpassword.trim().isEmpty()
				|| DBName.trim().isEmpty()) {
			EventLog.setText("Error!\n");

		} else {
			String ReturnedMessage = DBController.getInstance().ConnectToDB(DBUserName, DBpassword, DBName);
			EventLog.appendText(ReturnedMessage);
			if (ReturnedMessage.contains("succeed")) {
				EventLog.appendText("Server started listening for connections on port " + port + "\n");
				ServerUI.runServer(port);
				StartTimerToCheckAvailableProducts();
				StartTimerToCheckNotAvailableProducts();
				btdisnconnect.setOpacity(1);
				btnconnect.setOpacity(0.15);
				btnconnect.setDisable(true);
				btdisnconnect.setDisable(false);
				EchoServer.setDB(DBController.getInstance());
			}
			else
				EventLog.appendText("Error occured while trying to start the server\n");
		}
		
		
	}
		
		
	
	
	/**
	 * start a timer to check the quantities of the products if its not 0 set Available
	 */
	public void StartTimerToCheckAvailableProducts()
	{
		Timer timer= new Timer();
		TimerTask CheckAvailable = new TimerTask() {

			@Override
			public void run() {
				DBController.getInstance().CheckQuantities_ChangeStatus_ToAvailable();
			}
		};
		timer.scheduleAtFixedRate(CheckAvailable, 5000 , 5000);
		
	}
	
	/**
	 * start a timer to check the quantities of the products if its 0 set NotAvailable
	 */
	public void StartTimerToCheckNotAvailableProducts()
	{
		Timer timer = new Timer();
		TimerTask CheckNotAvailable = new TimerTask() {

			@Override
			public void run() {
				DBController.getInstance().CheckQuantities_ChangeStatus_ToNotAvailable();
			}
		};
		timer.scheduleAtFixedRate(CheckNotAvailable, 5000 , 5000);
		
	}
	

	/**
	 * Method to Sets the text of the connected clients display
	 * @param s the string to set the text to
	 */
	public void setConnectedClients(String s) {
		ClientConnections.setText(s);
	}

	/**
	 * Method to disconnect from the data base
	 * 
	 * @param event event disconnect clicked
	 * @throws Exception exception will be thrown when there is an error
	 */
	public void getdisnconnectBtn(ActionEvent event) throws Exception {
		EventLog.clear();
		ServerUI.sv.stopListening();
		ServerUI.sv.close();
		btdisnconnect.setOpacity(0.15);
		btnconnect.setOpacity(1);
		btdisnconnect.setDisable(true);
		btnconnect.setDisable(false);
		// disconnect all connected users
		if (ServerUI.sv != null)
			ServerUI.sv.LogOutAllUsers();
	}
	
	/**
	 * function to disconnect all users
	 * @param event click
	 */
	@FXML
    void DisconnectClients(ActionEvent event) {
		 Message msg = new Message();
   	     msg.setCommand(Commands.ChangeClientScreenToConnection);
		 msg.setContents("Nothing");
		 if (ServerUI.sv != null) {
		 ServerUI.sv.LogOutAllUsers();
		 ServerUI.sv.sendToAllClients(msg);
		 ServerUI.sv.DisconnectAllClients();
		 ServerUI.sv.UpdateClientConnections();
		 }
		 
		
    }

    /**
     * function to logout all loggedin users
     * @param event click
     */
    @FXML
    void LogOutUsers(ActionEvent event) {
    	if (ServerUI.sv != null)
    	ServerUI.sv.LogOutAllUsers();
    
    }

	/**
	 * Method to exit the system
	 * 
	 * @param event event X is clicked
	 * @throws Exception exception will be thrown when there is an error
	 */
	public void getExitBtn(ActionEvent event) throws Exception {
		System.out.println("exit\n");
		System.exit(0);
	}

	/**
	 * Method for closing the application, the window of the application would be
	 * closed
	 * 
	 * @param event event of the X icon clicked
	 * @throws Exception Exception will be thrown if an error occurs
	 */
	public void clsoe(MouseEvent event) throws Exception // close window
	{
		EventLog.setText("Server Disconnected");
		if (ServerUI.sv != null) {
			ServerUI.sv.stopListening();
			ServerUI.sv.close();
			btdisnconnect.setOpacity(0.15);
			btnconnect.setOpacity(1);
			btdisnconnect.setDisable(true);
			btnconnect.setDisable(false);

		}
		System.out.println("exit\n");
		System.exit(0);

	}
	
	/**
	 * Method to import external user
	 * @param e event activated on clicking import users 
	 */
	public void importUsers(ActionEvent e)
	{
		if (ServerUI.sv != null)
			DBController.getInstance().importUsers();
	}

}
