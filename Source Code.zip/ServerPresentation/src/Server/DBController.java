package Server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import application.ServerController;
import logic.User;

/**
 * This class is a singleton design pattern which is responsible for connecting
 * to a MySQL database and handle the data operations
 * 
 * @author Shadi
 * @author Mahran
 *
 */
public class DBController {
	////////////////////////////////// Singelton Start
	////////////////////////////////// ////////////////////////////////////////////

	/**
	 * Singelton Design pattern for the database
	 */
	private static DBController MyInstance = new DBController();

	/**
	 * Method to get the single instance made of the controller
	 * 
	 * @return my instance (DBController)
	 */
	public static DBController getInstance() {
		return MyInstance;
	}

	/**
	 * private constructor only one instance can be made
	 */
	private DBController() {

	}

	///////////////////////////////////// Singelton Done
	///////////////////////////////////// ///////////////////////////////////////////

	/**
	 * for connection
	 */
	private  Connection conn;

	/**
	 * ConnectToDB method is used to establish a connection to the MySQL database
	 * using the provided credentials
	 * 
	 * @param UserName   the user name to connect to the database
	 * @param Password   the password associated with the user name
	 * @param SchemaName the name of the schema or database to connect to
	 * @return messageToReturn a string message indicating the status of the
	 *         connection attempt
	 */
	public String ConnectToDB(String UserName, String Password, String SchemaName) {
		String messageToReturn = "";
		try {
			System.out.println("Driver definition succeed");
		} catch (Exception ex) {
			/* handle the error */
			messageToReturn += "Driver definition failed\n";
			System.out.println("Driver definition failed");
		}

		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost/" + SchemaName + "?serverTimezone=IST", UserName,
					Password);
			// Connection conn =
			// DriverManager.getConnection("jdbc:mysql://192.168.3.68/test","root","Root");
			messageToReturn += "SQL connection succeed\n";
			System.out.println("SQL connection succeed");
			// createTableCourses(conn);;
		} catch (SQLException ex) {/* handle any errors */
			messageToReturn += "SQLException: " + ex.getMessage() + "\n";
			messageToReturn += "SQLState: " + ex.getSQLState() + "\n";
			messageToReturn += "VendorError: " + ex.getErrorCode() + "\n";
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}
		return messageToReturn;

	}

	/**
	 * InsertProductsIntoProducts_in_orders method is used to insert the products
	 * into the products_in_orders table
	 * 
	 * @param id       a list of product IDs to be inserted
	 * @param quantity a list of quantities of each product to be inserted
	 * @return boolean indicating the success or failure of the insertion
	 */
	public boolean InsertProductsIntoProducts_in_orders(ArrayList<String> id, ArrayList<String> quantity) {
		String Query = "SELECT OrderID AS LastOrderID FROM orders WHERE OrderID = @@Identity";
		try {
			PreparedStatement pstmt = conn.prepareStatement(Query);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			int orderidd = rs.getInt(1);
			System.out.println("orderid*****************************=" + orderidd);
			System.out.println("array size in function :" + id.size());
			for (int i = 0; i < id.size(); i++)
				this.AddProductToOrder(orderidd, Integer.parseInt(id.get(i)), Integer.parseInt(quantity.get(i)));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;

	}

	/**
	 * insertSubscriptionCoupon method is used to insert a subscription coupon into
	 * the database
	 * 
	 * @return boolean indicating the success or failure of the insertion
	 */
	public boolean insertSubscriptionCoupon() {

		try {
			String Query11 = "SELECT costumerID AS LastCostumerID FROM costumers WHERE costumerID = @@Identity;";
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(Query11);
			rs.next();
			int customer = rs.getInt(1);
			System.out.println("************************************" + customer);

			return true;
		} catch (SQLException e) {
			System.out.println("Error in insert subscription");
			e.printStackTrace();
		}
		return false;

	}

	/**
	 * insertNewUserAsCustomer method is used to insert a new customer into the
	 * database
	 * 
	 * @param array an ArrayList of objects containing the user information to be
	 *              inserted
	 * @return boolean indicating the success or failure of the insertion
	 */
	public boolean insertNewUserAsCustomer(ArrayList<Object> array) {

		String idnumber = (String) array.get(1);
		String username = (String) array.get(2);
		String password = (String) array.get(3);
		String fname = (String) array.get(4);
		String lname = (String) array.get(5);
		String creditcard = (String) array.get(6);
		String homearea = "North";
		String email = (String) array.get(7);
		String phone = (String) array.get(8);
		String type;
		String userType;

		if (((String) array.get(9)).equals("Subscriber")) {
			type = "Subscriber";
			userType = "Subscriber";
		} else {
			type = "Customer";
			userType = "Costumer";
		}
		String status = "APPROVED";
		String area = null;
		String customerQuery = "insert into costumers values(null,'" + username + "',0,'" + status + "',0,'"
				+ creditcard + "',null,null,'" + type + "');";
		this.SelectEditQuery(customerQuery);

		try {
			String Query = "Select costumerID As LastCostumerID from costumers where costumerID=@@Identity;";
			PreparedStatement pstmt = conn.prepareStatement(Query);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			int customerid = rs.getInt(1);

			String userQuery = "insert into users values(null,'" + idnumber + "','" + username + "','" + password
					+ "','" + fname + "','" + lname + "','" + homearea + "','" + email + "','" + phone + "','"
					+ userType + "','" + area + "',0,'" + customerid + "');";
			this.SelectEditQuery(userQuery);

			if (type.equals("Subscriber")) {
				String coQuery = "insert into coupons_for_costumers values('" + customerid + "',2);";
				this.SelectEditQuery(coQuery);
			}
			return true;

		} catch (SQLException e) {
			System.out.println("Error in insert newuser");
			e.printStackTrace();
		}

		return false;
	}

	/**
	 * InsertNewOrder method is used to insert a new order into the database
	 * 
	 * @param price          the price of the order
	 * @param paymentMethod  the method of payment for the order
	 * @param DeliveryMethod the delivery method for the order
	 * @param CostumerID     the ID of the customer placing the order
	 * @return boolean indicating the success of the insertion
	 */
	public boolean InsertNewOrder(String price, String paymentMethod, String DeliveryMethod, String CostumerID) {
		int min = 10;
		int max = 50;
		System.out.println("Random value in int from " + min + " to " + max + ":");
		String random_int;
		String OrderStatus;
		if (DeliveryMethod.equals("NotCompleted")) {
			random_int = "";
			OrderStatus = "NotCompleted";
		} else if (!DeliveryMethod.equals("PickUp")) {
			random_int = ((Double) Math.floor(Math.random() * (max - min + 1) + min)).toString().substring(0, 2);
			random_int += " Minutes";
			OrderStatus = "Ready For Dispatch";
		} else {
			random_int = "";
			OrderStatus = "Ready To Pickup";
		}

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

		String datetimeNOW = LocalDateTime.now().format(dtf);

		String Query = "Insert into orders values(null," + Double.parseDouble(price) + ",'" + random_int + "','"
				+ datetimeNOW + "','" + OrderStatus + "'," + Integer.parseInt(CostumerID) + ",0.0,'" + DeliveryMethod
				+ "','" + paymentMethod + "'" + ",5" + ",''" + ")";

		this.SelectEditQuery(Query);
		return true;
	}

	/**
	 * InsertNewOrderAfterPayment method is used to insert a new order into the
	 * database after a payment is made
	 * 
	 * @param price          the price of the order
	 * @param paymentMethod  the method of payment for the order
	 * @param DeliveryMethod the delivery method for the order
	 * @param CostumerID     the ID of the customer placing the order
	 * @param code           The code of the payment
	 * @param machineid      the machine id used for the payment
	 * @return boolean indicating the success of the insertion
	 */
	public boolean InsertNewOrderAfterPayment(String price, String paymentMethod, String DeliveryMethod,
			String CostumerID, String code, String machineid) {
		int min = 10;
		int max = 50;
		System.out.println("Random value in int from " + min + " to " + max + ":");
		String random_int;
		String OrderStatus;
		if (DeliveryMethod.equals("NotCompleted")) {
			random_int = "";
			OrderStatus = "NotCompleted";
		} else if (!DeliveryMethod.equals("PickUp")) {
			random_int = ((Double) Math.floor(Math.random() * (max - min + 1) + min)).toString().substring(0, 2);
			random_int += " Minutes";
			OrderStatus = "Ready For Dispatch";
		} else {
			random_int = "";
			OrderStatus = "Ready To Pickup";
		}

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

		String datetimeNOW = LocalDateTime.now().format(dtf);

		String Query = "Insert into orders values(null," + Double.parseDouble(price) + ",'" + random_int + "','"
				+ datetimeNOW + "','" + OrderStatus + "'," + Integer.parseInt(CostumerID) + ",0.0,'" + DeliveryMethod
				+ "','" + paymentMethod + "'" + ",'" + machineid + "','" + code + "'" + ")";
		this.SelectEditQuery(Query);
		return true;
	}

	/**
	 * InsertNewOrderDeliveryAddress method is used to insert a new delivery address
	 * into the database
	 * 
	 * @param FN     First name
	 * @param LN     Last name
	 * @param PN     Phone number
	 * @param HN     House number
	 * @param street street name
	 * @param area   area name
	 * @return boolean indicating the success of the insertion
	 */
	public boolean InsertNewOrderDeliveryAddress(String FN, String LN, String PN, String HN, String street,
			String area) {
		String Query = "SELECT OrderID AS LastOrderID FROM orders WHERE OrderID = @@Identity";
		try {
			PreparedStatement pstmt = conn.prepareStatement(Query);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			int orderid = rs.getInt(1);
			Query = "Insert into deliveries values(null," + orderid + ",'" + FN + "','" + LN + "','" + PN + "','" + HN
					+ "','" + street + "', '" + area + "');";
			this.SelectEditQuery(Query);
			return true;
		} catch (SQLException e) {
			System.out.println("error in InsertNewOrderDeliveryAddress");
			e.printStackTrace();
		}

		return false;
	}
	
	
	/**
	 * function to update the arrive time for the last order
	 * @param ArriveTime time for order to arrive
	 * @return if the query done successfully
	 */
	public boolean UpdateToTheRightArrivalTime(Integer ArriveTime)
	{
		try {
			// adding minutes string to the arrive time
			String ArriveTimee = ArriveTime + " Minutes";
			String Query = "update orders set TimeToArrive='"+ArriveTimee+"' where OrderID="+orderid+";";
			this.SelectEditQuery(Query);
			return true;
		} catch (Exception e) {
			System.out.println("error in UpdateToTheRightArrivalTime");
			e.printStackTrace();
		}

		return false;
	}
	/**
	 * This method returns a Boolean value indicating whether a stock report with
	 * the given information exists in the database.
	 * 
	 * @param reportInfo An ArrayList of Strings that contains the following
	 *                   information: month, area and location of the stock report.
	 * @return A Boolean value indicating whether a stock report with the given
	 *         information exists in the database.
	 */
	public Boolean CheckStockReports(ArrayList<String> reportInfo) {

		try {
			String Query = "select count(*) from monthlystockreport" + " where Month=? and Area=? and Location=?; ";
			PreparedStatement ps = conn.prepareStatement(Query);
			System.out.println("reportInfo=" + reportInfo);
			ps.setString(1, reportInfo.get(0));
			ps.setString(2, reportInfo.get(1));
			ps.setString(3, reportInfo.get(2));
			ResultSet rs = ps.executeQuery();
			rs.next();
			System.out.println("resultset=" + rs);
			System.out.println("first column=" + rs.getInt(1));
			if (rs.getInt(1) == 1)
				return true;
			else
				return false;

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return false;
	}

	/**
	 * CheckOrdersReports checks if the given reportInfo exists in the
	 * monthlyordersreport table.
	 * 
	 * @param reportInfo the reportInfo to check
	 * @return true if the reportInfo exists in the monthlyordersreport table, false
	 *         otherwise
	 */
	public Boolean CheckOrdersReports(ArrayList<String> reportInfo) {
		try {
			String Query = "select count(*) from monthlyordersreport" + " where Month=? and Area=? and Location=?; ";
			PreparedStatement ps = conn.prepareStatement(Query);
			System.out.println("reportInfo=" + reportInfo);
			ps.setString(1, reportInfo.get(0));
			ps.setString(2, reportInfo.get(1));
			ps.setString(3, reportInfo.get(2));
			ResultSet rs = ps.executeQuery();
			rs.next();
			System.out.println("resultset=" + rs);
			System.out.println("first column=" + rs.getInt(1));
			if (rs.getInt(1) >= 1)
				return true;
			else
				return false;

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return false;
	}

	/**
	 * CheckCustomersReports checks if the given reportInfo exists in the
	 * monthlycustomersreport table.
	 * 
	 * @param reportInfo the reportInfo to check
	 * @return true if the reportInfo exists in the monthlycustomersreport table,
	 *         false otherwise
	 */
	public Boolean CheckCustomersReports(ArrayList<String> reportInfo) {
		try {
			String Query = "select count(*) from monthlycustomersreport" + " where Month=? and Area=?; ";
			PreparedStatement ps = conn.prepareStatement(Query);
			System.out.println("reportInfo=" + reportInfo);
			ps.setString(1, reportInfo.get(0));
			ps.setString(2, reportInfo.get(1));
			ResultSet rs = ps.executeQuery();
			rs.next();
			System.out.println("resultset=" + rs);
			System.out.println("first column=" + rs.getInt(1));
			if (rs.getInt(1) == 1)
				return true;
			else
				return false;

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return false;
	}

	/**
	 * Update the low level of a machine.
	 *
	 * @param LowLevel The new low level for the machine.
	 * @param Area     The area of the machine that needs to be updated.
	 * @return A boolean value indicating if the update was successful.
	 */
	public boolean UpdateLowLevel(String LowLevel,String Area)
	{
		this.SelectEditQuery("SET SQL_SAFE_UPDATES=0;");
		this.SelectEditQuery("update machines set LowLevel="+LowLevel+" where Area='"+Area+"';" );
		return true;
	}

	/**
	*Updates the status of a product to "OnSale" and sets the sale percentage in a specific machine in a specific area.
	*@param productID The ID of the product to update.
	*@param Area The area where the machine is located.
	*@param Percentage The percentage of sale for the product.
	 */
	public void UpdateProductStatusTo_OnSale_AndSetPercentage(String productID,String Area,String Percentage) {
		this.SelectEditQuery("update products_in_machine "
						   + "natural join machines set SaleStatus=\"OnSale\",SalePercentage=\""+Percentage+"\" "  
						   + "where pId="+productID+" and Area=\""+Area+"\";");
	}
	
	/**
	 * Update the product status in machine
	 *
	 * @param productID the product ID
	 * @param Area The area where the machine is located.
	 */
	public void UpdateProductMachineStatusTo_NormalPrice(String productID,String Area) {
		this.SelectEditQuery("update products_in_machine "
				   + "natural join machines set SaleStatus=\"Normal Price\" "
				   + "where pId="+productID+" and Area= '"+Area+"' ;");
		this.SelectEditQuery("update products_in_machine "
				   + "natural join machines set SalePercentage="+null
				   + " where pId="+productID+" and Area= '"+Area+"' ;");
	}

	/**
	 * Update a sale request status to Cancelled
	 *
	 * @param requestid the request id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateSaleRequest_SetCancelled(int requestid) {
		this.SelectEditQuery("Update salerequest set RequestStatus='Cancelled' where RequestID=" + requestid + ";");
		return true;
	}
     
	 /**
     * function to check if the quantity of any product is 0 change the status to not available
     */
    synchronized public void CheckQuantities_ChangeStatus_ToNotAvailable()
    {
    	this.SelectEditQuery("SET SQL_SAFE_UPDATES=0;");
    	this.SelectEditQuery("update products_in_machine set AvailablityStatus=\"Not_Available\" where Quantity=0; ");
    }
    
    /**
     * function to check if the quantity of any product is 0 change the status to not available
     */
    synchronized public void CheckQuantities_ChangeStatus_ToAvailable()
    {
    	this.SelectEditQuery("SET SQL_SAFE_UPDATES=0;");
    	this.SelectEditQuery("update products_in_machine set AvailablityStatus=\"Available\" where Quantity>0; ");
    }
    
	/**
	 * Update a sale request status to Applyed
	 *
	 * @param requestid the request id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateSaleRequest_SetApplyed(int requestid) {
		this.SelectEditQuery("Update salerequest set RequestStatus='Applyed' where RequestID=" + requestid + ";");
		return true;
	}

	/**
	 * Update an order status to Approved
	 *
	 * @param orderid the order id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateOrderStatusTo_SetApproved(int orderid) {
		this.SelectEditQuery("Update orders set orderStatus='Delivery Approved' where orderID=" + orderid + ";");
		return true;
	}
	
	/**
	 * Update an order status to confirmed
	 *
	 * @param orderid the order id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateOrderStatusTo_SetConfirmed(int orderid) {
		this.SelectEditQuery("Update orders set orderStatus='Confirmed' where orderID=" + orderid + ";");
		return true;
	}

	/**
	 * Update an order status to Refunded
	 *
	 * @param orderid    the order id
	 * @param totalPrice the total price of the order
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateOrderStatusTo_SetRefunded(int orderid, double totalPrice) {
		this.SelectEditQuery(
				"Update orders set orderStatus='Refunded',refund=" + totalPrice + " where orderID=" + orderid + ";");
		return true;
	}

	/**
	 * Update an order status to Cancelled 
	 *
	 * @param orderid the order id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateOrderStatus_SetCanceled(int orderid) {
		int machineId;
		int pid;
		int quantity;
		ArrayList<ArrayList<Object>> AllTable = new ArrayList<ArrayList<Object>>();
		this.SelectEditQuery("Update orders set orderStatus='Cancelled' where orderID=" + orderid + ";");
		 
		String Query = "select pId,quantity,MachineID from orders natural join products_in_order where OrderID = "+orderid+";";
		 AllTable = GetAllTableData(3,Query);
		 this.SelectEditQuery("Update products_in_order set quantity= "+0+" where orderID=" + orderid + ";");
		 
		 for(int i =0;i<AllTable.size();i++) {
			 machineId = (Integer) AllTable.get(i).get(2);
			 pid =  (Integer) AllTable.get(0).get(0);
			 quantity =  (Integer) AllTable.get(i).get(1);
			 this.SelectEditQuery("Update products_in_machine set Quantity= Quantity + "+quantity +" where MachineID=" + machineId +
					 " and pId="+pid+ " ;");
		 }
		return true;
	}

	/**
	 * Update a customer registration status to Approved
	 *
	 * @param registirationid the registration id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateCustomerRegistirationStatus_SetApproved(int registirationid) {
		this.SelectEditQuery("Update customer_registirations set RegistirationStatus='Approved' where RID=" + "'"
				+ registirationid + "'");
		return true;
	}
	
	/**
	 * update the restock status column to sent
	 * @param machineid machine id
	 * @param pid product id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateRestockRequestStatus_ToSent(int machineid,int pid) {
		this.SelectEditQuery("Update products_in_machine set RestockRequestStatus='Sent' "
				+ "where pId="+pid+" and MachineID="+machineid+";" );
		return true;
	}
	
	/**
	 * update the restock status column to no request
	 * @param machineid machine id
	 * @param pid product id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateRestockRequestStatus_ToNoRequest(int machineid,int pid) {
		this.SelectEditQuery("Update products_in_machine set RestockRequestStatus='No Request' "
				+ "where pId="+pid+" and MachineID="+machineid+";" );
		return true;
	}

	/**
	 * Update a customer registration status to Not Approved
	 *
	 * @param registirationid the registration id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateCustomerRegistirationStatus_SetNotApproved(int registirationid) {
		this.SelectEditQuery("Update customer_registirations set RegistirationStatus='Not Approved' where RID=" + "'"
				+ registirationid + "'");
		return true;
	}

	/**
	 * Update a worker registration status to Approved
	 *
	 * @param registirationid the registration id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateWorkerRegistirationStatus_SetApproved(int registirationid) {
		this.SelectEditQuery("Update worker_registirations set RegistirationStatus='Approved' where WID=" + "'"
				+ registirationid + "'");
		return true;
	}

	/**
	 * Update a worker registration status to Not Approved
	 *
	 * @param registirationid the registration id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateWorkerRegistirationStatus_SetNotApproved(int registirationid) {
		this.SelectEditQuery("Update worker_registirations set RegistirationStatus='Not Approved' where WID=" + "'"
				+ registirationid + "'");
		return true;
	}

	/**
	 * Update a user's login status to 0
	 *
	 * @param userid the user id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateUser_isLoggedin_SetZero(int userid) {
		this.SelectEditQuery("Update users set isLoggedin=0 where userid=" + "'" + userid + "'");
		return true;
	}

	/**
	 * Update a user's login status to 1
	 *
	 * @param userid the user id
	 * @return A boolean value indicating if the update was successful
	 */
	public boolean UpdateUser_isLoggedin_SetOne(int userid) {
		this.SelectEditQuery("Update users set isLoggedin=1 where userid=" + "'" + userid + "'");
		return true;
	}

	/**
	 * Check login credentials.
	 *
	 * @param TableName the table name
	 * @param username  the user name
	 * @param password  the user's password
	 * @param c1        the column number for the user name
	 * @param c2        the column number for the password
	 * @return ArrayList of Object that contains the login status, and other details
	 *         about the user if the credentials are correct, otherwise it returns
	 *         "false" and "null" in the ArrayList
	 */
	public ArrayList<Object> CheckLogin(String TableName, String username, String password, int c1, int c2) {
		ArrayList<Object> arr = new ArrayList<Object>();
		try {
			String Query = "";
			Query += "select * from ";
			Query += TableName;
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = stmt.executeQuery(Query);
			while (rs.next())
				if (rs.getString(c1).equals(username) && rs.getString(c2).equals(password)) {
					arr.add("true");
					arr.add(rs.getString(10));
					arr.add(rs.getString(1));
					arr.add(rs.getString(5));
					arr.add(rs.getString(11));
					arr.add(rs.getString(12));
					arr.add(rs.getString(13));
					arr.add(rs.getString(8));
					arr.add(rs.getString(9));
					return arr;
				}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		arr.add("false");
		arr.add(null);
		return arr;
	}

	/**
	 * Check if a specific ID exists in the specified table.
	 *
	 * @param TableName the table name
	 * @param id        the id to be searched for
	 * @param cn        the column number for the id in the table
	 * @return true if the id exists in the table, false otherwise
	 */
	public Boolean CheckID(String TableName, String id, int cn) {
		try {
			String Query = "";
			Query += "select * from ";
			Query += TableName;
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = stmt.executeQuery(Query);
			while (rs.next())
				if (rs.getString(cn).equals(id)) {
					return true;
				}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	/**
	 * Inserts data into a specified table.
	 *
	 * @param arr       the array of data to be inserted
	 * @param TableName the table name
	 */
	public void InsertToTable(ArrayList<? extends Object> arr, String TableName) {
		try {
			String SqlCommand = "insert into ";
			SqlCommand += TableName + " values";
			SqlCommand += "(";
			for (int i = 0; i < arr.size(); i++) {
				if (i == arr.size() - 1)
					SqlCommand += "?";
				else
					SqlCommand += "?,";
			}
			SqlCommand += ");";
			PreparedStatement updatetable = conn.prepareStatement(SqlCommand);
			for (int i = 0; i < arr.size(); i++)
				updatetable.setObject(i + 1, arr.get(i));
			updatetable.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Retrieves all data from a specified table.
	 *
	 * @param TableName the table name
	 * @param size      the number of columns in the table
	 * @return a list of lists containing the data of the table
	 */
	public ArrayList<ArrayList<Object>> GetAllTableData(String TableName, int size) {
		try {
			String Query = "";
			Query += "select * from ";
			Query += TableName;
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = stmt.executeQuery(Query);
			ArrayList<ArrayList<Object>> AllTable = new ArrayList<ArrayList<Object>>();
			int j = 0;
			while (rs.next()) {
				AllTable.add(new ArrayList<Object>());
				for (int i = 0; i < size; i++)
					AllTable.get(j).add(rs.getObject(i + 1));
				j++;
			}
			return AllTable;
		} catch (SQLException e) {
			System.out.println("error in DBController get AllTableData");
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 
	 * The GetAllTableData method retrieves all the data from a table according to a
	 * SELECT query.
	 * 
	 * @param size        The number of columns of the table
	 * @param SelectQuery SELECT query that will be used to fetch the data from the
	 *                    table
	 * @return An ArrayList of ArrayLists of Objects that contains the data of the
	 *         table
	 */
	public ArrayList<ArrayList<Object>> GetAllTableData(int size, String SelectQuery) {

		try {
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = stmt.executeQuery(SelectQuery);
			// Saving all db data retrived from database
			ArrayList<ArrayList<Object>> AllTable = new ArrayList<ArrayList<Object>>();
			int j = 0;
			while (rs.next()) {
				AllTable.add(new ArrayList<Object>());
				for (int i = 0; i < size; i++)
					AllTable.get(j).add(rs.getObject(i + 1));
				j++;
			}

			// Showing Data on console
			int rc = 0;
			for (ArrayList<Object> ao : AllTable)
				System.out.format("row %d : %s \n", ++rc, ao);

			return AllTable;

		} catch (SQLException e) {
			System.out.println("error in DBController get AllTableData");
			e.printStackTrace();
		}
		return null;

	}

	/**
	 * 
	 * The ShowWholeTable function retrieves all data from the specified table and
	 * prints it to the console.
	 * 
	 * @param TableName the name of the table whose data needs to be retrieved.
	 * @param size      the number of columns in the table.
	 */
	public void ShowWholeTable(String TableName, int size) {
		System.out.println("hehe");
		try {
			System.out.println("im here");
			String Query = "";
			Query += "select * from ";
			Query += TableName;
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = stmt.executeQuery(Query);
			// Saving all db data retrived from database
			ArrayList<ArrayList<Object>> AllTable = new ArrayList<ArrayList<Object>>();
			int j = 0;
			while (rs.next()) {
				AllTable.add(new ArrayList<Object>());
				for (int i = 0; i < size; i++)
					AllTable.get(j).add(rs.getObject(i + 1));
				j++;
			}
			// Showing Data on console
			int rc = 0;
			for (ArrayList<Object> ao : AllTable)
				System.out.format("row %d : %s \n", ++rc, ao);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * 
	 * ShowTableRowUsingKey This method will take a table name, column name, key
	 * value, and size of the table as an input, and it will query the table with
	 * the provided key column name and key value and return the resulted row, it
	 * will print the data on console.
	 * 
	 * @param keyName   Column name used as a key to filter data
	 * @param key       value to filter data
	 * @param TableName the name of the table to be queried
	 * @param size      the number of columns in the table
	 */
	public void ShowTableRowUsingKey(String keyName, String key, String TableName, int size) {
		try {
			String Query = "";
			Query += "select * from ";
			Query += TableName;
			Query += " where ";
			Query += keyName;
			Query += "=" + "'" + key + "'";
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(Query);
			ArrayList<ArrayList<Object>> AllTable = new ArrayList<ArrayList<Object>>();
			int j = 0;
			while (rs.next()) {
				AllTable.add(new ArrayList<Object>());
				for (int i = 0; i < size; i++)
					AllTable.get(j).add(rs.getObject(i + 1));
				j++;
			}

			// Showing Data on console
			int rc = 0;
			for (ArrayList<Object> ao : AllTable)
				System.out.format("row %d : %s \n", ++rc, ao);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * The method EditTableRow allows you to update a certain value of a certain
	 * column in a table based on a specific condition.
	 * 
	 * @param ColumnName name of the column you want to update the value of.
	 * @param ToReplace  the new value you want to replace the current value with.
	 * @param Condition  the condition on which the value will be updated, it should
	 *                   be in the form of 'columnName = columnValue'.
	 * @param TableName  name of the table you want to update.
	 * @param size       number of columns in the table.
	 */
	public void EditTableRow(String ColumnName, String ToReplace, String Condition, String TableName, int size) {
		try {
			String Query = "update ";
			Query += TableName;
			Query += " set ";
			Query += ColumnName;
			Query += "=" + "'" + ToReplace + "'";
			Query += " where";
			Query += " " + Condition + ";";
			System.out.println(Query);
			PreparedStatement pstmt = conn.prepareStatement(Query);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * This method allows to delete a table in the database.
	 * 
	 * @param TableName: The name of the table that you want to delete
	 */
	public void DeleteTable(String TableName) {
		try {
			String Query = "Drop Table ";
			Query += TableName;
			PreparedStatement pstmt = conn.prepareStatement(Query);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 *
	 * 
	 * This method is used to execute a SELECT statement and display the results on
	 * the console. The query to be executed should be passed as the first
	 * parameter, and the number of columns in the returned result set should be
	 * passed as the second parameter. The results are stored in an ArrayList of
	 * ArrayLists and the values are printed on the console.
	 * 
	 * @param Query - The SELECT statement to be executed
	 * @param ts    - the number of columns in the result set
	 */
	public void SelectViewQuery(String Query, int ts) {
		try {
			PreparedStatement pstmt = conn.prepareStatement(Query);
			ResultSet rs = pstmt.executeQuery();
			ArrayList<ArrayList<Object>> AllTable = new ArrayList<ArrayList<Object>>();
			int j = 0;
			while (rs.next()) {
				AllTable.add(new ArrayList<Object>());
				for (int i = 0; i < ts; i++)
					AllTable.get(j).add(rs.getObject(i + 1));
				j++;
			}
			// Showing Data on console
			int rc = 0;
			for (ArrayList<Object> ao : AllTable)
				System.out.format("row %d : %s \n", ++rc, ao);

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/**
	 * 
	 * Runs the given query and performs the update operation on the data.
	 * 
	 * @param Query The update query string to be executed
	 */
	synchronized public void SelectEditQuery(String Query) {

		try {
			PreparedStatement pstmt = conn.prepareStatement(Query);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}


	/**
	 * Returns the number of columns of a table in the database
	 * @param TableName the name of the table
	 * @return the number of columns in the table
	 */
	public int GetTableColumnsNumber(String TableName) {
		try {
			// Getting Table Size using query
			String ColumnsNumberQuery = "SELECT count(*)\r\n" + "FROM information_schema.columns\r\n"
					+ "WHERE table_name = " + "'" + TableName + "'" + ";";
			PreparedStatement stmtsize = conn.prepareStatement(ColumnsNumberQuery);
			ResultSet rssize = stmtsize.executeQuery();
			rssize.next();
			int TableSize = rssize.getInt(1);
			System.out.println(TableSize);
			return TableSize;
		} catch (SQLException e) {

			e.printStackTrace();
			return 0;
		}
	}

	/**
	 * 
	 * Returns the number of columns in the table specified by TableName.
	 * 
	 * @param TableName the name of the table to get the number of columns of.
	 * @return an int representing the number of columns in the table.
	 */
	public int GetTableRowsNumber(String TableName) {
		try {
			// Getting Table Size using query
			String RowsNumberQuery = "SELECT COUNT(*) FROM " + TableName + ";";
			PreparedStatement stmtsize = conn.prepareStatement(RowsNumberQuery);
			ResultSet rssize = stmtsize.executeQuery();
			rssize.next();
			int TableSize = rssize.getInt(1);
			System.out.println(TableSize);
			return TableSize;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}

	/**
	 * 
	 * Get the primary key name of the specified table.
	 * 
	 * @param TableName name of the table to retrieve the primary key name from
	 * @return the primary key name of the specified table
	 */
	public String GetTablePrimaryKeyName(String TableName) {
		try {
			// Getting Table Size using query
			String RowsNumberQuery = "SHOW KEYS FROM " + TableName + " WHERE Key_name = 'PRIMARY'; ";
			PreparedStatement stmtsize = conn.prepareStatement(RowsNumberQuery);
			ResultSet rssize = stmtsize.executeQuery();
			rssize.next();
			String KeyName = rssize.getString(5);
			System.out.println(KeyName);
			return KeyName;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Get the names of the primary keys of a table
	 * @param TableName the name of the table to get the primary keys from
	 * @return an ArrayList of strings containing the names of the primary keys of the table or null if an error occurred
	 */
	public ArrayList<String> GetTablePrimaryKeysNames(String TableName) {
		try {
			// Getting Table Size using query
			String RowsNumberQuery = "SHOW KEYS FROM " + TableName + " WHERE Key_name = 'PRIMARY'; ";
			PreparedStatement stmtsize = conn.prepareStatement(RowsNumberQuery);
			ResultSet rs = stmtsize.executeQuery();
			ArrayList<String> pkeys = new ArrayList<String>();
			while (rs.next())
				pkeys.add(rs.getString(5));
			System.out.println(pkeys);
			return pkeys;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 
	 * Adds a product to an existing order.
	 * 
	 * @param orderNumber The number of the order.
	 * @param pId         The id of the product to be added to the order.
	 * @param quantity    The quantity of the product to be added to the order.
	 * @return An ArrayList containing a boolean indicating whether the product was
	 *         added successfully.
	 */
	public ArrayList<String> AddProductToOrder(int orderNumber, int pId, int quantity) {
		ArrayList<String> arr = new ArrayList<String>();
		try {

			String Query = "insert into products_in_order values (?,?,?) ";
			System.out.println("the current query is : " + Query);
			PreparedStatement pstmt = conn.prepareStatement(Query);
			pstmt.setInt(1, orderNumber);
			pstmt.setInt(2, pId);
			pstmt.setInt(3, quantity);
			pstmt.execute();
			arr.add("true");
		} catch (Exception e) {
			System.out.println("sorry couldn't add the item");
			arr.add("false");
		}
		return arr;
	}

	/**
	 * 
	 * Method that decreases the quantity of a set of products based on their id.
	 * 
	 * @param id       A list of product id's that need to have their quantity
	 *                 decreased
	 * @param quantity A list of quantity values for the corresponding product id's
	 * @return boolean returns true if the update is successful, false otherwise.
	 */
	public boolean DecreaseQuantityForProducts(ArrayList<String> id, ArrayList<String> quantity) {
		String Query = "SELECT OrderID AS LastOrderID FROM orders WHERE OrderID = @@Identity";
		for (int i = 0; i < id.size(); i++) {
			this.SelectEditQuery(
					"update product set pQuantity=pQuantity-" + quantity.get(i) + " where pId=" + id.get(i) + ";");
		}

		return true;

	}
    /**
     * to save the last orderid after inserting new order
     */
    private int orderid;
	/**
	 *
	 * 
	 * Decreases quantity for specific products in machines
	 * 
	 * @param id       a list of product's ID
	 * @param quantity a list of quantity that should be decreased from the
	 *                 products_in_machine table.
	 * @return boolean, true if the process is done successfully.
	 */
	public boolean DecreaseQuantityForProducts_in_machines(ArrayList<String> id, ArrayList<String> quantity) {
		String Query = "SELECT OrderID AS LastOrderID FROM orders WHERE OrderID = @@Identity";
		try {
			PreparedStatement pstmt = conn.prepareStatement(Query);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			orderid = rs.getInt(1);
			System.out.println("orderid*****************************=" + orderid);
			System.out.println("array size in function :" + id.size());
			String MachineIDQuery = "select MachineID from orders where OrderID=" + orderid + ";";
			PreparedStatement pstmt1 = conn.prepareStatement(MachineIDQuery);
			ResultSet rs1 = pstmt1.executeQuery();
			rs1.next();
			int MachineID = rs1.getInt(1);
			for (int i = 0; i < id.size(); i++) {
				this.SelectEditQuery("update products_in_machine set Quantity=Quantity-" + quantity.get(i)
						+ " where MachineID=" + MachineID + " and pId=" + id.get(i) + ";");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;

	}
	
	
	/**
	 * 
	 * Increase the quantity of products in stock after a purchase
	 * @param OrderID the order id of the purchase
	 * @return true if the update was successful, false otherwise
	 */
	public boolean IncreaseQuantityForProducts(Integer OrderID) {
        this.SelectEditQuery("update orders natural join products_in_order natural join product "
        					+ "set pQuantity=pQuantity+quantity "
        					+ "where OrderID="+OrderID+";");
		return true;

	}
	    
	
	
		/**
		 * Function to import data from an external database
		 */
		public void importUsers() {
			try {
				Connection connExternal = DriverManager
						.getConnection("jdbc:mysql://localhost/external?serverTimezone=IST&useSSL=false", "root" , "Aa123456");
				Statement statementExt = connExternal.createStatement();
				ArrayList<User> usersExternal = new ArrayList<>();
				ResultSet rs = statementExt.executeQuery("SELECT * FROM external.users");
				while (rs.next()) {
					User u=new User(rs.getInt("UserID"), rs.getString("IDNumber"), rs.getString("Username"),
							rs.getString("Password"), rs.getString("FirstName"), rs.getString("LastName"), rs.getString("HomeArea")
							,rs.getString("Email"),rs.getString("PhoneNumber"),rs.getString("type"),rs.getString("Area"),rs.getInt("isLoggedin"),
							rs.getInt("costumerID"));
					usersExternal.add(u);
				}
				statementExt.close();
				connExternal.close();
				int linesAffected = 0;
				for (User user : usersExternal) {
					PreparedStatement ps = conn.prepareStatement(
							"INSERT INTO ekrut.users "
									+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)"
									+ " ON DUPLICATE KEY UPDATE IDNumber=?,Username=?,Password=?,FirstName=?,LastName=?,HomeArea=?,Email=?,PhoneNumber=?,type=?"
									+ ",Area=?,isLoggedin=?,costumerID=?");
					
					ps.setInt(1, user.getUserID());
					ps.setString(2, user.getIDNumber());
					ps.setString(3, user.getUserName());
					ps.setString(4, user.getPassword());
					ps.setString(5, user.getFirstName());
					ps.setString(6, user.getLastName());
					ps.setString(7, user.getHomeArea());
					ps.setString(8, user.getEmail());
					ps.setString(9, user.getPhoneNumber());
					ps.setString(10, user.getType());
					ps.setString(11, user.getArea());
					ps.setInt(12, user.getIsLoggedin());
					ps.setInt(13, user.getCostumerID());

					
					ps.setString(14,user.getIDNumber());
					ps.setString(15, user.getUserName());
					ps.setString(16, user.getPassword());
					ps.setString(17, user.getFirstName());
					ps.setString(18, user.getLastName());
					ps.setString(19, user.getHomeArea());
					ps.setString(20, user.getEmail());
					ps.setString(21, user.getPhoneNumber());
					ps.setString(22, user.getType());
					ps.setString(23, user.getArea());
					ps.setInt(24, user.getIsLoggedin());
					ps.setInt(25, user.getCostumerID());

					linesAffected = ps.executeUpdate();
					if (linesAffected == 0)
						ServerController.cp.addMessage( "Failed to insert user to database: " + user.toString());
					ps.close();
					ServerController.cp.addMessage("Importing users from external schema done successfully");
				}

			} catch (SQLException e) {
				ServerController.cp.addMessage( e.getMessage());
				e.printStackTrace();
			}

		}


}
