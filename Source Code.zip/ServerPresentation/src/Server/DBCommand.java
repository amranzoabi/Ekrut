package Server;

/**
 * Enumeration of commands that can be issued to a database.
 * 
 * @author Shadi
 *
 */
public enum DBCommand {
	/** Save a customer to the database. */
	SaveCustomer,
	/** Delete a customer from the database. */
	DeleteCustomer,
	/** Edit a customer's information in the database. */
	EditCustomer,
	/** Save a product in the system to the database. */
	SaveProductInSystem,
	/** Delete a product from the system in the database. */
	DeleteProductInSystem,
	/** Edit a product in the system in the database. */
	EditProductInSystem,
	/** Add a product to a customer's cart. */
	AddProductToCart,
	/** Remove a product from a customer's cart. */
	RemoveProductInCart,
	/** Edit a product in a customer's cart. */
	EditProductInCart,
	/** Approve a delivery. */
	ApproveDelivery,
	/** Deny a delivery. */
	DenyDelivery,
	/** Show orders report. */
	ShowOrdersReport;
	;
}