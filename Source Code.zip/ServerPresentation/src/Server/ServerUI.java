package Server;

import javafx.application.Application;
import javafx.stage.Stage;
import application.ServerController;

/**
 * This class represents the UI of the server application. It creates a new
 * server instance that listens for client connections.
 * 
 * @author Shadi
 * @author Mahran
 *
 */
public class ServerUI extends Application {
	/**
	 * final for default port
	 */
	final public static int DEFAULT_PORT = 5555;
	/**
	 * EchoServer instance
	 */
	public static EchoServer sv;

	/**
	 * The start method initializes the primary stage of the server's UI.
	 *
	 * @param primaryStage the primary stage of the server's UI
	 * @throws Exception if an error occurs while initializing the stage
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {

		ServerController aFrame = new ServerController(); // create StudentFrame
		aFrame.start(primaryStage);

	}

	/**
	 * Start the server
	 * 
	 * @param p port number that server should listen to.
	 */
	public static void runServer(String p) {
		DeleteTimer timer = new DeleteTimer();

		int port = 0; // Port to listen on

		try {
			port = Integer.parseInt(p); // Set port to 5555
		} catch (Throwable t) {
			System.out.println("ERROR - Could not connect!");
		}

		sv = new EchoServer(port);

		try {
			sv.listen(); // Start listening for connections
			timer.start();
		} catch (Exception ex) {
			System.out.println("ERROR - Could not listen for clients!");
		}

	}

	/**
	 * main method
	 * @param args the arguments
	 * @throws Exception throws exception
	 */
	public static void main(String args[]) throws Exception {
		launch(args);
	} // end main

}
