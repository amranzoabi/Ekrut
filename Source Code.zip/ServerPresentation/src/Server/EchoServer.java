// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 
package Server;

import java.io.IOException;
import java.util.ArrayList;

import application.ServerController;
import common.Commands;
import common.Message;
import javafx.collections.FXCollections;
import ocsf.server.AbstractServer;
import ocsf.server.ConnectionToClient;

/**
 * This class overrides some of the methods in the abstract superclass in order
 * to give more functionality to the server.
 *
 * @author Shadi
 */

public class EchoServer extends AbstractServer {
	// Class variables *************************************************
	/**
	 * counter for messages
	 */
	int messagecounter = 1;
	/**
	 * to save the DB controller
	 */
	private static DBController db;
	/**
	 * to sav ethe host name
	 */
	private String hostname;

	/**
	 * The default port to listen on.
	 */
	// final public static int DEFAULT_PORT = 5555;

	// Constructors ****************************************************

	/**
	 * Constructs an instance of the echo server.
	 *
	 * @param port The port number to connect on.
	 * 
	 */

	public EchoServer(int port) {
		super(port);
	}

	// Instance methods ************************************************

	/**
	 * Check if the command is valid or not
	 * @param arr the array of elements
	 * @param Command the command you want to check
	 * @return true if the command is valid, false otherwise
	 */
	// checks first Element in Array
	public boolean CheckCommand(Object arr, String Command) {
		if (arr instanceof ArrayList<?>)
			if (((ArrayList<?>) arr).get(0).equals(Command)) {

				return true;
			}

		return false;
	}

	/**
	 * Handles a new client connection by updating the list of connected clients.
	 */
	@Override
	protected void clientConnected(ConnectionToClient client) {
		System.out.println("im at clientconnected method");
		UpdateClientConnections();
	}
     
	/**
	 * Array to save all the users currently logged in
	 */
	public ArrayList<Integer> ConnectedUsersIDs = new ArrayList<>();
	/**
	 * Handles a lost client connection by updating the list of connected clients.
	 */
     protected void MyclientDisconnected(ConnectionToClient client) {
		System.out.println("im at clientDisconnected method");
		try {
			client.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		UpdateClientConnections();
	}
     
     /**
     * function used when the server disconnects 
     */
    public void LogOutAllUsers()
     {
    	 for (int UserID : ConnectedUsersIDs) {
    		 DBController.getInstance().UpdateUser_isLoggedin_SetZero(UserID);
    	 }
    	 
    	 Message msg = new Message();
    	 msg.setCommand(Commands.ChangeClientScreenToLogin);
		 msg.setContents("Nothing");
		 this.sendToAllClients(msg);
     }
    
    /**
     * Disconnects all currently connected clients by closing their connections and calls 
     */
    public void DisconnectAllClients()
    {
		for (int i = 0; i < getClientConnections().length; i++) {
			try {
				((ConnectionToClient) getClientConnections()[i]).close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		UpdateClientConnections();
    }
     
     

	/**
	 * This method handles the messages from the clients, and performs the
	 * appropriate action based on the command in the message.
	 * 
	 * @param msg    the message object recieved from the client.
	 * @param client the client that sent the message.
	 */
	public void handleMessageFromClient(Object msg, ConnectionToClient client) {
		this.UpdateClientConnections();
		hostname = "localhost";
		System.out.println(client.getInetAddress());
		ArrayList<Object> arr = new ArrayList<Object>();
		System.out.println("i did enter to server");
		System.out.println("Message recieved at server :" + msg);

		if (msg instanceof Message) {
			// save the Message in variable to deal with it easier
			System.out.println("im here at Message");
			Message recieved = (Message) msg;
			recieved.setClient(client.toString());
			recieved.setMsgId(messagecounter++);
			ServerController.cp.addMessage(recieved.toString());
			System.out.println("full message :" + recieved);

			// start checking the command in message and do what supposed to be done
			String commandRecieved = recieved.getCommand();
			String[] arrcontents = { "Nothing" };
			if (recieved.getContents() instanceof String)
				arrcontents = ((String) recieved.getContents()).split("/");

			switch (commandRecieved) {
			
			case Commands.ClientConnect:
				ServerMethods.SendToClient(arrcontents, client, recieved);
				break;

			case Commands.Login:
				System.out.println(recieved);
				for (String s : arrcontents)
					System.out.println(s);
				System.out.println("arrcontents=" + arrcontents);
				arr.addAll(DBController.getInstance().CheckLogin("users", arrcontents[0].toString(),
						arrcontents[1].toString(), 3, 4));
				System.out.println("the array is:" + arr);
				if (arr.get(0).toString().equals("true")) // if the user information is correct 
				{
					DBController.getInstance().UpdateUser_isLoggedin_SetOne(Integer.parseInt((String) (arr.get(2)))); // get the user id and send it
					int IsLoggedIn=Integer.parseInt((String) (arr.get(5)));
					int UseerID = Integer.parseInt((String) (arr.get(2)));
					if (IsLoggedIn!=1) // check if the user already connected
						ConnectedUsersIDs.add(UseerID);
				}
				System.out.println(arr);
				ServerMethods.SendToClient(arr, client, recieved);
				break;

			case Commands.Logout:
				DBController.getInstance().UpdateUser_isLoggedin_SetZero((Integer) recieved.getContents());
				ServerMethods.SendToClient(arr, client, recieved);
				System.out.println("in logout");
				break;

			case Commands.ShowDBData:
				System.out.println("im here at showdbdata command hahahay");
				recieved.setContents(DBController.getInstance().GetAllTableData("Subscriber", 7).toString());
				System.out.println("arr:" + arr);
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.UpdateInfo:
				System.out.println("im here at update info command in Message");
				String Query = "update subscriber set creditcardnumber= '" + ((ArrayList) recieved.getContents()).get(1)
						+ "',subscribernumber= '" + ((ArrayList) recieved.getContents()).get(2) + "' where id=" + "'"
						+ ((ArrayList) recieved.getContents()).get(0) + "';";
				System.out.println("the query is ::: " + Query);
				System.out.println("doing the query");
				DBController.getInstance().SelectEditQuery(Query);
				System.out.println("done with the query");
				ServerMethods.SendToClient(client,"done updating");
				break;

			case Commands.Getallproducts:
				System.out.println("im here at getallproducts command hahahay");
				ArrayList<String> strarr = new ArrayList<String>();
				recieved.setContents(
						(ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData("product", 7));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.Getallorders:
				System.out.println("im here at getallorders command hahahay");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance()
						.GetAllTableData("orders natural join deliveries;", 18));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.getOrderFromMachine:
				System.out.println("im here at getallorders command hahahay");
				String Q = "select * from orders;";
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData(11, Q));
				// recieved.setContents((ArrayList<ArrayList<Object>>)
				// DBController.getInstance().GetAllTableData("orders;", 11));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.SaveSaleRequest:
				System.out.println("im here at Save sale request");
				ArrayList<String> temp = new ArrayList<String>();
				temp = (ArrayList<String>) recieved.getContents();
				System.out.println("print temp" + temp);
				DBController.getInstance().InsertToTable(temp, "salerequest");
				recieved.setContents("Saved Successfully");
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.Getallsalerequests:
				System.out.println("im here at getallrequests command hahahay");
				recieved.setContents(
						(ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData("salerequest", 6));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.Getallmonthlystockreports:
				System.out.println("im here at getallrordersreports command hahahay");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance()
						.GetAllTableData("monthlystockreport", 15));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;
			case Commands.Getallmonthlycostumersreports:
				System.out.println("im here at getallrordersreports command hahahay");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance()
						.GetAllTableData("MonthlyCustomersReport", 11));
				ServerMethods.SendToClient(client,recieved);
				break;
				
			case Commands.Getallmonthlyrorderseports:
				System.out.println("im here at getallrordersreports command hahahay");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance()
						.GetAllTableData("monthlyordersreport", 12));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;
			case Commands.RegisterNewCustomer:
				System.out.println("im at register new customer command");
				ArrayList<String> DataToInsertCustomer = new ArrayList<>();
				DataToInsertCustomer = (ArrayList<String>) recieved.getContents();
				DataToInsertCustomer.add(0, null); // add to the start for the primary key
				DataToInsertCustomer.add("Needs Review"); // add in the end for the status
				System.out.println("data to add" + DataToInsertCustomer);
				DBController.getInstance().InsertToTable(DataToInsertCustomer, "customer_registirations");
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.RegisterNewWorker:
				System.out.println("im at register new worker command");
				ArrayList<String> DataToInsertWorker = new ArrayList<>();
				DataToInsertWorker = (ArrayList<String>) recieved.getContents();
				DataToInsertWorker.add(0, null); // add to the start for the primary key
				DataToInsertWorker.add("Needs Review"); // add in the end for the status
				DBController.getInstance().InsertToTable(DataToInsertWorker, "worker_registirations");
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.GetAllCustomersRegistirations:
				System.out.println("im here at getallcustomerregistrations command");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance()
						.GetAllTableData("Customer_registirations", 11));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.GetAllWorkersRegistirations:
				System.out.println("im here at getallcustomerregistrations command");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance()
						.GetAllTableData("Worker_registirations", 12));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.UpdateCustomerRegistirationStatus: // update the status to approved
				DBController.getInstance()
						.UpdateCustomerRegistirationStatus_SetApproved((Integer) (recieved.getContents()));
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.UpdateCustomerRegistirationStatusToNotApproved: // update the status to not approved
				DBController.getInstance()
						.UpdateCustomerRegistirationStatus_SetNotApproved((Integer) (recieved.getContents()));
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.UpdateWorkerRegistirationStatus:
				DBController.getInstance()
						.UpdateWorkerRegistirationStatus_SetApproved((Integer) (recieved.getContents()));
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.AddNewCustomer:
				ArrayList<Object> DataToInsert = (ArrayList<Object>) (recieved.getContents());

				DBController.getInstance().insertNewUserAsCustomer(DataToInsert);
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.AddNewWorker:
				ArrayList<Object> DataToInsert1 = (ArrayList<Object>) (recieved.getContents());
				DataToInsert1.remove(0);
				DataToInsert1.remove(DataToInsert1.size() - 1);
				DataToInsert1.add(0, null); // send null to id because its auto increment
				DataToInsert1.add(6, (String) (DataToInsert1.get(10))); // put homearea constant haifa
				DataToInsert1.add(0);
				DataToInsert1.remove(7);
				DataToInsert1.add(null); ////// add null because no customer id for workers
				System.out.println("print the array before inserting : \n" + DataToInsert1);
				DBController.getInstance().InsertToTable(DataToInsert1, "users");
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.UpdateWorkerRegistirationStatusToNotApproved:
				DBController.getInstance()
						.UpdateWorkerRegistirationStatus_SetNotApproved((Integer) (recieved.getContents()));
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.GetAllMachinesJoinsProductsInsideThem:
				System.out.println("im here at getallmachinesandproducts command");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData(8,
						"select MachineID, Location, Area, LowLevel, pId, Quantity, SaleStatus,RestockRequestStatus"
					+   " from machines natural join products_in_machine;"));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.GetallproductsJoinsMachines:
				System.out.println("im here at productsjoinsmachines command");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData(14 ,
								  "select MachineID, pId, pName, pCategory, pPrice, pSpecification, pQuantity, ProductStatus, "
								+ "Quantity, SaleStatus, Location, Area, LowLevel,SalePercentage"
								+ " from product natural join products_in_machine natural join machines;"));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.UpdateProductInMachineQuantity:

				System.out.println("im here at updateproductinmachinequantity");
				ArrayList<Object> midpid = ((ArrayList) recieved.getContents());
				System.out.println("hey");
				int mid = (Integer) (midpid.get(0)); // machine id
				int pid = (Integer) (midpid.get(1)); // product id
				DBController.getInstance().SelectEditQuery(
						"update products_in_machine set Quantity=100 where pId=" + pid + " and MachineID=" + mid);
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.OrderDone:
				System.out.println("im at orderdone command");
				System.out.println("the contents are:" + recieved.getContents());
				ArrayList<Object> contents = (ArrayList<Object>) recieved.getContents();
				int productsize = (Integer) contents.get(0);
				String paymentmethod = (String) contents.get(1);
				String DeliveryMethod = (String) contents.get(2);
				String orderprice = (String) contents.get(3);
				String costumerID = (String) contents.get(4);
				ArrayList<String> productsids = new ArrayList<>();
				ArrayList<String> productsquantities = new ArrayList<>();
				for (int i = 5; i < (productsize * 2) + 5; i++) {
					if (i % 2 == 0)
						productsquantities.add(((String) contents.get(i)));
					else
						productsids.add((String) contents.get(i));
				}
				DBController.getInstance().InsertNewOrder(orderprice, paymentmethod, DeliveryMethod, costumerID);
				DBController.getInstance().InsertProductsIntoProducts_in_orders(productsids, productsquantities);
				ServerMethods.SendToClient(client,"Done inserting");
				break;

			case Commands.CancelOrder:
				ArrayList<Integer> orderarr = new ArrayList<Integer>();
				orderarr = (ArrayList<Integer>) recieved.getContents();
				int orderid = orderarr.get(0);
				DBController.getInstance().UpdateOrderStatus_SetCanceled(orderid);
				ServerMethods.SendToClient(client,"Done canceling the order");
				break;

			case Commands.ApproveOrderDelivery:
				ArrayList<String> orderarrr = new ArrayList<String>();
				orderarrr = (ArrayList<String>) recieved.getContents();
				int orderidd = Integer.parseInt(orderarrr.get(0) + "");
				DBController.getInstance().UpdateOrderStatusTo_SetApproved(orderidd);
				ServerMethods.SendToClient(client,"Done approving the order");
				break;

			case Commands.RefundOrderAfterDelivery:

				ArrayList<String> orderarr1 = new ArrayList<String>();
				orderarr1 = (ArrayList<String>) recieved.getContents();
				int orderid1 = Integer.parseInt(orderarr1.get(0) + "");
				double totalprice = Double.parseDouble(orderarr1.get(1) + "");
				DBController.getInstance().UpdateOrderStatusTo_SetRefunded(orderid1, totalprice);
				ServerMethods.SendToClient(client,"Done refunding the order");
				break;
				
			case Commands.GetCategoryProfitPerMonthTable:
				System.out.println("im here at getcategoryprofitpermonth command ");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance()
						.GetAllTableData("category_profit_permonth", 9));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.GetAllCustomers:
				System.out.println("im here at getallcustomers command ");
				recieved.setContents(
						(ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData("costumers", 9));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.GetAllUsers:
				System.out.println("im here at getallusers command ");
				recieved.setContents(
						(ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData("users", 13));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.GetNumberOfCustomers_Subscriber:
				System.out.println("im here at getcostumerssubscribersnumber command ");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData(2,
						"select cType , count(*) as \"Number Of Costumers\" " + "from costumers group by  cType;"));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.GetCategoryPercentagePerMonth:
				System.out.println("im here at getcategorypercentagepermonth command ");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance()
						.GetAllTableData("category_percentage_permonth", 9));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;
				
			case Commands.GetCostumersSubscribersNumberPerMonthTable:
				System.out.println("im here at getcostumerssubscribernumberpermonth command ");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance()
						.GetAllTableData("costumerssubscribers_number_permonth", 5));
				ServerMethods.SendToClient(client,recieved);
				break;
				

			case Commands.CheckStockReports:
				System.out.println("im here at checkstockreports command ");
				recieved.setContents(
						DBController.getInstance().CheckStockReports((ArrayList<String>) recieved.getContents()));
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.CheckOrdersReports:
				System.out.println("im here at check command ");
				recieved.setContents(
						DBController.getInstance().CheckOrdersReports((ArrayList<String>) recieved.getContents()));
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.CheckCustomerskReports:
				System.out.println("im here at check command ");
				recieved.setContents(
						DBController.getInstance().CheckCustomersReports((ArrayList<String>) recieved.getContents()));
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.GetUsersJoinsCostumers:
				System.out.println("im here at getusersjoinscustomers command");
				String ProduceCustomersReportQuery = "select FirstName,costumerID,count(*) as \"Number of orders\",cType"
						+ " from users natural join costumers natural join orders " + "group by costumerID;";
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData(4,
						ProduceCustomersReportQuery));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.InsertNewMonthlyCustomersReport:
				System.out.println("im at insertnewmonthlycustomer command");
				ArrayList<Object> DataToInsertCustomersReport = new ArrayList<>();
				DataToInsertCustomersReport = (ArrayList<Object>) recieved.getContents();
				DataToInsertCustomersReport.add(0, null);
				System.out.println("data to add" + DataToInsertCustomersReport);
				DBController.getInstance().InsertToTable(DataToInsertCustomersReport, "monthlycustomersreport");
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.InsertNewMonthlyOrdersReport:
				System.out.println("im at insertnewmonthlyorders command");
				ArrayList<Object> DataToInsertOrdersReport = new ArrayList<>();
				DataToInsertOrdersReport = (ArrayList<Object>) recieved.getContents();
				DataToInsertOrdersReport.add(0, null);
				System.out.println("data to add" + DataToInsertOrdersReport);
				DBController.getInstance().InsertToTable(DataToInsertOrdersReport, "monthlyordersreport");
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.InsertNewCategoryProfitReport:
				System.out.println("im at insertnewmonthlyordersreport command");
				ArrayList<Object> DataToInsertCategoryProfitReport = new ArrayList<>();
				DataToInsertCategoryProfitReport = (ArrayList<Object>) recieved.getContents();
				DataToInsertCategoryProfitReport.add(0, null);
				System.out.println("data to add" + DataToInsertCategoryProfitReport);
				DBController.getInstance().InsertToTable(DataToInsertCategoryProfitReport, "category_profit_permonth");
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.InsertNewMonthlyStockReport:
				System.out.println("im at insertmonthlystockreport command");
				ArrayList<Object> DataToInsertStockReport = new ArrayList<>();
				DataToInsertStockReport = (ArrayList<Object>) recieved.getContents();
				DataToInsertStockReport.add(0, null);
				System.out.println("data to add" + DataToInsertStockReport);
				DBController.getInstance().InsertToTable(DataToInsertStockReport, "monthlystockreport");
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.InsertNewCategoryPercentageReport:
				System.out.println("im at insertnewmonthlyordersreport command");
				ArrayList<Object> DataToInsertCategoryPercentageReport = new ArrayList<>();
				DataToInsertCategoryPercentageReport = (ArrayList<Object>) recieved.getContents();
				DataToInsertCategoryPercentageReport.add(0, null);
				System.out.println("data to add" + DataToInsertCategoryPercentageReport);
				DBController.getInstance().InsertToTable(DataToInsertCategoryPercentageReport,
						"category_percentage_permonth");
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.InsertNewCostumersNumberReport:
				System.out.println("im at insertnewcostumersnumbereport command");
				ArrayList<Object> DataToInsertCostumersNumberReport = new ArrayList<>();
				DataToInsertCostumersNumberReport = (ArrayList<Object>) recieved.getContents();
				DataToInsertCostumersNumberReport.add(0, null);
				System.out.println("data to add" + DataToInsertCostumersNumberReport);
				DBController.getInstance().InsertToTable(DataToInsertCostumersNumberReport,
						"costumerssubscribers_number_permonth");
				ServerMethods.SendToClient(client,recieved);
				break;
				
			case Commands.GetProduceReportsTableData:
				System.out.println("im here at getproductsreports command ");
				String Location = (String) ((ArrayList) recieved.getContents()).get(0);
				String Area = (String) ((ArrayList) recieved.getContents()).get(1);
				String QueryProduceOrdersReport = "select pName,pId,pCategory,sum(quantity) as \"Total Sales\",sum(quantity)*pPrice as \"Profit\" \n"
						+ "from product natural join products_in_order natural join orders natural join machines\n"
						+ "where Location=\"" + Location + "\" and Area='" + Area + "'" + "group by pId; ";
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData(5,
						QueryProduceOrdersReport));
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.GetProduceStockReportTableData:
				System.out.println("im here at getproductsreports command ");
				String Location1 = (String) ((ArrayList) recieved.getContents()).get(0);
				String Area1 = (String) ((ArrayList) recieved.getContents()).get(1);
				String QueryProduceStockReport = "select pCategory,sum(Quantity) as \"Stock Quantity\" from product natural join products_in_machine natural join machines\n"
						+ "				where Location=\"" + Location1 + "\" and Area=\"" + Area1 + "\"\n"
						+ "				group by pCategory;";
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData(2,
						QueryProduceStockReport));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.MakeSale:
				String Template = (String) (((ArrayList<Object>) recieved.getContents()).get(0));
				Integer RequestID = (Integer) (((ArrayList<Object>) recieved.getContents()).get(1));
				String ProductsIDs = (String) (((ArrayList<Object>) recieved.getContents()).get(2));
				String Areaa = (String) (((ArrayList<Object>) recieved.getContents()).get(4));
				String Percentage = (String) (((ArrayList<Object>) recieved.getContents()).get(5));
				DBController.getInstance().UpdateSaleRequest_SetApplyed(RequestID);
				String[] products = ProductsIDs.split(",");
				for (String Pid : products)
					DBController.getInstance().UpdateProductStatusTo_OnSale_AndSetPercentage(Pid, Areaa,Percentage);
				ServerMethods.SendToClient(client,recieved);
				break;
				
			case Commands.CancelAppliededSale:
				String ProductsID = (String) (((ArrayList<Object>) recieved.getContents()).get(2));
				String Areaaa = (String) (((ArrayList<Object>) recieved.getContents()).get(4));
				String[] product = ProductsID.split(",");
				for (String Pid : product)
					DBController.getInstance().UpdateProductMachineStatusTo_NormalPrice(Pid, Areaaa);
				ServerMethods.SendToClient(client,recieved);
				break;
				
			case Commands.InsertRestockRequest:
				System.out.println("im at insertrestockrequest command");
				ArrayList<Object> RestockDataToInsert = (ArrayList<Object>) recieved.getContents();
				RestockDataToInsert.add(0, null);
				System.out.println("data to add" + RestockDataToInsert);
				DBController.getInstance().InsertToTable(RestockDataToInsert, "restockrequests");
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.GetAllRestockRequests:
				System.out.println("im here at getallrestockrequests command");
				recieved.setContents((ArrayList<ArrayList<Object>>) DBController.getInstance()
						.GetAllTableData("restockrequests", 5));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.CancelSaleRequest:
				Integer RequestId = (Integer) recieved.getContents();
				DBController.getInstance().UpdateSaleRequest_SetCancelled(RequestId);
				ServerMethods.SendToClient(client,"Done canceling the order");
				break;

			case Commands.SetLowLevel:
				System.out.println("im at set low level command");
				ArrayList<String> DataRecieved = (ArrayList<String>) recieved.getContents();
				String LowLevel = DataRecieved.get(0);
				String AreaLowLevel = DataRecieved.get(1);
				DBController.getInstance().UpdateLowLevel(LowLevel, AreaLowLevel);
				ServerMethods.SendToClient(client,"Done updating the low level");
				break;

			case Commands.GetLowLevel:
				System.out.println("im here at getlowlevel command");
				String AreaGetLowLevel = (String) recieved.getContents();
				String GetLowLevelQuery = "select lowlevel from machines where Area='" + AreaGetLowLevel + "' "
						+ "limit 1;";
				ArrayList<ArrayList<Object>> QueryAnswer = DBController.getInstance().GetAllTableData(1,
						GetLowLevelQuery);
				Integer GetLowLevel = (Integer) (QueryAnswer.get(0).get(0));
				recieved.setContents(GetLowLevel);
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.ProductsJoinsOrdersJoinsProductsInOrders:
				String Queryhere = "select MachineID,pId,OrderID,price,TimeToArrive,orderDate,orderStatus,costumerID,refund,supplyMethod,paymentMethod\n"
						+ ",quantity,pName,pCategory,pPrice,pSpecification,pQuantity,ProductStatus,Location,\n"
						+ "Area,LowLevel from orders natural join products_in_order natural join product natural join machines;	";
				recieved.setContents(
						(ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData(21, Queryhere));
				System.out.println("contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.DeleteOrder:
				Integer OrderID = (Integer) recieved.getContents();
				String Queryhere1 = "DELETE FROM orders WHERE OrderID=" + OrderID + ";";
				DBController.getInstance().SelectEditQuery(Queryhere1);
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.ChangeOrderStatus:
				Integer orderId = (Integer) recieved.getContents();
				String Qu = "UPDATE orders SET orderStatus='PickedUp' WHERE OrderID=" + orderId + ";";
				DBController.getInstance().SelectEditQuery(Qu);
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.deleteCoupon:
				ArrayList<String> IDs = (ArrayList<String>) recieved.getContents();
				Integer CouponID = Integer.parseInt(IDs.get(0) + "");
				Integer CustomerID = Integer.parseInt(IDs.get(1) + "");
				String QueryCoupon = "DELETE FROM coupons_for_costumers WHERE costumerID=" + CustomerID
						+ " And couponID=" + CouponID + ";";
				DBController.getInstance().SelectEditQuery(QueryCoupon);
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.getMachines:
				recieved.setContents(
						(ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData("machines", 4));
				ServerMethods.SendToClient(client,recieved);
				break;
				
			case Commands.getCoupons:
				String Querycoupons = "select * from costumers natural join coupons_for_costumers natural join coupons;";
				recieved.setContents(
						(ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData(11, Querycoupons));
				ServerMethods.SendToClient(client,recieved);
				break;

			case Commands.getRegestrationIDNumber:
				String subname = (String) recieved.getContents();
				String tableName = (String) subname + "";
				tableName += "_registirations";
				String QueryIDnum = "select IDNumber from " + tableName + ";	";
				recieved.setContents(
						(ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData(1, QueryIDnum));
				System.out.println("*********contents here : " + recieved.getClass());
				ServerMethods.SendToClient(client,recieved);
				break;
				
			case Commands.OrderPaymentDone:
				ArrayList<Object> contents1 = (ArrayList<Object>) recieved.getContents();
				int productsize1 = (Integer) contents1.get(0);
				String paymentmethod1 = (String) contents1.get(1);
				String DeliveryMethod1 = (String) contents1.get(2);
				String orderprice1 = (String) contents1.get(3);
				String costumerID1 = (String) contents1.get(4);

				ArrayList<String> productsids1 = new ArrayList<>();
				ArrayList<String> productsquantities1 = new ArrayList<>();
				int tempindex = 0;
				for (int i = 5; i < (productsize1 * 2) + 5; i++) {
					if (i % 2 == 0)
						productsquantities1.add(((String) contents1.get(i)));
					else
						productsids1.add((String) contents1.get(i));
					tempindex = i;
				}
				tempindex++;
				String code = (String) contents1.get(tempindex++) + "";
				String machineid = (String) contents1.get(tempindex++) + "";
				DBController.getInstance().InsertNewOrderAfterPayment(orderprice1, paymentmethod1, DeliveryMethod1,
						costumerID1, code, machineid);
				DBController.getInstance().InsertProductsIntoProducts_in_orders(productsids1, productsquantities1);
				DBController.getInstance().DecreaseQuantityForProducts(productsids1, productsquantities1);
				DBController.getInstance().DecreaseQuantityForProducts_in_machines(productsids1, productsquantities1);
				DBController.getInstance().CheckQuantities_ChangeStatus_ToNotAvailable();
				if (DeliveryMethod1.equals("Delivery")) {
					String DAFirstName = (String) contents1.get(tempindex++);
					String DALastName = (String) contents1.get(tempindex++);
					String DAPhoneNumber = (String) contents1.get(tempindex++);
					String DAHouseNumer = (String) contents1.get(tempindex++);
					String DAStreet = (String) contents1.get(tempindex++);
					String DAArea = (String) contents1.get(tempindex++);
					DBController.getInstance().InsertNewOrderDeliveryAddress(DAFirstName, DALastName, DAPhoneNumber,
							DAHouseNumer, DAStreet, DAArea);
				}
				ServerMethods.SendToClient(client,"Done");
				break;
			
			case Commands.UpdateToRightArrivalTimeAfterPayment:
				Integer arrivetime = (Integer)recieved.getContents();
				DBController.getInstance().UpdateToTheRightArrivalTime(arrivetime);
				ServerMethods.SendToClient(client,"Done");
				break;
				
			case Commands.addQuantitiesToProducts:
				// add all quantities to product table
				Integer OrderID9 = (Integer)(recieved.getContents());		
				DBController.getInstance().IncreaseQuantityForProducts(OrderID9);
				break;
						
			case Commands.ChangeOrderStatusToConfirmed:
				Integer orderiddd = (Integer)recieved.getContents();
				DBController.getInstance().UpdateOrderStatusTo_SetConfirmed(orderiddd);
				ServerMethods.SendToClient(client,"Done");
				break;
				
				
			case Commands.DeleteRestockRequest:
				Integer RequestID5 = (Integer) recieved.getContents();
				String DeleteRestockRequestQuery = "DELETE from restockrequests where RequestID=" + RequestID5 + ";";
				DBController.getInstance().SelectEditQuery(DeleteRestockRequestQuery);
				ServerMethods.SendToClient(client, "Done Deleting");
				break;

			case Commands.UpdateRestockRequestStatusToSent:
		        ArrayList<Integer> DataRecieved1 = (ArrayList<Integer>)recieved.getContents();
		        int pid5 = DataRecieved1.get(0);
		        int MachineID5=DataRecieved1.get(1);
				DBController.getInstance().UpdateRestockRequestStatus_ToSent(MachineID5,pid5);
				ServerMethods.SendToClient(client, "Done");
				break;

			case Commands.UpdateRestockRequestStatusToNoRequest:
				ArrayList<Integer> DataRecieved2 = (ArrayList<Integer>)recieved.getContents();
		        int MachineID6 = DataRecieved2.get(0);
		        int pid6=DataRecieved2.get(1);
				DBController.getInstance().UpdateRestockRequestStatus_ToNoRequest(MachineID6,pid6);
				ServerMethods.SendToClient(client, "Done");
				break;
				
			case Commands.TerminateClient:
				this.MyclientDisconnected(client);
				break;
				
			case Commands.getUserPassword:
				String user = (String) recieved.getContents();
				String passQ = "select Password from users where exists(select Password from users where users.Username='"
						+ user + "') and Username='"+user+"';";
				recieved.setContents(
						(ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData(1, passQ));
				ServerMethods.SendToClient(client, recieved);

				break;
			case Commands.getCreditCardInfo:
				String customerid = (String) recieved.getContents();
				String QCC = "select FirstName , LastName, creditCard , expirationDate ,cvv from users natural join costumers where costumerID="+customerid+" ;";
				recieved.setContents(
						(ArrayList<ArrayList<Object>>) DBController.getInstance().GetAllTableData(5, QCC));
				ServerMethods.SendToClient(client, recieved);
				break;

			

			}
		}

	}

	/**
	 * Updates the list of clients currently connected to the server and also print
	 * the connected clients in the console
	 * 
	 */
	public void UpdateClientConnections() {
		String connectedclients = "";
		System.out.println("clients connected are : ");
		if(getClientConnections()!=null)
		for (int i = 0; i < getClientConnections().length; i++) {
			if(((ConnectionToClient) getClientConnections()[i]).toString()!=null) {
			connectedclients += ((ConnectionToClient) getClientConnections()[i]).toString();
			connectedclients += "\n";
			}
		}
		ServerController.cp.setConnectedClients(connectedclients);
	}

	/**
	 *Sets the database controller to be used in the class.
	 *@param dbpar The DBController object to be used for database operations.
	 */
	public static void setDB(DBController dbpar) {
		db = dbpar;
	}

	/**
	 * Handles the event of the server starting to listen for connections on a
	 * specific port.
	 */
	protected void serverStarted() {
		System.out.println("Server listening for connections on port " + getPort());

	}

	/**
	 * This method overrides the one in the superclass. Called when the server stops
	 * listening for connections.
	 */
	protected void serverStopped() {
		System.out.println("Server has stopped listening for connections.");
	}
}
//End of EchoServer class
