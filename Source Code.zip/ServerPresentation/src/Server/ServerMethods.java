package Server;

import java.io.IOException;

import common.Message;
import ocsf.server.ConnectionToClient;

/**
 * ServerMethods class provides a method to send a message to a specific client
 * connected to the server
 * 
 * @author Shadi
 *
 */
public class ServerMethods {
	/**
	 * Sends a message to a specific client, by updating the message contents and
	 * sending it through the given client's connection.
	 * 
	 * @param contents the contents of the message to be sent.
	 * @param client   the client's connection to send the message through.
	 * @param msg      the message to be sent, its contents will be updated.
	 */
	public static void SendToClient(Object contents, ConnectionToClient client, Message msg) {
		msg.setContents(contents);
		try {
			client.sendToClient(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("There was a problem sending message to client");
			e.printStackTrace();
		}
	}
	
	/**
	 * Sends a message to a specified client.
 	* @param client the client to send the message to
 	* @param msg the message to send
	 */
	public static void SendToClient(ConnectionToClient client,Object msg)
	{
		try {
			client.sendToClient(msg);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
