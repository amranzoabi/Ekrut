package Server;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * This class extends Thread and overrides the run method. It enters an infinite
 * loop, calculates the difference between the current date and time and a
 * previously stored date and time in minutes, and executes a series of SQL
 * queries if the difference is greater than or equal to 15 minutes.
 *
 * @author Mahran
 *
 */
public class DeleteTimer extends Thread {

	/**
	 * This is the run method of a Java Thread class. It enters an infinite loop and
	 * at each iteration, it formats the current date and time using a
	 * DateTimeFormatter object and stores it in a string called today. It then
	 * calls the findDifference method, passing it history, today, the string
	 * "Minutes", and the integer 15 as arguments. If the findDifference method
	 * returns true, the run method updates the value of history to the current date
	 * and time and executes a series of SQL queries using the DBController object's
	 * SelectEditQuery method.
	 */
	@Override
	public void run() {
		DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		LocalDateTime now2 = LocalDateTime.now();

		String deleteTime = "1 Day";//you can change  {1 MINUTE,1 HOUR,1 WEEk,1 DAY "or any amount not only 1"}
		//save history as when the thread is activate for first time after launching the server
		String history = dtf1.format(now2);;

		try {
			Thread.sleep(1100);
			String useGlobal = "SET GLOBAL sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));";
			DBController.getInstance().SelectEditQuery(useGlobal);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

		while (true) {
			//always search if the not complete order 
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
			LocalDateTime now = LocalDateTime.now();
			String today = dtf.format(now);
			//every amount if minutes (specified "15 Minutes") search and delete an order not completed from
			//data base if its equal or more than the deleteTime
			if (findDifference(history, today, "Minutes", 13)) {
				history = today;
				String useDb = "USE ekrut";
				String setSafeUpdates = "SET sql_safe_updates = 0";
				String deleteQuery = "DELETE FROM orders WHERE orderStatus = 'NotCompleted' AND (orderDate < DATE_SUB(NOW(), INTERVAL "
						+ deleteTime + ") OR orderDate IS NULL)";
				String resetSafeUpdates = "SET sql_safe_updates = 1";
				DBController.getInstance().SelectEditQuery(useDb);
				DBController.getInstance().SelectEditQuery(setSafeUpdates);
				DBController.getInstance().SelectEditQuery(deleteQuery);
				DBController.getInstance().SelectEditQuery(resetSafeUpdates);

			}
		}
	}

	/**
	 * This method calculates the time difference between two dates in minutes and
	 * returns true if the difference is greater than or equal to a specified
	 * number. It takes in two date strings and a string and an integer as
	 * arguments. It converts the strings to Date objects,calculates the difference
	 * in minutes, and returns true if the difference is greater than or equal to
	 * the specified number
	 * 
	 * @param end_date date today
	 * @return returns true or false
	 */
	static boolean findDifference(String start_date, String end_date, String check, int checkParameter) {

		long difference_In_Time;
		long difference_In_Minutes;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

		// Try Block
		try {

			// parse method is used to parse
			// the text from a string to
			// produce the date
			Date d1 = sdf.parse(start_date);
			Date d2 = sdf.parse(end_date);

			// Calculate time difference
			// in milliseconds
			difference_In_Time = d2.getTime() - d1.getTime();

			difference_In_Minutes = (difference_In_Time / (1000 * 60)) % 60;

			if (check.equals("Minutes") && difference_In_Minutes >= checkParameter)
				return true;

		}

		// Catch the Exception
		catch (ParseException e) {
			System.out.println("Error in date diffrence");
			e.printStackTrace();
		}
		return false;

	}
}
